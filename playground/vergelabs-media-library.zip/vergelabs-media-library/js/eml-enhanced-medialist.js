window.wp = window.wp || {};
window.vergeml = window.vergeml || { l10n: {} };



function emlIsFilterBased( attrs ) {

    if ( _.isUndefined( attrs ) || _.isEmpty( attrs ) ) {
        return false;
    }

    if ( attrs.uploadedTo ) {
        return true;
    }

    if ( _.filter( _.pick( attrs, 'monthnum', 'year' ), _.identity ).length == 2 ) {
        return true;
    }

    return _.some( vergeml.l10n.taxonomies, function( terms, taxonomy ) {
        return ( ! _.isUndefined( attrs[taxonomy] ) && ! _.isNull( attrs[taxonomy] ) );
    });
}



( function( $, _ ) {

    var media = wp.media,
        original = {};



    _.extend( vergeml.l10n, vergeml_enhanced_medialist_l10n );



    /**
     * wp.media.view.MediaFrame.Post
     *
     */
    original.MediaFrame = {

        Post: {
            galleryMenu: media.view.MediaFrame.Post.prototype.galleryMenu,
            playlistMenu: media.view.MediaFrame.Post.prototype.playlistMenu,
            videoPlaylistMenu: media.view.MediaFrame.Post.prototype.videoPlaylistMenu
        }
    };

    _.extend( media.view.MediaFrame.Post.prototype, {

        galleryMenu: function( view ) {

            original.MediaFrame.Post.galleryMenu.apply( this, arguments );

            var library = this.state().get('library'),
                isFilterBased = emlIsFilterBased( library.props.toJSON() );


            if ( isFilterBased ) {
                view.hide( 'gallery-library' );
            }
        },

        playlistMenu: function( view ) {

            original.MediaFrame.Post.playlistMenu.apply( this, arguments );

            var library = this.state().get('library'),
                isFilterBased = emlIsFilterBased( library.props.toJSON() );


            if ( isFilterBased ) {
                view.hide( 'playlist-library' );
            }
        },

        videoPlaylistMenu: function( view ) {

            original.MediaFrame.Post.playlistMenu.apply( this, arguments );

            var library = this.state().get('library'),
                isFilterBased = emlIsFilterBased( library.props.toJSON() );


            if ( isFilterBased ) {
                view.hide( 'video-playlist-library' );
            }
        }
    });



    /**
     *  wp.media.view.Attachment.EditLibrary
     *
     *  Enable/disable the deleting button for gallery media items
     *  based on whether it's a filter-based gallery or not
     *
     */
    _.extend( media.view.Attachment.EditLibrary.prototype, {

        initialize: function() {

            var state = this.controller.state(),
                isFilterBased = emlIsFilterBased( state.get('library').props.toJSON() ),
                isMediaList = 'gallery-edit' === state.get('id') || 'playlist-edit' === state.get('id') || 'video-playlist-edit' === state.get('id');


            this.buttons.close = ( isMediaList && isFilterBased ) ? false : true;
        }
    });



    /**
     * wp.media.view.Settings
     *
     */
    original.Settings = {

        Gallery: {
            render: media.view.Settings.Gallery.prototype.render
        },
        Playlist: {
            render: media.view.Settings.Playlist.prototype.render
        }
    };



    /**
     * wp.media.view.Settings.Gallery
     *
     */
    _.extend( media.view.Settings.Gallery.prototype.events, {
        'change [data-setting=_orderbyRandom]' : 'change_orderbyRandom'
    });

    _.extend( media.view.Settings.Gallery.prototype, {

        render: function() {

            var library = this.controller.frame.state().get('library'),
                append = vergeml.basedOnHTML( library );


            original.Settings.Gallery.render.apply( this, arguments );

            if ( append ) {
                this.$el.append( append );
            }

            return this;
        },

        change_orderbyRandom: function( event ) {

            var content = this.controller.frame.content,
                reverse = content.get().toolbar.get( 'reverse' );


            if ( _.isUndefined( reverse ) ) {
                return false;
            }

            reverse.model.set( 'disabled', $( event.target ).is(':checked') );
        }
    });



    /**
     * wp.media.view.Settings.Playlist
     *
     */
    _.extend( media.view.Settings.Playlist.prototype, {

        render: function() {

            var library = this.controller.frame.state().get('library'),
                append = vergeml.basedOnHTML( library );


            original.Settings.Playlist.render.apply( this, arguments );

            if ( append ) {
                this.$el.append( append );
            }

            return this;
        }
    });



    /**
     * vergeml.basedOnHTML
     *
     * output for:
     * wp.media.view.Settings.Gallery
     * wp.media.view.Settings.Playlist
     *
     */
    vergeml.basedOnHTML = function( library ) {

        var isFilterBased = emlIsFilterBased( library.props.toJSON() ),
            append = '',
            date,
            months = media.view.settings.months,
            monthnum = library.props.get( 'monthnum' ),
            year = library.props.get( 'year' ),
            uploadedTo = library.props.get( 'uploadedTo' );

        if ( isFilterBased ) {

            append = '<br class="clear" /><h3>' + vergeml.l10n.based_on + '</h3><span class="setting eml-filter-based"><ul class="eml-filter-based">';

            _.each( vergeml.l10n.taxonomies, function( attrs, taxonomy ) {

                var terms = library.props.get( taxonomy ),
                    split, join, 
                    taxonomy_string,
                    terms_to_string = [],
                    key;


                if ( terms ) {

                    split = terms.includes( '+' ) ? '+' : ',';
                    join  = terms.includes( '+' ) ? ' + ' : ', ';
                    terms = terms.split( split );

                    if ( typeof terms !== 'object' ) {
                        terms = [terms];
                    }

                    key = ! terms.some(isNaN) ? 'term_id' : 'slug';

                    _.each( terms, function( term ) {

                        var t = _.find( attrs.term_list, function( item ) {
                            return item[key] == term;
                        });

                        terms_to_string.push( t.term_name );
                    });

                    taxonomy_string = '<label>' + attrs.singular_name + '</label>: <strong>' + terms_to_string.join( join ) + '</strong>';
                    append += '<li>' + taxonomy_string + '</li>';
                }
            });

            if ( monthnum && year ) {
                date = _.first( _.where( months, { month: monthnum, year: year } ) ).text;
                append += '<li>' + date + '</li>';
            }

            if ( ! _.isUndefined( uploadedTo ) ) {

                if ( uploadedTo == media.view.settings.post.id ) {
                    append += '<li>' + media.view.l10n.uploadedToThisPost + '</li>';
                }
                else if ( parseInt( uploadedTo ) ) {
                    append += '<li>' + vergeml.l10n.uploaded_to + uploadedTo + '</li>';
                }
            }
            append += '</ul></span>';
        }

        return append;
    };



    /**
     * vergeml.renderSettings
     *
     * for:
     * wp.media.controller.GalleryEdit
     * wp.media.controller.CollectionEdit (Playlist)
     *
     */
    vergeml.renderSettings = function( browser, library, tag ) {

        var reverse = browser.toolbar.get( 'reverse' );


        if ( _.isUndefined( reverse ) ) {
            return false;
        }

        reverse.options.click = function() {

            var order = library.props.get( 'order' );


            if ( 'ASC' === order ) {
                order = 'DESC';
            }
            else if ( 'DESC' === order ) {
                order = 'ASC';
            }

            library[ tag ].set( 'order', order );

            library.props.set( 'order', order, { silent: true } );
            library.reset( library.toArray().reverse() );
            library.saveMenuOrder();
        }
    };



    /**
     * wp.media.controller.GalleryEdit
     *
     */
    original.GalleryEdit = {

        gallerySettings: media.controller.GalleryEdit.prototype.gallerySettings
    };

    _.extend( media.controller.GalleryEdit.prototype, {

        gallerySettings: function( browser ) {
            
            var library = this.get('library');

            original.GalleryEdit.gallerySettings.apply( this, arguments );

            vergeml.renderSettings( browser, library, media.gallery.tag );
        }
    });



    /**
     * wp.media.controller.CollectionEdit (Playlist)
     *
     */
    original.CollectionEdit = {

        renderSettings: media.controller.CollectionEdit.prototype.renderSettings
    };

    _.extend( media.controller.CollectionEdit.prototype, {

        renderSettings: function( browser ) {

            var library = this.get('library');

            original.CollectionEdit.renderSettings.apply( this, arguments );

            vergeml.renderSettings( browser, library, media.playlist.tag );
        }
    });

})( jQuery, _ );
