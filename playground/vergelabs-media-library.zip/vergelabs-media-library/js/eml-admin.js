window.vergeml = window.vergeml || { l10n: {} };


( function( $ ) {

    _.extend( vergeml.l10n, vergeml_admin_l10n );




    var w;


    if ( 'settings_page_media' == window.adminpage )
        window.adminpage = 'options-media-php';
    if ( 'settings_page_media' == window.pagenow )
        window.pagenow = 'options-media';


    if ( $(window).width() < 600 )
        w = '90%';
    else if ( $(window).width() > 1024 )
        w = '500';
    else
        w = '50%';


    window.vergemlConfirmDialog = function( title, html, yes, no, yesClass ) {

        var def = $.Deferred(),

            confirmdialog = $('<div id="eml-dialog-modal"></div>').appendTo('body')
            .html( html )
            .dialog({
                dialogClass : 'eml-dialog-modal',
                modal       : true,
                resizable   : false,
                width       : w,
                autoOpen    : false,
                title       : title,
                buttons     : [
                    {
                        'text'  : yes,
                        'class' : yesClass,
                        'click' : function() {
                            $(this).dialog( 'close' );
                            def.resolve();
                        }
                    },
                    {
                        'text'  : no,
                        'click': function() {
                            $(this).dialog( 'close' );
                            def.reject();
                        }
                    }
                ],
                close: function() {
                    $(this).remove();
                }
            });

        confirmdialog.dialog('open');

        return def.promise();
    }


    window.vergemlAlertDialog = function( title, html, yes, yesClass ) {

        var def = $.Deferred(),

            alertdialog = $('<div id="eml-dialog-modal"></div>').appendTo('body')
            .html( html )
            .dialog({
                dialogClass : 'eml-dialog-modal',
                modal       : true,
                resizable   : false,
                width       : w,
                autoOpen    : false,
                title       : title,
                buttons     : [
                    {
                        'text'  : yes,
                        'class' : yesClass,
                        'click' : function() {
                            $(this).dialog( 'close' );
                            def.resolve();
                        }
                    }
                ],
                close: function() {
                    $(this).remove();
                }
            });

        alertdialog.dialog('open');

        return def.promise();
    }


    window.vergemlFullscreenSpinnerStart = function( text ) {
        $('body').append( '<div class="fullscreen-spinner-box"><div class="fullscreen-spinner-inner-box"><span class="eml-spinner">'+text+'</span></div></div>' );
    }


    window.vergemlFullscreenSpinnerStop = function() {
        $('.fullscreen-spinner-box').remove();
    }

    $( document ).on( 'click', '.eml-admin-notice .notice-dismiss', function( event ) {

        var notice_id = $( event.currentTarget ).parent('.eml-admin-notice').attr('id');

        $.post( ajaxurl, {
            nonce:     vergeml.l10n.admin_notice_nonce,
            action:    'vergeml-admin-notice-dismiss',
            notice_id: notice_id
        });        
    });

})( jQuery );
