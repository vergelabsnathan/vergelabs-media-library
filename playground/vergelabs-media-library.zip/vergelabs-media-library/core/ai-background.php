<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  Describing a library without keeping a tab open.
 *
 *  The on-screen run in js/vergeml-ai.js is a loop of REST calls, which makes
 *  it resumable but not unattended: close the browser and it stops until
 *  somebody clicks again. That is fine for a hundred images and useless for
 *  twenty thousand, which is exactly the library that most needs describing.
 *
 *  So the same step function runs on WP-Cron instead. Nothing new is stored
 *  anywhere: this is the identical vergeml_ai_index_step() the button calls,
 *  on a schedule rather than on a click, and it writes the same index rows.
 *
 *  It is deliberately NOT a queue on the service. A server-side queue would
 *  have to hold the customer's images at rest while it worked through them,
 *  and the retention position this product sells is that nothing is kept --
 *  an image is described in the request that carries it and is never written
 *  down. Moving the waiting to this side keeps that true.
 *
 *  Slower than the on-screen run and it says so on the screen: cron fires when
 *  somebody visits the site, so progress tracks traffic. A site with a real
 *  system cron runs it every minute regardless.
 */


/** The option is not autoloaded: it is read on cron and on one admin screen. */
const VERGEML_AI_RUN_OPTION = 'vergeml_ai_run';

/** The cron hook. Single events, re-scheduled by each tick, rather than a
 *  recurring schedule -- a finite job should not leave a repeating hook
 *  behind when it finishes. */
const VERGEML_AI_RUN_HOOK = 'vergeml_ai_run_tick';

/** Seconds of describing per tick. Under the 30s max_execution_time that
 *  shared hosting still ships, with room for the last call to finish. */
const VERGEML_AI_RUN_BUDGET = 50;

/** Seconds before the next tick is due. Cron cannot fire more often than the
 *  site is visited, so this is a floor rather than a promise. */
const VERGEML_AI_RUN_GAP = 5;

/** How many files one step describes before the budget is checked again.
 *
 *  Eight, which is one group in flight together -- so a chunk now costs about
 *  what a single file used to, and the budget is still only checked between
 *  chunks. Three was chosen when they went one at a time. */
const VERGEML_AI_RUN_CHUNK = 16;


/**
 *  vergeml_ai_run_state
 *
 *  Never returns false: a run that was never started and a run that finished
 *  are both "not running", and no caller should have to tell them apart.
 */
function vergeml_ai_run_state() {

    $state = get_option( VERGEML_AI_RUN_OPTION, array() );

    if ( ! is_array( $state ) ) {
        $state = array();
    }

    return wp_parse_args( $state, array(
        'active'     => false,
        'scope'      => 'unindexed',
        'reason'     => '',
        'apply_alt'  => false,
        'total'      => 0,
        'described'  => 0,
        'failed'     => 0,
        'failed_ids' => array(),
        'remaining'  => 0,
        'started_at' => '',
        'updated_at' => '',
        'stopped'    => '',
    ) );
}


function vergeml_ai_run_save( $state ) {
    $state['updated_at'] = current_time( 'mysql', true );
    update_option( VERGEML_AI_RUN_OPTION, $state, false );
    return $state;
}


function vergeml_ai_run_schedule() {
    /*
     *  Due now, not in five seconds: spawn_cron() only spawns for an event
     *  that is already due, so a run whose first tick sat five seconds in the
     *  future was nudged too early and then waited for a visitor.
     */
    if ( ! wp_next_scheduled( VERGEML_AI_RUN_HOOK ) ) {
        wp_schedule_single_event( time(), VERGEML_AI_RUN_HOOK );
    }
}


/**
 *  vergeml_ai_run_revive
 *
 *  A pass books its successor only as it ends. Cron takes the event off the
 *  schedule before it calls the tick, so a pass that php-fpm kills half-way
 *  -- a memory limit, a restart, a request timeout -- leaves an active run
 *  with nothing booked and a lock that outlives it, and nothing on the site
 *  ever runs it again. The screen says "working" for good.
 *
 *  So an active run with nothing booked is booked again, once the dead pass's
 *  lock has lapsed: from every admin request, and from the status the screen
 *  polls. A lock still warm means a pass is alive and will book its own.
 *
 *  @return bool  whether it booked one.
 */
add_action( 'admin_init', 'vergeml_ai_run_revive' );

function vergeml_ai_run_revive() {

    if ( false !== wp_next_scheduled( VERGEML_AI_RUN_HOOK ) ) {
        return false;
    }

    $state = vergeml_ai_run_state();

    if ( empty( $state['active'] ) || get_transient( 'vergeml_ai_run_lock' ) ) {
        return false;
    }

    vergeml_ai_run_schedule();
    vergeml_ai_run_nudge();

    return true;
}


/**
 *  Keep going without waiting for a visitor.
 *
 *  WP-Cron is not a clock. It fires when somebody loads a page, so on a site
 *  nobody is browsing -- a staging copy, a shop at four in the morning, a box
 *  a developer left open on another tab -- a run that says "you can close this
 *  tab" simply stops, and the screen goes on claiming it is working. That is
 *  the whole complaint: it does not finish, and it does not continue when you
 *  move to another page.
 *
 *  So the tick asks the site to run its own due events, in a request it does
 *  not wait for. The overlap lock in the tick is what makes this safe: a
 *  second one arriving early finds the lock and returns. Cron stays as the
 *  fallback for whenever a visitor does turn up.
 */
function vergeml_ai_run_nudge() {

    // Nothing to chase if the work is done or somebody stopped it.
    $state = vergeml_ai_run_state();
    if ( empty( $state['active'] ) ) {
        return;
    }

    /*
     *  A host with a system cron of its own, or a suite that starts a run
     *  only to look at it, can leave the event to be picked up rather than
     *  have a pass spawned this instant.
     */
    if ( ! apply_filters( 'vergeml_ai_run_should_nudge', true ) ) {
        return;
    }

    /*
     *  wp-cron.php only works when the key in the request matches the
     *  'doing_cron' lock. Posting a fresh key without taking the lock, which
     *  is what this did until 3 September 2026, is refused on line one of
     *  the lock check: every nudge on the box came back in zero seconds and
     *  the run waited for whatever else happened to spawn cron. Outside a
     *  cron run, core's spawn_cron() takes the lock and posts; it declines
     *  while a run holds the lock, and that run drops it as it ends.
     */
    if ( ! defined( 'DOING_CRON' ) ) {
        spawn_cron();
        return;
    }

    /*
     *  Inside a tick spawn_cron() refuses outright, so the next request is
     *  chained the way core's own does it: take the lock with a new key and
     *  post that key. The finishing run only clears the lock when it still
     *  holds it, so the handover is clean.
     */
    $key = sprintf( '%.22F', microtime( true ) );
    set_transient( 'doing_cron', $key );

    wp_remote_post(
        add_query_arg( 'doing_wp_cron', $key, site_url( 'wp-cron.php' ) ),
        array(
            'timeout'   => 0.01,
            'blocking'  => false,
            'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
            'headers'   => array( 'Cache-Control' => 'no-cache' ),
        )
    );
}


function vergeml_ai_run_unschedule() {
    $next = wp_next_scheduled( VERGEML_AI_RUN_HOOK );
    while ( false !== $next ) {
        wp_unschedule_event( $next, VERGEML_AI_RUN_HOOK );
        $next = wp_next_scheduled( VERGEML_AI_RUN_HOOK );
    }
}


/**
 *  vergeml_ai_run_start
 *
 *  @return array|WP_Error  the new state, or why it will not start.
 */
function vergeml_ai_run_start( $scope, $apply_alt, $reason = '' ) {

    if ( ! in_array( $scope, array( 'unindexed', 'missing-alt', 'page-gap', 'stale' ), true ) ) {
        return new WP_Error( 'vergeml_ai_bad_scope', __( 'Unknown scope.', 'vergelabs-media-library' ), array( 'status' => 400 ) );
    }

    if ( ! vergeml_ai_ready() ) {
        return new WP_Error( 'vergeml_ai_unconfigured', __( 'Add a licence key, or switch on demo mode, before starting a background run.', 'vergelabs-media-library' ), array( 'status' => 400 ) );
    }

    $pending = vergeml_ai_pending_count( $scope );

    if ( 0 === $pending ) {
        return new WP_Error( 'vergeml_ai_nothing_to_do', __( 'There is nothing left to describe in that scope.', 'vergelabs-media-library' ), array( 'status' => 409 ) );
    }

    $state = vergeml_ai_run_save( array(
        'active'     => true,
        'scope'      => $scope,
        'apply_alt'  => (bool) $apply_alt,
        'total'      => $pending,
        'described'  => 0,
        'failed'     => 0,
        'failed_ids' => array(),
        'remaining'  => $pending,
        'started_at' => current_time( 'mysql', true ),
        'stopped'    => '',
        // Why it started, when it started itself, so the screen can say so.
        'reason'     => (string) $reason,
    ) );

    // Due now: a run that ended waiting on the service may have booked a
    // pass ten minutes out, and a fresh press should not wait for it.
    vergeml_ai_run_unschedule();
    vergeml_ai_run_schedule();
    vergeml_ai_run_nudge();

    return $state;
}


/**
 *  vergeml_ai_run_stop
 *
 *  @param string $reason  what the screen should say. Empty means the person
 *                         stopped it, which needs no explaining.
 */
function vergeml_ai_run_stop( $reason = '' ) {

    vergeml_ai_run_unschedule();

    $state = vergeml_ai_run_state();

    $state['active']    = false;
    $state['stopped']   = (string) $reason;
    $state['remaining'] = vergeml_ai_pending_count( $state['scope'] );

    return vergeml_ai_run_save( $state );
}


/**
 *  vergeml_ai_run_tick
 *
 *  One cron pass. Describes for as long as the budget allows, writes down what
 *  happened, and books the next pass -- or stops, if there is nothing left or
 *  something happened that every further call would hit as well.
 */

add_action( VERGEML_AI_RUN_HOOK, 'vergeml_ai_run_tick' );

function vergeml_ai_run_tick() {

    $state = vergeml_ai_run_state();

    if ( empty( $state['active'] ) ) {
        return;
    }

    /*
     *  One pass at a time. Cron normally sees to this itself, but a busy site
     *  can spawn a second loopback before the first has finished, and two
     *  passes describing the same files would spend a customer's credits
     *  twice for one result.
     */
    if ( get_transient( 'vergeml_ai_run_lock' ) ) {
        return;
    }

    /*
     *  The lock is a heartbeat, not a lease. It lived five minutes and was
     *  set once, so a pass killed half-way held the run up for the rest of
     *  those minutes. Now it lasts two and is renewed before every batch; a
     *  batch is sixteen calls in flight together, each capped at sixty
     *  seconds, so a living pass never lets it lapse and a dead one is found
     *  out within two minutes of its last batch (vergeml_ai_run_revive).
     */
    set_transient( 'vergeml_ai_run_lock', time(), 2 * MINUTE_IN_SECONDS );

    // Cron requests inherit the site's limit, which on shared hosting is
    // often 30 seconds. Ask for more; carry on without it if refused.
    if ( function_exists( 'set_time_limit' ) ) {
        @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, Squiz.PHP.DiscouragedFunctions.Discouraged -- a long cron job on shared hosting; refused silently where disallowed.
    }

    $started = time();
    $stop    = '';
    /*
     *  Waiting: this tick stored nothing and every picture it asked for was
     *  held -- the service is away. Judged over the whole tick, not the last
     *  step: a budget that runs out after a step that held four of sixteen
     *  is the same outage.
     */
    $waiting = true;
    // The budget is a constant; a suite reaches the tail's other branch through the filter.
    $budget = (int) apply_filters( 'vergeml_ai_run_budget', VERGEML_AI_RUN_BUDGET );

    do {
        set_transient( 'vergeml_ai_run_lock', time(), 2 * MINUTE_IN_SECONDS );

        $result   = vergeml_ai_index_step( $state['scope'], VERGEML_AI_RUN_CHUNK, $state['apply_alt'] );
        $held_now = 0;

        $state['described'] += count( $result['described'] );
        $state['remaining']  = (int) $result['remaining'];

        /*
         *  Pictures, not attempts. A picture the run retried every pass was
         *  counted every pass, so the screen said "13 of 19 described · 12
         *  could not be described" about six pictures; and one that went
         *  through on a later pass is no longer a failure at all.
         */
        $failed_ids = array_map( 'intval', (array) ( isset( $state['failed_ids'] ) ? $state['failed_ids'] : array() ) );

        foreach ( (array) $result['described'] as $ok ) {
            $okid = is_array( $ok ) ? (int) ( isset( $ok['id'] ) ? $ok['id'] : 0 ) : (int) $ok;
            $at   = array_search( $okid, $failed_ids, true );
            if ( false !== $at ) {
                array_splice( $failed_ids, $at, 1 );
            }
        }

        foreach ( $result['errors'] as $error ) {

            // A held picture is one the service did not answer for; it is
            // waiting, not failed, and comes round again after the hold.
            if ( ! empty( $error['held'] ) ) {
                $held_now++;
                continue;
            }

            $id = isset( $error['id'] ) ? (int) $error['id'] : 0;
            if ( $id > 0 && ! in_array( $id, $failed_ids, true ) ) {
                $failed_ids[] = $id;
            }

            /*
             *  A fatal is out of credits, a refused licence or no licence at
             *  all. Every remaining file would fail the same way, so the run
             *  ends and says why rather than grinding through the backlog
             *  writing error stubs over it.
             */
            if ( ! empty( $error['fatal'] ) ) {
                $stop = (string) $error['error'];
            }
        }

        $state['failed_ids'] = array_slice( $failed_ids, -500 );
        $state['failed']     = count( $failed_ids );

        if ( '' !== $stop ) {
            break;
        }

        if ( ! empty( $result['described'] ) || count( $result['errors'] ) > $held_now ) {
            $waiting = false;
        }

        // Nothing described and nothing failed means the step found no work
        // it could take; looping on that would spin.
        if ( empty( $result['described'] ) && empty( $result['errors'] ) ) {
            break;
        }

        // Every picture this step asked for was held: asking for the next
        // ones now would only hold them too. The tail books the next pass
        // for when the hold lapses.
        if ( empty( $result['described'] ) && $held_now > 0 && count( $result['errors'] ) === $held_now ) {
            break;
        }

    } while ( $state['remaining'] > 0 && ( time() - $started ) < $budget );

    delete_transient( 'vergeml_ai_run_lock' );

    if ( '' !== $stop ) {
        vergeml_ai_run_save( $state );
        vergeml_ai_run_stop( $stop );
        return;
    }

    /*
     *  Recounted before deciding the run is over.
     *
     *  'remaining' came from the step, and the step has already dropped every
     *  id on the ten-minute hold -- a transient refusal, a duplicate. So the
     *  count reached zero with 96 pictures still on the old prompt, and the
     *  run declared itself finished. pending_count() does not apply the hold,
     *  so a run with held pictures stays active, reschedules, and collects
     *  them once the hold lapses -- which is what the hold was for.
     */
    $state['remaining'] = (int) vergeml_ai_pending_count( $state['scope'] );

    /*
     *  Finished. Anything still filed under an older prompt is stale, and
     *  until 17 September 2026 a finishing run started a 'stale' run over it
     *  on its own -- a prompt change on the service re-described every
     *  customer's library without a press. Now the count sits on the
     *  dashboard's button ("Re-describe N images · Costs N credits") and
     *  waits; a library half on the old prompt ranks a little wrong until
     *  the owner presses, with the number in front of them. Nothing spends
     *  credits by itself.
     */
    if ( $state['remaining'] < 1 ) {
        vergeml_ai_run_save( $state );
        vergeml_ai_run_stop( '' );
        return;
    }

    vergeml_ai_run_save( $state );

    /*
     *  Due now rather than in thirty seconds, and chased immediately: the gap
     *  was only ever politeness to shared hosting, and the batch size is what
     *  actually bounds the work per tick. A run that pauses for half a minute
     *  between batches and then waits indefinitely for a page load is not a
     *  background run, it is a stalled one.
     */
    /*
     *  Unless the last step held everything it was offered -- the service is
     *  away, or every remaining picture was described minutes ago -- in
     *  which case there is nothing to do until the hold lapses: booked for
     *  then, and not chased. Booked now and chased, a tick during an outage
     *  followed a tick followed a tick for the length of the hold (4.0.4).
     */
    // Five seconds past the hold, so the pass does not arrive while the hold still stands.
    if ( ! wp_next_scheduled( VERGEML_AI_RUN_HOOK ) ) {
        wp_schedule_single_event( time() + ( $waiting ? VERGEML_AI_HOLD_SECONDS + 5 : 0 ), VERGEML_AI_RUN_HOOK );
    }
    if ( ! $waiting ) {
        vergeml_ai_run_nudge();
    }
}


/* ----------------------------------------------------------------- the API */

add_action( 'rest_api_init', 'vergeml_ai_run_routes' );

function vergeml_ai_run_routes() {

    register_rest_route( VERGEML_REST_NS, '/ai-run', array(
        array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => 'vergeml_ai_run_rest_status',
            'permission_callback' => function () {
                return current_user_can( 'manage_categories' );
            },
        ),
        array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'vergeml_ai_run_rest_write',
            // Same bar as /ai-index: this describes files and writes their meta.
            'permission_callback' => function () {
                return current_user_can( 'manage_categories' );
            },
            'args'                => array(
                'action'    => array( 'type' => 'string', 'default' => 'start' ),
                'scope'     => array( 'type' => 'string', 'default' => 'unindexed' ),
                'apply_alt' => array( 'type' => 'boolean', 'default' => false ),
            ),
        ),
    ) );
}


function vergeml_ai_run_payload() {

    // The screen polls this every five seconds, so a run whose pass died is
    // picked up while somebody is watching it, not on the next admin visit.
    vergeml_ai_run_revive();

    $state = vergeml_ai_run_state();

    $next = wp_next_scheduled( VERGEML_AI_RUN_HOOK );

    return array(
        'active'    => (bool) $state['active'],
        'scope'     => $state['scope'],
        'total'     => (int) $state['total'],
        'described' => (int) $state['described'],
        'failed'    => (int) $state['failed'],
        'remaining' => (int) $state['remaining'],
        'stopped'   => (string) $state['stopped'],
        'started'   => (string) $state['started_at'],
        'updated'   => (string) $state['updated_at'],
        // The screen says "next pass is due" rather than "is running", because
        // cron fires on a visit and there is no honest way to promise a time.
        'next'      => false === $next ? null : max( 0, (int) $next - time() ),
        /*
         *  A site with DISABLE_WP_CRON and no system cron behind it will never
         *  fire the hook, and a progress bar that never moves is a worse
         *  answer than a sentence saying so.
         */
        'cron_off'  => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
    );
}


function vergeml_ai_run_rest_status() {
    return rest_ensure_response( vergeml_ai_run_payload() );
}


function vergeml_ai_run_rest_write( WP_REST_Request $request ) {

    if ( 'stop' === $request->get_param( 'action' ) ) {
        vergeml_ai_run_stop( '' );
        return rest_ensure_response( vergeml_ai_run_payload() );
    }

    $started = vergeml_ai_run_start(
        $request->get_param( 'scope' ),
        (bool) $request->get_param( 'apply_alt' )
    );

    if ( is_wp_error( $started ) ) {
        return $started;
    }

    return rest_ensure_response( vergeml_ai_run_payload() );
}


/* ---------------------------------------------------------------- the card */

/*
 *  No card of its own.
 *
 *  This used to render "Describe in the background" directly under "Describe
 *  the library", with two buttons doing the same two jobs. One feature, shown
 *  twice, with nothing saying which to pick. The choice now lives inside the
 *  one describe section in core/ai.php, and the progress line and stop button
 *  there are these -- same ids, so the JS below is unchanged.
 */


add_action( 'admin_enqueue_scripts', 'vergeml_ai_run_assets' );

function vergeml_ai_run_assets( $hook ) {

    if ( false === strpos( (string) $hook, 'media-ai' ) ) {
        return;
    }

    wp_enqueue_script(
        'vergeml-ai-background',
        plugins_url( 'js/vergeml-ai-background.js', VERGEML_FILE ),
        array( 'wp-api-fetch' ),
        vergeml_asset_ver( 'js/vergeml-ai-background.js' ),
        true
    );

    wp_localize_script( 'vergeml-ai-background', 'vergemlAiRun', array(
        'idle'     => '',
        /* translators: 1: pictures described so far, 2: pictures in the run. */
        'progress' => __( '%1$d of %2$d described', 'vergelabs-media-library' ),
        /* translators: 1: pictures described so far, 2: pictures in the run. */
        'button'   => __( 'Describing %1$d of %2$d', 'vergelabs-media-library' ),
        /* translators: %d: seconds until the next pass is due. */
        'next'     => __( 'next pass due in %ds', 'vergelabs-media-library' ),
        'due'      => __( 'next pass is due', 'vergelabs-media-library' ),
        /* translators: %d: number of pictures that could not be described. */
        'failed'   => __( '%d could not be described', 'vergelabs-media-library' ),
        /* translators: 1: pictures described, 2: pictures that failed. */
        'done'     => __( '%1$d pictures described · %2$d failed', 'vergelabs-media-library' ),
        /* translators: 1: pictures described, 2: pictures in the run, 3: pictures left. */
        'stopped'  => __( '%1$d of %2$d described · %3$d left · stopped', 'vergelabs-media-library' ),
        'cronOff'  => __( 'This site has WP-Cron off. The run moves only when a system cron calls wp-cron.php.', 'vergelabs-media-library' ),
        'starting' => __( 'Starting', 'vergelabs-media-library' ),
    ) );
}
