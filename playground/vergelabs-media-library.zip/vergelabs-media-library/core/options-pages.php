<?php

if ( ! defined( 'ABSPATH' ) )
    exit;



/**
 *  vergeml_register_setting
 *
 *  @since    1.0
 *  @created  03/08/13
 */

add_action( 'admin_init', 'vergeml_register_setting' );

function vergeml_register_setting() {

    // plugin settings: media library
    register_setting(
        'media-library', //option_group
        'vergeml_lib_options', //option_name
        'vergeml_lib_options_validate' //sanitize_callback
    );

    // plugin settings: taxonomies
    register_setting(
        'media-taxonomies', //option_group
        'vergeml_taxonomies', //option_name
        'vergeml_taxonomies_validate' //sanitize_callback
    );

    // plugin settings: taxonomies options
    register_setting(
        'media-taxonomies', //option_group
        'vergeml_tax_options', //option_name
        'vergeml_tax_options_validate' //sanitize_callback
    );

    // plugin settings: mime types
    register_setting(
        'mime-types', //option_group
        'vergeml_mimes', //option_name
        'vergeml_mimes_validate' //sanitize_callback
    );

    // plugin settings: network settings
    // validated explicitly in vergeml_update_network_settings; the callback
    // below is the generic guard for anything arriving via the Settings API
    register_setting(
        'eml-network-settings', //option_group
        'vergeml_network_options', //option_name
        'vergeml_sanitize_option_array' //sanitize_callback
    );

    // plugin settings: all settings backup before import
    register_setting(
        'vergeml_backup', //option_group
        'vergeml_backup', //option_name
        'vergeml_sanitize_option_array' //sanitize_callback
    );

    // plugin settings: remote admin notices
    register_setting(
        'vergeml_notices', //option_group
        'vergeml_notices', //option_name
        'vergeml_sanitize_option_array' //sanitize_callback
    );
}



/**
 *  vergeml_sanitize_option_array
 *
 *  Generic sanitiser for the option groups that carry no validation callback of
 *  their own. Walks the array and runs every string through
 *  sanitize_text_field, leaving structure and scalar types alone so stored
 *  integers and booleans do not come back as strings.
 *
 *  These three options are normally written with update_option rather than
 *  through options.php, so in practice this runs only if something posts them
 *  via the Settings API.
 *
 *  @since    2.9.8
 */

function vergeml_sanitize_option_array( $value ) {

    if ( is_array( $value ) ) {
        return array_map( 'vergeml_sanitize_option_array', $value );
    }

    if ( is_string( $value ) ) {
        return sanitize_text_field( $value );
    }

    // int, float, bool and null are already safe to store as they are
    return $value;
}



/**
 *  vergeml_admin_media_menu
 *
 *  @since    2.6
 *  @created  28/04/18
 */

add_action( 'admin_menu', 'vergeml_admin_media_menu', 12 );

function vergeml_admin_media_menu() {

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'media_settings' ) )
            return;
    }


    $eml_media_options_page = add_submenu_page(
        '',
        __('Media Settings','vergelabs-media-library'), //page_title
        '',                                //menu_title
        'manage_options',                  //capability
        'media',                           //menu_slug
        'vergeml_print_media_settings'  //callback
    );

    $eml_medialibrary_options_page = add_submenu_page(
        VERGEML_MENU,
        __('Media Library','vergelabs-media-library') . ' &lsaquo; ' . __('Media Settings','vergelabs-media-library'),
        __('Media Library','vergelabs-media-library'),
        'manage_options',
        'media-library',
        'vergeml_print_media_library_options'
    );

    $eml_taxonomies_options_page = add_submenu_page(
        VERGEML_MENU,
        __('Media Taxonomies','vergelabs-media-library') . ' &lsaquo; ' . __('Media Settings','vergelabs-media-library'),
        __('Media Taxonomies','vergelabs-media-library'),
        'manage_options',
        'media-taxonomies',
        'vergeml_print_taxonomies_options'
    );

    $eml_mimetype_options_page = add_submenu_page(
        VERGEML_MENU,
        __('MIME Types','vergelabs-media-library') . ' &lsaquo; ' . __('Media Settings','vergelabs-media-library'),
        __('MIME Types','vergelabs-media-library'),
        'manage_options',
        'mime-types',
        'vergeml_print_mimetypes_options'
    );


    add_action( 'load-' . $eml_media_options_page, 'vergeml_load_media_options_page' );
    add_action( $eml_media_options_page, 'vergeml_media_options_page' );

    add_action('admin_print_scripts-' . $eml_medialibrary_options_page, 'vergeml_medialibrary_options_page_scripts');
    add_action('admin_print_scripts-' . $eml_taxonomies_options_page, 'vergeml_taxonomies_options_page_scripts');
    add_action('admin_print_scripts-' . $eml_mimetype_options_page, 'vergeml_mimetype_options_page_scripts');
}



/**
 *  vergeml_admin_utility_menu
 *
 *  @since    2.6
 *  @created  28/04/18
 */

add_action( 'admin_menu', 'vergeml_admin_utility_menu' );

function vergeml_admin_utility_menu() {

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'utilities' ) )
            return;
    }


    $eml_options_page = add_options_page(
       __('VergeLabs Media Library Utilities','vergelabs-media-library'),
       __('Media Utilities','vergelabs-media-library'),
       'manage_options',
       'eml-settings',
       'vergeml_print_settings'
    );

    add_action('admin_print_scripts-' . $eml_options_page, 'vergeml_options_page_scripts');
}



/**
 *  vergeml_network_admin_menu
 *
 *  @since    2.6
 *  @created  22/04/18
 */

add_action( 'network_admin_menu', 'vergeml_network_admin_menu' );

function vergeml_network_admin_menu() {

    $eml_network_options_page = add_submenu_page(
        'settings.php',
        __('VergeLabs Media Library Utilities','vergelabs-media-library'),
        __('Media Utilities','vergelabs-media-library'),
        'manage_network_options',
        'eml-settings',
        'vergeml_print_network_settings'
    );

    add_action('admin_print_scripts-' . $eml_network_options_page, 'vergeml_options_page_scripts');
}



/**
 *  vergeml_submenu_order
 *
 *  Custom admin media menu.
 *
 *  @since    2.6
 *  @created  04/03/18
 */

add_action( 'admin_menu', 'vergeml_submenu_order', 1001 );

function vergeml_submenu_order() {

    global $submenu;


    if ( ! isset( $submenu['options-general.php'] ) ) {
        return;
    }

    $media_key = 0;
    $media_items = array();
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- reading which settings tab to mark active, no state is changed.
    $requested_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
    $page = in_array( $requested_page, array( 'media', 'media-library', 'media-taxonomies', 'mime-types' ), true ) ? $requested_page : '';
    $settings_menu = array_values( $submenu['options-general.php'] );

    foreach( $settings_menu as $key => $item ) {

        if ( 'options-media.php' === $item[2] ) {

            $media_key = $key;
            $settings_menu[$key][2] = 'options-general.php?page=media';
            $settings_menu[$key][4] = ( 'media' === $page ) ? 'eml-menu-media current' : 'eml-menu-media';
        }

        if ( in_array( $item[2], array('media-library','media-taxonomies','mime-types') ) ) {

            $item[4] = 'eml-media-submenu';
            $media_items[] = $item;

            unset( $settings_menu[$key] );
        }
    }

    array_splice( $settings_menu, $media_key+1, 0, $media_items );
    $submenu['options-general.php'] = $settings_menu;
}



/**
 *  vergeml_load_media_options_page
 *
 *  Ensure compatibility with default options-media.php for third-parties
 *
 *  @since    2.3
 *  @created  14/06/16
 */

function vergeml_load_media_options_page() {

    global $pagenow, $title;

    // to avoid the unknown global value (php 8)
    // @todo: look deeper
    $title = '';

    $hook_suffix = $pagenow = 'options-media.php';

    /*
     *  These are WordPress's own admin page lifecycle hooks, not ours. This
     *  screen replaces options-media.php, so it has to fire them or every other
     *  plugin that enqueues assets or prints markup for that screen is silently
     *  skipped. Prefixing them would not namespace anything, it would stop them
     *  reaching the callbacks they exist for.
     */

    // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core hooks, deliberately fired.
    do_action( "load-{$hook_suffix}" );
    do_action( 'admin_enqueue_scripts', $hook_suffix );
    do_action( "admin_print_styles-{$hook_suffix}" );
    do_action( "admin_print_scripts-{$hook_suffix}" );
    do_action( "admin_head-{$hook_suffix}" );
    // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound

    add_filter( 'admin_body_class', 'vergeml_admin_body_class_for_media_options_page' );
    add_filter( 'admin_title', 'vergeml_admin_title_for_media_options_page', 10, 2 );
}



/**
 *  vergeml_admin_body_class_for_media_options_page
 *
 *  Ensure compatibility with default options-media.php for third-parties
 *
 *  @since    2.3.6
 *  @created  16/12/16
 */

function vergeml_admin_body_class_for_media_options_page( $admin_body_class ) {

    $hook_suffix = 'options-media.php';

    $admin_body_class .= preg_replace('/[^a-z0-9_\-]+/i', '-', $hook_suffix);

    return $admin_body_class;
}



/**
 *  vergeml_admin_title_for_media_options_page
 *
 *  @since    2.3.6
 *  @created  16/12/16
 */

function vergeml_admin_title_for_media_options_page( $admin_title, $title ) {

    $admin_title = __('Media Settings','vergelabs-media-library') . $admin_title;

    return $admin_title;
}



/**
 *  vergeml_media_options_page
 *
 *  Ensure compatibility with default options-media.php for third-parties
 *
 *  @since    2.3.6
 *  @created  16/12/16
 */

function vergeml_media_options_page() {

    $hook_suffix = 'options-media.php';

    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- fires core's own options-media.php screen hook.
    do_action( $hook_suffix );
}



/**
 *  vergeml_print_media_settings
 *
 *  Based on wp-admin/options-media.php
 *
 *  @since    2.2.1
 *  @created  11/04/16
 */

function vergeml_print_media_settings() {

    if ( ! current_user_can( 'manage_options' ) )
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'media_settings' ) )
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );
    }

    settings_errors();


    $title = __( 'Media Settings', 'vergelabs-media-library' );
    ?>

    <div class="wrap">
    <h1><?php echo esc_html( $title ); ?></h1>

    <?php
    /*
     *  The tab strip is gone from the plugin's own screens -- they sit in a menu
     *  of their own now, and a page carrying navigation that repeats the sidebar
     *  beside it is asking to be read twice. This screen is not in that menu, so
     *  it keeps a way back to it.
     */
    printf(
        '<p><a href="%1$s">&larr; %2$s</a></p>',
        esc_url( admin_url( 'admin.php?page=' . VERGEML_MENU ) ),
        esc_html__( 'Media Library settings', 'vergelabs-media-library' )
    );
    ?>

    <form action="options.php" method="post">
    <?php settings_fields( 'media' ); ?>

    <h2 class="title"><?php esc_html_e( 'Image sizes', 'vergelabs-media-library' ); ?></h2>
    <p><?php esc_html_e( 'The sizes listed below determine the maximum dimensions in pixels to use when adding an image to the Media Library.', 'vergelabs-media-library' ); ?></p>

    <table class="form-table" role="presentation">
    <tr>
    <th scope="row"><?php esc_html_e( 'Thumbnail size', 'vergelabs-media-library' ); ?></th>
    <td><fieldset><legend class="screen-reader-text"><span>
        <?php
        /* translators: Hidden accessibility text. */
        esc_html_e( 'Thumbnail size', 'vergelabs-media-library' );
        ?>
    </span></legend>
    <label for="thumbnail_size_w"><?php esc_html_e( 'Width', 'vergelabs-media-library' ); ?></label>
    <input name="thumbnail_size_w" type="number" step="1" min="0" id="thumbnail_size_w" value="<?php form_option( 'thumbnail_size_w' ); ?>" class="small-text" />
    <br />
    <label for="thumbnail_size_h"><?php esc_html_e( 'Height', 'vergelabs-media-library' ); ?></label>
    <input name="thumbnail_size_h" type="number" step="1" min="0" id="thumbnail_size_h" value="<?php form_option( 'thumbnail_size_h' ); ?>" class="small-text" />
    </fieldset>
    <input name="thumbnail_crop" type="checkbox" id="thumbnail_crop" value="1" <?php checked( '1', get_option( 'thumbnail_crop' ) ); ?>/>
    <label for="thumbnail_crop"><?php esc_html_e( 'Crop thumbnail to exact dimensions (normally thumbnails are proportional)', 'vergelabs-media-library' ); ?></label>
    </td>
    </tr>

    <tr>
    <th scope="row"><?php esc_html_e( 'Medium size', 'vergelabs-media-library' ); ?></th>
    <td><fieldset><legend class="screen-reader-text"><span>
        <?php
        /* translators: Hidden accessibility text. */
        esc_html_e( 'Medium size', 'vergelabs-media-library' );
        ?>
    </span></legend>
    <label for="medium_size_w"><?php esc_html_e( 'Max Width', 'vergelabs-media-library' ); ?></label>
    <input name="medium_size_w" type="number" step="1" min="0" id="medium_size_w" value="<?php form_option( 'medium_size_w' ); ?>" class="small-text" />
    <br />
    <label for="medium_size_h"><?php esc_html_e( 'Max Height', 'vergelabs-media-library' ); ?></label>
    <input name="medium_size_h" type="number" step="1" min="0" id="medium_size_h" value="<?php form_option( 'medium_size_h' ); ?>" class="small-text" />
    </fieldset></td>
    </tr>

    <tr>
    <th scope="row"><?php esc_html_e( 'Large size', 'vergelabs-media-library' ); ?></th>
    <td><fieldset><legend class="screen-reader-text"><span>
        <?php
        /* translators: Hidden accessibility text. */
        esc_html_e( 'Large size', 'vergelabs-media-library' );
        ?>
    </span></legend>
    <label for="large_size_w"><?php esc_html_e( 'Max Width', 'vergelabs-media-library' ); ?></label>
    <input name="large_size_w" type="number" step="1" min="0" id="large_size_w" value="<?php form_option( 'large_size_w' ); ?>" class="small-text" />
    <br />
    <label for="large_size_h"><?php esc_html_e( 'Max Height', 'vergelabs-media-library' ); ?></label>
    <input name="large_size_h" type="number" step="1" min="0" id="large_size_h" value="<?php form_option( 'large_size_h' ); ?>" class="small-text" />
    </fieldset></td>
    </tr>

    <?php do_settings_fields( 'media', 'default' ); ?>
    </table>

    <?php
    /**
     * @global array $wp_settings
     */
    if ( isset( $GLOBALS['wp_settings']['media']['embeds'] ) ) :
        ?>
    <h2 class="title"><?php esc_html_e( 'Embeds', 'vergelabs-media-library' ); ?></h2>
    <table class="form-table" role="presentation">
        <?php do_settings_fields( 'media', 'embeds' ); ?>
    </table>
    <?php endif; ?>

    <?php if ( ! is_multisite() ) : ?>
    <h2 class="title"><?php esc_html_e( 'Uploading Files', 'vergelabs-media-library' ); ?></h2>
    <table class="form-table" role="presentation">
        <?php
        /*
         * If upload_url_path is not the default (empty),
         * or upload_path is not the default ('wp-content/uploads' or empty),
         * they can be edited, otherwise they're locked.
         */
        if ( get_option( 'upload_url_path' )
            || get_option( 'upload_path' ) && 'wp-content/uploads' !== get_option( 'upload_path' ) ) :
            ?>
    <tr>
    <th scope="row"><label for="upload_path"><?php esc_html_e( 'Store uploads in this folder', 'vergelabs-media-library' ); ?></label></th>
    <td><input name="upload_path" type="text" id="upload_path" value="<?php echo esc_attr( get_option( 'upload_path' ) ); ?>" class="regular-text code" />
    <p class="description">
            <?php
            /* translators: %s: wp-content/uploads */
            printf( esc_html__( 'Default is %s', 'vergelabs-media-library' ), '<code>wp-content/uploads</code>' );
            ?>
    </p>
    </td>
    </tr>

    <tr>
    <th scope="row"><label for="upload_url_path"><?php esc_html_e( 'Full URL path to files', 'vergelabs-media-library' ); ?></label></th>
    <td><input name="upload_url_path" type="text" id="upload_url_path" value="<?php echo esc_attr( get_option( 'upload_url_path' ) ); ?>" class="regular-text code" />
    <p class="description"><?php esc_html_e( 'Configuring this is optional. By default, it should be blank.', 'vergelabs-media-library' ); ?></p>
    </td>
    </tr>
    <tr>
    <td colspan="2" class="td-full">
    <?php else : ?>
    <tr>
    <td class="td-full">
    <?php endif; ?>
    <label for="uploads_use_yearmonth_folders">
    <input name="uploads_use_yearmonth_folders" type="checkbox" id="uploads_use_yearmonth_folders" value="1"<?php checked( '1', get_option( 'uploads_use_yearmonth_folders' ) ); ?> />
        <?php esc_html_e( 'Organize my uploads into month- and year-based folders', 'vergelabs-media-library' ); ?>
    </label>
    </td>
    </tr>

        <?php do_settings_fields( 'media', 'uploads' ); ?>
    </table>
    <?php endif; ?>

    <?php do_settings_sections( 'media' ); ?>

    <?php submit_button(); ?>

    </form>

    </div>

    <?php
}



/**
 *  vergeml_medialibrary_options_page_scripts
 *
 *  @since    2.2.1
 *  @created  11/04/16
 */

function vergeml_medialibrary_options_page_scripts() {

    global $vergeml_dir;

    wp_enqueue_script(
        'vergeml-medialibrary-options-script',
        $vergeml_dir . 'js/eml-medialibrary-options.js',
        array( 'jquery' ),
        VERGEML_VERSION,
        true
    );

    vergeml_settings_accordion_script();
}


/**
 *  The one script the three settings screens share: which sections this
 *  person had open. Every section is printed closed, so the screen is short
 *  whether or not this loads.
 */
function vergeml_settings_accordion_script() {

    global $vergeml_dir;

    wp_enqueue_script(
        'vergeml-settings',
        $vergeml_dir . 'js/vergeml-settings.js',
        array(),
        function_exists( 'vergeml_asset_ver' ) ? vergeml_asset_ver( 'js/vergeml-settings.js' ) : VERGEML_VERSION,
        true
    );
}



/**
 *  vergeml_taxonomies_options_page_scripts
 *
 *  @since    2.2
 *  @created  08/03/16
 */

function vergeml_taxonomies_options_page_scripts() {

    global $vergeml_dir;

    vergeml_settings_accordion_script();

    wp_enqueue_script(
        'vergeml-taxonomies-options-script'
        // $vergeml_dir . 'js/eml-taxonomies-options.js',
        // array( 'jquery', 'underscore', 'vergeml-admin-script' ),
        // VERGEML_VERSION,
        // true
    );

    $l10n_data = array(
        'edit' => __( 'Edit', 'vergelabs-media-library' ),
        'close' => __( 'Close', 'vergelabs-media-library' ),
        'view' => __( 'View', 'vergelabs-media-library' ),
        'update' => __( 'Update', 'vergelabs-media-library' ),
        'add_new' => __( 'Add New', 'vergelabs-media-library' ),
        'new' => __( 'New', 'vergelabs-media-library' ),
        'name' => __( 'Name', 'vergelabs-media-library' ),
        'parent' => __( 'Parent', 'vergelabs-media-library' ),
        'all' => __( 'All', 'vergelabs-media-library' ),
        'search' => __( 'Search', 'vergelabs-media-library' ),

        'tax_new' => __( 'New Taxonomy', 'vergelabs-media-library' ),

        'tax_deletion_confirm_title' => __( 'Remove Taxonomy', 'vergelabs-media-library' ),
        'tax_deletion_confirm_text_p1' => '<p>' . __( 'The taxonomy is removed. Its files are not.', 'vergelabs-media-library' ) . '</p>',
        'tax_deletion_confirm_text_p2' => '<p>' . __( 'The terms stay in the database. A taxonomy made with the same name later gets them back.', 'vergelabs-media-library' ) . '</p>',
        'tax_deletion_confirm_text_p3' => '<p>' . __( 'Media items will remain intact.', 'vergelabs-media-library' ) . '</p>',
        // The button "Yes, remove taxonomy" is the confirmation; asking again
        // under three lines that already said it is a question nobody asked.
        'tax_deletion_confirm_text_p4' => '',
        'tax_deletion_yes' => __( 'Yes, remove taxonomy', 'vergelabs-media-library' ),

        'tax_error_duplicate_title' => __( 'Duplicate', 'vergelabs-media-library' ),
        'tax_error_duplicate_text' => __( 'A taxonomy with that name exists. Choose another.', 'vergelabs-media-library' ),

        'tax_error_empty_fileds_title' => __( 'Empty Fields', 'vergelabs-media-library' ),
        'tax_error_wrong_taxname_title' => __( 'Wrong Taxonomy Name', 'vergelabs-media-library' ),
        'tax_error_wrong_slug_title' => __( 'Wrong Slug', 'vergelabs-media-library' ),

        'tax_error_empty_both' => __( 'Every new taxonomy needs a singular and a plural name.', 'vergelabs-media-library' ),
        'tax_error_empty_singular' => __( 'Every new taxonomy needs a singular name.', 'vergelabs-media-library' ),
        'tax_error_empty_plural' => __( 'Every new taxonomy needs a plural name.', 'vergelabs-media-library' ),

        'tax_error_empty_taxname' => __( 'A taxonomy needs a name. Type one if it was not made from the singular name.', 'vergelabs-media-library' ),
        'tax_error_wrong_taxname' => __( 'Taxonomy Name should only contain lowercase Latin letters, the underscore character ( _ ), and be 3-32 characters long.', 'vergelabs-media-library' ),
        'tax_error_wrong_slug' => __( 'Slug should only contain lowercase Latin letters, numbers, underscore ( _ ) or hyphen ( - ) characters.', 'vergelabs-media-library' ),

        'okay' => __( 'Ok', 'vergelabs-media-library' ),
        'cancel' => __( 'Cancel', 'vergelabs-media-library' ),

        'sync_warning_title' => __( 'Synchronize Now', 'vergelabs-media-library' ),
        'sync_warning_text' => __( 'This cannot be undone.', 'vergelabs-media-library' ),
        'sync_warning_yes' => __( 'Synchronize', 'vergelabs-media-library' ),
        'sync_warning_no' => __( 'Cancel', 'vergelabs-media-library' ),
        'in_progress_sync_text' => __( 'Synchronizing...', 'vergelabs-media-library' ),

        'bulk_edit_nonce' => wp_create_nonce( 'eml-bulk-edit-nonce' )
    );

    wp_localize_script(
        'vergeml-taxonomies-options-script',
        'vergeml_taxonomies_options_l10n_data',
        $l10n_data
    );
}



/**
 *  vergeml_mimetype_options_page_scripts
 *
 *  @since    2.2
 *  @created  08/03/16
 */

function vergeml_mimetype_options_page_scripts() {

    global $vergeml_dir;

    vergeml_settings_accordion_script();

    wp_enqueue_script(
        'vergeml-mimetype-options-script',
        $vergeml_dir . 'js/eml-mimetype-options.js',
        array( 'jquery', 'underscore' ),
        VERGEML_VERSION,
        true
    );

    $l10n_data = array(
        'mime_restoring_confirm_title' => __( 'Restore WordPress default MIME Types', 'vergelabs-media-library' ),
        'mime_restoring_confirm_text' => __( 'Warning! All your custom MIME Types will be deleted by this operation.', 'vergelabs-media-library' ),
        'mime_restoring_yes' => __( 'Restore Defaults', 'vergelabs-media-library' ),
        'in_progress_restoring_text' => __( 'Restoring...', 'vergelabs-media-library' ),

        'okay' => __( 'Ok', 'vergelabs-media-library' ),
        'cancel' => __( 'Cancel', 'vergelabs-media-library' ),

        'mime_error_cannot_save_title' => __( 'MIME Types cannot be saved', 'vergelabs-media-library' ),
        'mime_error_empty_fields' => __( 'Every column needs a value.', 'vergelabs-media-library' ),
        'mime_error_duplicate' => __( 'That extension or MIME type is already listed.', 'vergelabs-media-library' )
    );

    wp_localize_script(
        'vergeml-mimetype-options-script',
        'vergeml_mimetype_options_l10n_data',
        $l10n_data
    );
}



/**
 *  vergeml_options_page_scripts
 *
 *  @since    2.2
 *  @created  08/03/16
 */

function vergeml_options_page_scripts() {

    global $vergeml_dir;


    wp_enqueue_script(
        'vergeml-options-script',
        $vergeml_dir . 'js/eml-options.js',
        array( 'jquery', 'underscore', 'vergeml-admin-script' ),
        VERGEML_VERSION,
        true
    );

    $l10n_data = array(
        'cleanup_warning_title' => __( 'Complete Cleanup', 'vergelabs-media-library' ),
        'cleanup_warning_text_p1' => '<p>' . __( 'You are about to <strong style="text-transform:uppercase">delete all plugin data</strong> from the database including backups.', 'vergelabs-media-library' ) . '</p>',
        'cleanup_warning_text_p2' => '<p>' . __( 'This cannot be undone.', 'vergelabs-media-library') . '</p>',
        'cleanup_warning_yes' => __( 'Yes, delete all data', 'vergelabs-media-library' ),
        'in_progress_cleanup_text' => __( 'Cleaning...', 'vergelabs-media-library' ),
        'cancel' => __( 'Cancel', 'vergelabs-media-library' ),

        'apply_to_network_nonce' => wp_create_nonce( 'eml-apply-to-network-nonce' ),
        'applying_settings_title' => __( 'Unify Media Settings over Network', 'vergelabs-media-library' ),
        'applying_media_library_settings_text' => sprintf(
            /* translators: %s: the emphasised phrase "will be overwritten" */
            __( 'ALL Media Library Settings on the Network %s with the settings of the main website.', 'vergelabs-media-library' ),
            '<strong style="text-transform:uppercase">' . esc_html__( 'will be overwritten', 'vergelabs-media-library' ) . '</strong>'
        ),
        'applying_media_taxonomies_settings_text' => sprintf(
            /* translators: %s: the emphasised phrase "will be overwritten" */
            __( 'ALL Media Taxonomies Settings on the Network %s with the settings of the main website. If your websites have individual taxonomies registered, they will be overwritten with the taxonomies from the main website.', 'vergelabs-media-library' ),
            '<strong style="text-transform:uppercase">' . esc_html__( 'will be overwritten', 'vergelabs-media-library' ) . '</strong>'
        ),
        'applying_mime_types_settings_text' => sprintf(
            /* translators: %s: the emphasised phrase "will be overwritten" */
            __( 'ALL MIME Types Settings on the Network %s with the settings of the main website.', 'vergelabs-media-library' ),
            '<strong style="text-transform:uppercase">' . esc_html__( 'will be overwritten', 'vergelabs-media-library' ) . '</strong>'
        ),
        'applying_settings_yes' => __( 'Apply', 'vergelabs-media-library' ),
        'in_progress_apply_setings_text' => __( 'Applying Settings...', 'vergelabs-media-library' )
    );

    wp_localize_script(
        'vergeml-options-script',
        'vergeml_options_l10n_data',
        $l10n_data
    );
}



/**
 *  vergeml_print_settings
 *
 *  @since    2.1
 *  @created  25/10/15
 */

function vergeml_print_settings() {

    if ( ! current_user_can( 'manage_options' ) )
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );


    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'utilities' ) )
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );
    } ?>


    <div id="vergeml-global-options-wrap" class="wrap eml-options">

        <h2><?php esc_html_e( 'VergeLabs Media Library Utilities', 'vergelabs-media-library' ); ?></h2>

        <div id="poststuff">

            <div id="post-body" class="metabox-holder columns-2">

                <div id="postbox-container-2" class="postbox-container">

                    <div class="postbox">

                        <h3 class="hndle"><?php esc_html_e( 'Export', 'vergelabs-media-library' ); ?></h3>

                        <div class="inside">

                            <ul>
                                <li><strong><?php esc_html_e( 'Plugin settings to export:', 'vergelabs-media-library' ); ?></strong></li>
                                <li><?php esc_html_e( 'Settings > Media Library', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'Settings > Media Taxonomies', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'Settings > MIME Types', 'vergelabs-media-library' ); ?></li>
                            </ul>


                            <p><?php esc_html_e( 'Use generated JSON file to import the configuration into another website.', 'vergelabs-media-library' ); ?></p>

                            <form method="post">
                                <input type='hidden' name='eml-settings-export' />
                                <?php wp_nonce_field( 'eml_settings_export_nonce', 'eml-settings-export-nonce' ); ?>
                                <?php submit_button( __( 'Export Plugin Settings', 'vergelabs-media-library' ), 'primary', 'eml-submit-settings-export', true ); ?>
                            </form>

                        </div>

                    </div>


                    <div class="postbox">

                        <h3 class="hndle"><?php esc_html_e( 'Import', 'vergelabs-media-library' ); ?></h3>

                        <div class="inside">

                            <ul>
                                <li><strong><?php esc_html_e( 'Plugin settings to import:', 'vergelabs-media-library' ); ?></strong></li>
                                <li><?php esc_html_e( 'Settings > Media Library', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'Settings > Media Taxonomies', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'Settings > MIME Types', 'vergelabs-media-library' ); ?></li>
                            </ul>

                            <p><?php esc_html_e( 'Plugin settings will be imported from a configuration JSON file which can be obtained by exporting the settings on another website using the export button above.', 'vergelabs-media-library' ); ?></p>
                            <p><?php esc_html_e( 'All plugin settings will be overridden by the import. You will have a chance to restore current data from an automatic backup in case you are not satisfied with the result of the import.', 'vergelabs-media-library' ); ?></p>

                            <form method="post" enctype="multipart/form-data">
                                <p><input type="file" name="import_file"/></p>
                                <input type='hidden' name='eml-settings-import' />
                                <?php wp_nonce_field( 'eml_settings_import_nonce', 'eml-settings-import-nonce' ); ?>
                                <?php submit_button(  __( 'Import Plugin Settings', 'vergelabs-media-library' ), 'primary', 'eml-submit-settings-import' ); ?>
                            </form>

                        </div>

                    </div>


                    <?php $vergeml_backup = get_option( 'vergeml_backup' ); ?>

                    <div class="postbox">

                        <h3 class="hndle"><?php esc_html_e( 'Restore', 'vergelabs-media-library' ); ?></h3>

                        <div class="inside">

                            <?php if ( empty( $vergeml_backup ) ) : ?>

                                <p><?php esc_html_e( 'No backup available at the moment.', 'vergelabs-media-library' ); ?></p>

                                <p><?php esc_html_e( 'Backup will be created automatically before any import operation.', 'vergelabs-media-library' ); ?></p>

                            <?php else : ?>

                                <p><?php esc_html_e( 'The backup has been automatically created before the latest import operation.', 'vergelabs-media-library' ); ?></p>

                                <ul>
                                    <li><strong><?php esc_html_e( 'Plugin settings to restore:', 'vergelabs-media-library' ); ?></strong></li>
                                    <li><?php esc_html_e( 'Settings > Media Library', 'vergelabs-media-library' ); ?></li>
                                    <li><?php esc_html_e( 'Settings > Media Taxonomies', 'vergelabs-media-library' ); ?></li>
                                    <li><?php esc_html_e( 'Settings > MIME Types', 'vergelabs-media-library' ); ?></li>
                                </ul>

                                <form method="post">
                                    <input type='hidden' name='eml-settings-restore' />
                                    <?php wp_nonce_field( 'eml_settings_restore_nonce', 'eml-settings-restore-nonce' ); ?>
                                    <?php submit_button( __( 'Restore Settings from the Backup', 'vergelabs-media-library' ), 'primary', 'eml-submit-settings-restore', true, array( 'id' => 'eml-submit-settings-restore' ) ); ?>
                                </form>

                            <?php endif; ?>


                        </div>

                    </div>


                    <?php if ( ! is_multisite() || is_network_admin() ) : ?>


                        <div class="postbox">

                            <h3 class="hndle"><?php esc_html_e( 'Complete Cleanup', 'vergelabs-media-library' ); ?></h3>

                            <div class="inside">

                                <?php $vergeml_taxonomies = vergeml_get_eml_taxonomies(); ?>

                                <ul>
                                    <li><strong><?php esc_html_e( 'What will be deleted:', 'vergelabs-media-library' ); ?></strong></li>
                                    <?php foreach( (array) $vergeml_taxonomies as $taxonomy => $params ) : ?>
                                        <li><?php esc_html_e( 'All', 'vergelabs-media-library' );
                                        echo ' ' . esc_html( $params['labels']['name'] ); ?></li>
                                    <?php endforeach; ?>
                                    <li><?php esc_html_e( 'All plugin options', 'vergelabs-media-library' ); ?></li>
                                    <li><?php esc_html_e( 'All plugin backups stored in the database', 'vergelabs-media-library' ); ?></li>
                                </ul>

                                <ul>
                                    <li><strong><?php esc_html_e( 'What will remain intact:', 'vergelabs-media-library' ); ?></strong></li>
                                    <li><?php esc_html_e( 'All media items', 'vergelabs-media-library' ); ?></li>
                                    <li><?php esc_html_e( 'All taxonomies not listed above', 'vergelabs-media-library' ); ?></li>
                                </ul>

                                <p><?php esc_html_e( 'The plugin cannot delete itself for security reasons. Please delete it manually from the plugin list after the cleanup is complete.', 'vergelabs-media-library' ); ?></p>

                                <p><strong style="color:red;"><?php esc_html_e( 'If you are not sure about this operation it\'s HIGHLY RECOMMENDED to create a backup of your database prior to cleanup!', 'vergelabs-media-library' ); ?></strong></p>

                                <form id="eml-form-cleanup" method="post">
                                    <input type='hidden' name='eml-settings-cleanup' />
                                    <?php wp_nonce_field( 'eml_settings_cleanup_nonce', 'eml-settings-cleanup-nonce' ); ?>
                                    <?php submit_button( __( 'Delete All Data & Deactivate', 'vergelabs-media-library' ), 'primary', 'eml-submit-settings-cleanup', true ); ?>
                                </form>

                                <hr />

                                <p><strong><?php esc_html_e( 'When the plugin is deleted from the Plugins screen', 'vergelabs-media-library' ); ?></strong></p>

                                <p><?php esc_html_e( 'By default, deleting the plugin keeps your folders and AI descriptions: the folders live in WordPress\'s own tables, and a reinstall -- or another folder plugin reading the same taxonomy -- picks them up exactly as you left them. Only caches and scheduled tasks are removed.', 'vergelabs-media-library' ); ?></p>

                                <form method="post">
                                    <p>
                                        <label>
                                            <input type="checkbox" name="vergeml_uninstall_wipe" value="1" <?php checked( (bool) get_option( 'vergeml_uninstall_wipe' ) ); ?> />
                                            <?php esc_html_e( 'Also remove all folders, settings and the AI index when the plugin is deleted', 'vergelabs-media-library' ); ?>
                                        </label>
                                    </p>
                                    <?php wp_nonce_field( 'vergeml_uninstall_wipe_nonce', 'vergeml-uninstall-wipe-nonce' ); ?>
                                    <?php submit_button( __( 'Save', 'vergelabs-media-library' ), 'secondary', 'vergeml-submit-uninstall-wipe', true ); ?>
                                </form>

                            </div>

                        </div>

                        <?php do_action( 'vergeml_extend_settings_page' ); ?>

                    <?php endif; ?>

                    <?php vergeml_system_report_render(); ?>

                </div>

                <div id="postbox-container-1" class="postbox-container">

                    <?php vergeml_print_credits(); ?>

                </div>

            </div>

        </div>

    </div>

    <?php
}



/**
 *  vergeml_print_network_settings
 *
 *  @since    2.6
 *  @created  22/04/18
 */

function vergeml_print_network_settings() {

    if ( ! current_user_can( 'manage_network_options' ) )
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );


    settings_errors();

    $vergeml_network_options = get_site_option( 'vergeml_network_options', array() ); ?>


    <div id="vergeml-global-options-wrap" class="wrap eml-options">

        <h2><?php esc_html_e( 'VergeLabs Media Library Utilities', 'vergelabs-media-library' ); ?></h2>

        <div id="poststuff">

            <div id="post-body" class="metabox-holder columns-2">

                <div id="postbox-container-2" class="postbox-container">

                    <div class="postbox">

                        <h3 class="hndle" id="eml-license-key-section"><?php esc_html_e('Network Settings','vergelabs-media-library'); ?></h3>


                        <div class="inside">

                            <?php if ( ! is_plugin_active_for_network( vergeml_get_basename() ) ) : ?>

                                <p class="description"><?php esc_html_e( 'No settings available. The plugin is not network activated.', 'vergelabs-media-library' ); ?></p>

                            <?php else : ?>

                                <form method="post">

                                    <?php settings_fields( 'eml-network-settings' ); ?>

                                    <table class="form-table">

                                        <tr>
                                            <th scope="row"><?php esc_html_e('Media Settings per site','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'media_settings' ); } ?></th>
                                            <td>
                                                <fieldset>
                                                    <legend class="screen-reader-text"><span><?php esc_html_e('Enable Media Settings','vergelabs-media-library'); ?></span></legend>
                                                    <label><input name="vergeml_network_options[media_settings]" type="hidden" value="0" /><input name="vergeml_network_options[media_settings]" type="checkbox" value="1" <?php checked( true, vergeml_network_flag( 'media_settings' ), true ); ?> /> <?php esc_html_e('Allow an individual site admin to edit enhanced Media Settings','vergelabs-media-library'); ?></label>
</fieldset>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row"><?php esc_html_e('Plugin Utilities per site','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'utilities' ); } ?></th>
                                            <td>
                                                <fieldset>
                                                    <legend class="screen-reader-text"><span><?php esc_html_e('Enable plugin Utilities','vergelabs-media-library'); ?></span></legend>
                                                    <label><input name="vergeml_network_options[utilities]" type="hidden" value="0" /><input name="vergeml_network_options[utilities]" type="checkbox" value="1" <?php checked( true, vergeml_network_flag( 'utilities' ), true ); ?> /> <?php esc_html_e('Allow an individual site admin to import / export / restore plugin settings for their site','vergelabs-media-library'); ?></label>
</fieldset>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row"><?php esc_html_e('When the plugin is deleted','vergelabs-media-library'); ?></th>
                                            <td>
                                                <fieldset>
                                                    <legend class="screen-reader-text"><span><?php esc_html_e('Remove all data on uninstall','vergelabs-media-library'); ?></span></legend>
                                                    <label><input name="vergeml_network_options[uninstall_wipe]" type="hidden" value="0" /><input name="vergeml_network_options[uninstall_wipe]" type="checkbox" value="1" <?php checked( true, (bool) get_site_option( 'vergeml_uninstall_wipe_network' ), true ); ?> /> <?php esc_html_e('Remove every site\'s folders, settings and AI index when the plugin is deleted from the network. Off, deleting the plugin keeps them all — a reinstall picks them up.','vergelabs-media-library'); ?></label>
</fieldset>
                                            </td>
                                        </tr>

                                    </table>

                                    <?php submit_button( __( 'Save Changes', 'vergelabs-media-library' ), 'primary', 'eml-submit-network-settings', true ); ?>

                                </form>

                            <?php endif; ?>
                        </div>
                    </div>

                    <?php vergeml_print_network_licence_box(); ?>

                    <?php vergeml_print_network_overview(); ?>

                    <div class="postbox">

                        <h3 class="hndle"><?php esc_html_e('Unify Media Settings over Network','vergelabs-media-library'); ?></h3>


                        <div class="inside">

                            <?php if ( ! is_plugin_active_for_network( vergeml_get_basename() ) ) : ?>

                                <p class="description"><?php esc_html_e( 'No settings available. The plugin is not network activated.', 'vergelabs-media-library' ); ?></p>

                            <?php else : ?>

                                <form method="post">

                                    <table class="form-table">

                                        <tr>
                                            <th scope="row"><?php esc_html_e('Media Library Settings','vergelabs-media-library'); ?></th>
                                            <td>
                                                <fieldset>
                                                    <legend class="screen-reader-text"><span><?php esc_html_e('Media Library Settings','vergelabs-media-library'); ?></span></legend>
                                                    <a class="add-new-h2 vergeml-apply-settings-to-network" data-settings="media-library" href="javascript:;"><?php esc_html_e( 'Apply to ALL Network websites', 'vergelabs-media-library' ); ?></a>
                                                    <p class="description"><?php printf(
                                                        /* translators: %s: link to the Media Library settings page */
                                                        esc_html__( 'Main website %s settings will be applied to all websites on the Network.', 'vergelabs-media-library' ),
                                                        '<a href="' . esc_url( admin_url( 'options-general.php?page=media-library' ) ) . '" target="_blank">' . esc_html__( 'Media Library', 'vergelabs-media-library' ) . '</a>'
                                                    ); ?></p>
                                                </fieldset>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row"><?php esc_html_e('Media Taxonomies Settings','vergelabs-media-library'); ?></th>
                                            <td>
                                                <fieldset>
                                                    <legend class="screen-reader-text"><span><?php esc_html_e('Media Taxonomies Settings','vergelabs-media-library'); ?></span></legend>
                                                    <a class="add-new-h2 vergeml-apply-settings-to-network" data-settings="media-taxonomies" href="javascript:;"><?php esc_html_e( 'Apply to ALL Network websites', 'vergelabs-media-library' ); ?></a>
                                                    <p class="description"><?php printf(
                                                        /* translators: %s: link to the Media Taxonomies settings page */
                                                        esc_html__( 'Main website %s settings will be applied to all websites on the Network.', 'vergelabs-media-library' ),
                                                        '<a href="' . esc_url( admin_url( 'options-general.php?page=media-taxonomies' ) ) . '" target="_blank">' . esc_html__( 'Media Taxonomies', 'vergelabs-media-library' ) . '</a>'
                                                    ); ?></p>
                                                </fieldset>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row"><?php esc_html_e('MIME Types Settings','vergelabs-media-library'); ?></th>
                                            <td>
                                                <fieldset>
                                                    <legend class="screen-reader-text"><span><?php esc_html_e('MIME Types Settings','vergelabs-media-library'); ?></span></legend>
                                                    <a class="add-new-h2 vergeml-apply-settings-to-network" data-settings="mime-types" href="javascript:;"><?php esc_html_e( 'Apply to ALL Network websites', 'vergelabs-media-library' ); ?></a>
                                                    <p class="description"><?php printf(
                                                        /* translators: %s: link to the MIME Types settings page */
                                                        esc_html__( 'Main website %s settings will be applied to all websites on the Network.', 'vergelabs-media-library' ),
                                                        '<a href="' . esc_url( admin_url( 'options-general.php?page=mime-types' ) ) . '" target="_blank">' . esc_html__( 'MIME Types', 'vergelabs-media-library' ) . '</a>'
                                                    ); ?></p>
                                                </fieldset>
                                            </td>
                                        </tr>

                                    </table>

                                </form>

                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="postbox">

                        <h3 class="hndle"><?php esc_html_e( 'Complete Cleanup', 'vergelabs-media-library' ); ?></h3>

                        <div class="inside">

                            <?php
                            $vergeml_taxonomies = array();

                            foreach( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) :

                                switch_to_blog( $site_id );

                                $vergeml_taxonomies = array_merge( $vergeml_taxonomies, vergeml_get_eml_taxonomies() );

                                restore_current_blog();

                            endforeach; ?>


                            <ul>
                                <li><strong><?php esc_html_e( 'What will be deleted:', 'vergelabs-media-library' ); ?></strong></li>
                                <?php foreach( (array) $vergeml_taxonomies as $taxonomy => $params ) : ?>
                                    <li><?php esc_html_e( 'All', 'vergelabs-media-library' );
                                    echo ' ' . esc_html( $params['labels']['name'] ); ?></li>
                                <?php endforeach; ?>
                                <li><?php esc_html_e( 'All plugin options on every site', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'Network settings', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'All plugin backups stored in the database', 'vergelabs-media-library' ); ?></li>
                            </ul>

                            <ul>
                                <li><strong><?php esc_html_e( 'What will remain intact:', 'vergelabs-media-library' ); ?></strong></li>
                                <li><?php esc_html_e( 'All media items', 'vergelabs-media-library' ); ?></li>
                                <li><?php esc_html_e( 'All taxonomies not listed above', 'vergelabs-media-library' ); ?></li>
                            </ul>

                            <p><?php esc_html_e( 'The plugin cannot delete itself for security reasons. Please delete it manually from the plugin list after the cleanup is complete.', 'vergelabs-media-library' ); ?></p>

                            <p><strong style="color:red;"><?php esc_html_e( 'If you are not sure about this operation it\'s HIGHLY RECOMMENDED to create a backup of your database prior to cleanup!', 'vergelabs-media-library' ); ?></strong></p>

                            <form id="eml-form-cleanup" method="post">
                                <input type='hidden' name='eml-settings-cleanup' />
                                <?php wp_nonce_field( 'eml_settings_cleanup_nonce', 'eml-settings-cleanup-nonce' ); ?>
                                <?php submit_button( __( 'Delete All Data & Network Deactivate', 'vergelabs-media-library' ), 'primary', 'eml-submit-settings-cleanup', true ); ?>
                            </form>

                        </div>

                    </div>

                    <?php do_action( 'vergeml_extend_settings_page' ); ?>

                </div>

                <div id="postbox-container-1" class="postbox-container">

                    <?php vergeml_print_credits(); ?>

                </div>

            </div>

        </div>

    </div>

<?php
}



/**
 *  vergeml_apply_settings_to_network
 *
 *  @since    2.7
 *  @created  21/06/18
 */

add_action( 'wp_ajax_vergeml-apply-settings-to-network', 'vergeml_apply_settings_to_network' );

function vergeml_apply_settings_to_network() {

    if ( ! isset( $_REQUEST['settings'] ) )
        wp_send_json_error();

    check_ajax_referer( 'eml-apply-to-network-nonce', 'nonce' );

    /*
     *  This writes options into every site on the network, so it needs the
     *  capability that guards network settings, not just a valid nonce.
     *  Upstream relied on the nonce alone, which only held because the nonce
     *  is printed on a super-admin screen.
     *
     *  Gated on is_multisite() because a single site grants nobody
     *  manage_network_options, not even an administrator. Checking it
     *  unconditionally would reject the very users allowed to be here.
     */

    if ( is_multisite() && ! current_user_can( 'manage_network_options' ) )
        wp_send_json_error();


    $plugins = get_site_option( 'active_sitewide_plugins');

    if ( is_multisite() && isset($plugins[vergeml_get_basename()]) ) {

        switch_to_blog( get_main_site_id() );

        $vergeml_taxonomies = get_option( 'vergeml_taxonomies', array() );
        $vergeml_lib_options = get_option( 'vergeml_lib_options', array() );
        $vergeml_tax_options = get_option( 'vergeml_tax_options', array() );
        $vergeml_mimes = get_option( 'vergeml_mimes', array() );


        foreach( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) {

            switch_to_blog( $site_id );

            switch ( $_REQUEST['settings'] ) {
                case 'media-library':
                    update_option( 'vergeml_lib_options', $vergeml_lib_options );
                    break;

                case 'media-taxonomies':
                    update_option( 'vergeml_taxonomies', $vergeml_taxonomies );
                    update_option( 'vergeml_tax_options', $vergeml_tax_options );
                    break;

                case 'mime-types':
                    update_option( 'vergeml_mimes', $vergeml_mimes );
                    break;
            }

            restore_current_blog();
        }
    }

    wp_send_json_success();
}



/**
 *  vergeml_update_network_settings
 *
 *  @since    2.6
 *  @created  28/04/18
 */

/**
 *  vergeml_network_flag
 *
 *  One of the two network flags, with its default, whether or not the option
 *  exists. Eleven places read the option raw and indexed it without isset():
 *  on a network where the plugin was activated per site (so the option was
 *  never written) or after the save bug above had emptied it, that was an
 *  "undefined index" and a false -- and false meant "this site admin may not
 *  see the settings screen". Super admins short-circuit past the flag, which
 *  is exactly why nobody testing as one ever saw it.
 */
function vergeml_network_flag( $name ) {

    $defaults = array( 'media_settings' => 1, 'utilities' => 1 );
    $stored   = get_site_option( 'vergeml_network_options', array() );

    if ( is_array( $stored ) && array_key_exists( $name, $stored ) ) {
        return (bool) $stored[ $name ];
    }

    return isset( $defaults[ $name ] ) ? (bool) $defaults[ $name ] : false;
}


/* ------------------------------------------------ the network licence box */

/**
 *  vergeml_print_network_licence_box
 *
 *  One AI licence for the whole network. Sites inherit it unless they enter
 *  their own; locked, they cannot enter their own. Sealed the same way a
 *  site's key is (core/ai.php), so the network option holds no plaintext.
 */
function vergeml_print_network_licence_box() {

    if ( ! function_exists( 'vergeml_ai_seal' ) ) {
        return; // safe mode: the AI files are not loaded
    }

    $network = get_site_option( 'vergeml_ai_network', array() );
    $network = is_array( $network ) ? $network : array();
    $has_key = ! empty( $network['license_key'] ) && '' !== vergeml_ai_unseal( $network['license_key'] );
    ?>
    <div class="postbox">
        <h3 class="hndle"><?php esc_html_e( 'AI licence for the network', 'vergelabs-media-library' ); ?></h3>
        <div class="inside">
            <p class="description"><?php esc_html_e( 'Enter the licence once here and every site uses it. A site can still enter its own key unless you lock this one. Each site counts as one connected site on the licence.', 'vergelabs-media-library' ); ?></p>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="vgml-network-key"><?php esc_html_e( 'Licence key', 'vergelabs-media-library' ); ?></label></th>
                        <td>
                            <input type="text" id="vgml-network-key" name="vergeml_network_licence[key]" class="regular-text" value="" autocomplete="off"
                                placeholder="<?php echo esc_attr( $has_key ? '•••••••• (saved)' : 'VGML-…' ); ?>" />
                            <?php if ( $has_key ) : ?>
                                <p class="description"><label><input type="checkbox" name="vergeml_network_licence[clear]" value="1" /> <?php esc_html_e( 'Remove the network key. Sites fall back to their own, or to none.', 'vergelabs-media-library' ); ?></label></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Lock', 'vergelabs-media-library' ); ?></th>
                        <td>
                            <label><input type="hidden" name="vergeml_network_licence[lock]" value="0" /><input type="checkbox" name="vergeml_network_licence[lock]" value="1" <?php checked( ! empty( $network['lock'] ) ); ?> /> <?php esc_html_e( 'Sites use this key and cannot enter their own.', 'vergelabs-media-library' ); ?></label>
                        </td>
                    </tr>
                </table>
                <?php wp_nonce_field( 'vergeml_network_licence', 'vergeml-network-licence-nonce' ); ?>
                <?php submit_button( __( 'Save licence', 'vergelabs-media-library' ), 'primary', 'vergeml-submit-network-licence', true ); ?>
            </form>
        </div>
    </div>
    <?php
}


add_action( 'network_admin_menu', 'vergeml_update_network_licence' );

function vergeml_update_network_licence() {

    if ( ! isset( $_POST['vergeml-submit-network-licence'] ) )
        return;

    if ( ! isset( $_POST['vergeml-network-licence-nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vergeml-network-licence-nonce'] ) ), 'vergeml_network_licence' ) )
        return;

    if ( ! current_user_can( 'manage_network_options' ) || ! function_exists( 'vergeml_ai_seal' ) )
        return;

    $posted  = isset( $_POST['vergeml_network_licence'] ) ? map_deep( wp_unslash( (array) $_POST['vergeml_network_licence'] ), 'sanitize_text_field' ) : array();
    $network = get_site_option( 'vergeml_ai_network', array() );
    $network = is_array( $network ) ? $network : array();

    if ( ! empty( $posted['clear'] ) ) {
        $network['license_key'] = '';
    }
    elseif ( ! empty( $posted['key'] ) ) {
        $network['license_key'] = vergeml_ai_seal( (string) $posted['key'] );
    }

    $network['lock'] = empty( $posted['lock'] ) ? 0 : 1;

    update_site_option( 'vergeml_ai_network', $network );

    add_settings_error( 'eml-network-settings', 'vergeml_network_licence_saved', __( 'Network licence saved.', 'vergelabs-media-library' ), 'updated' );
}


/* --------------------------------------------------- the network overview */

/**
 *  vergeml_print_network_overview
 *
 *  What a network administrator could not see before: per site, which
 *  version it runs, whether its tables exist, whether it is in safe mode,
 *  where its AI key comes from, and its last credit snapshot. One walk of the
 *  network, held for five minutes; the first two hundred sites, and it says
 *  when there are more.
 */
function vergeml_print_network_overview() {

    // A stale bookmarked refresh link should show the page, not a nonce error.
    $refresh = isset( $_GET['vergeml_refresh'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'vergeml_refresh' );
    $rows    = $refresh ? false : get_site_transient( 'vergeml_network_overview' );

    if ( ! is_array( $rows ) ) {

        global $wpdb;

        $rows  = array();
        $sites = get_sites( array( 'fields' => 'ids', 'number' => 201 ) );

        foreach ( array_slice( $sites, 0, 200 ) as $site_id ) {

            switch_to_blog( (int) $site_id );

            $ai       = get_option( 'vergeml_ai', array() );
            $credits  = function_exists( 'vergeml_ai_refresh_credits' )
                ? array( 'remaining' => vergeml_ai_refresh_credits() )
                : get_option( 'vergeml_ai_credits', array() );
            $watchdog = get_option( 'vergeml_watchdog', array() );
            $network  = get_site_option( 'vergeml_ai_network', array() );

            $own_key = is_array( $ai ) && ! empty( $ai['license_key'] );
            $net_key = is_array( $network ) && ! empty( $network['license_key'] );

            $rows[] = array(
                'id'      => (int) $site_id,
                'name'    => get_option( 'blogname' ),
                'url'     => get_admin_url( (int) $site_id, 'admin.php?page=vergelabs-media' ),
                'version' => (string) get_option( 'vergeml_version', '' ),
                'tables'  => (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->prefix . 'vergeml_ai_index' ) ), // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                'safe'    => is_array( $watchdog ) && ! empty( $watchdog['safe'] ),
                'key'     => $own_key && ! ( $net_key && ! empty( $network['lock'] ) ) ? 'own' : ( $net_key ? 'network' : 'none' ),
                'credits' => is_array( $credits ) && isset( $credits['remaining'] ) ? (int) $credits['remaining'] : null,
            );

            restore_current_blog();
        }

        $rows = array( 'sites' => $rows, 'more' => count( $sites ) > 200, 'at' => time() );

        set_site_transient( 'vergeml_network_overview', $rows, 5 * MINUTE_IN_SECONDS );
    }

    $refresh_url = wp_nonce_url( add_query_arg( 'vergeml_refresh', '1' ), 'vergeml_refresh' );
    ?>
    <div class="postbox">
        <h3 class="hndle"><?php esc_html_e( 'Sites on this network', 'vergelabs-media-library' ); ?></h3>
        <div class="inside">
            <p class="description">
                <?php
                printf(
                    /* translators: %s: how long ago the list was gathered. */
                    esc_html__( 'Gathered %s ago.', 'vergelabs-media-library' ),
                    esc_html( human_time_diff( (int) $rows['at'] ) )
                );
                ?>
                <a href="<?php echo esc_url( $refresh_url ); ?>"><?php esc_html_e( 'Refresh', 'vergelabs-media-library' ); ?></a>
                <?php if ( ! empty( $rows['more'] ) ) : ?>
                    &mdash; <?php esc_html_e( 'the first two hundred sites are shown.', 'vergelabs-media-library' ); ?>
                <?php endif; ?>
            </p>
            <table class="widefat striped">
                <thead><tr>
                    <th><?php esc_html_e( 'Site', 'vergelabs-media-library' ); ?></th>
                    <th><?php esc_html_e( 'Version', 'vergelabs-media-library' ); ?></th>
                    <th><?php esc_html_e( 'Tables', 'vergelabs-media-library' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'vergelabs-media-library' ); ?></th>
                    <th><?php esc_html_e( 'AI key', 'vergelabs-media-library' ); ?></th>
                    <th><?php esc_html_e( 'Credits seen', 'vergelabs-media-library' ); ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ( $rows['sites'] as $r ) : ?>
                    <tr>
                        <td><a href="<?php echo esc_url( $r['url'] ); ?>"><?php echo esc_html( $r['name'] ); ?></a> <span class="description">#<?php echo (int) $r['id']; ?></span></td>
                        <td><?php echo '' !== $r['version'] ? esc_html( $r['version'] ) : '<em>' . esc_html__( 'not yet set up', 'vergelabs-media-library' ) . '</em>'; ?></td>
                        <td><?php echo $r['tables'] ? esc_html__( 'present', 'vergelabs-media-library' ) : '<strong>' . esc_html__( 'missing', 'vergelabs-media-library' ) . '</strong>'; ?></td>
                        <td><?php echo $r['safe'] ? '<strong>' . esc_html__( 'safe mode', 'vergelabs-media-library' ) . '</strong>' : esc_html__( 'running', 'vergelabs-media-library' ); ?></td>
                        <td><?php echo esc_html( 'own' === $r['key'] ? __( 'its own', 'vergelabs-media-library' ) : ( 'network' === $r['key'] ? __( 'network', 'vergelabs-media-library' ) : __( 'none', 'vergelabs-media-library' ) ) ); ?></td>
                        <td><?php echo null === $r['credits'] ? '&mdash;' : esc_html( number_format_i18n( $r['credits'] ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}


add_action( 'network_admin_menu', 'vergeml_update_network_settings' );

function vergeml_update_network_settings() {

    if ( ! isset($_POST['eml-submit-network-settings']) )
        return;

    check_admin_referer( 'eml-network-settings-options' );

    if ( ! current_user_can( 'manage_network_options' ) )
        return;


    $posted = isset( $_POST['vergeml_network_options'] )
        ? map_deep( wp_unslash( (array) $_POST['vergeml_network_options'] ), 'sanitize_text_field' )
        : array();

    /*
     *  Two flags, each 0 or 1, and nothing else. This used to run the posted
     *  array through vergeml_tax_options_validate(), which -- seeing no
     *  vergeml_tax_options in the POST -- returned the main site's taxonomy
     *  options instead. Every save of this screen overwrote the network option
     *  with the wrong array, both flags vanished, and every site administrator
     *  on the network lost Settings > Media and Utilities until a super admin
     *  happened to notice.
     */
    $vergeml_network_options = array(
        'media_settings' => empty( $posted['media_settings'] ) ? 0 : 1,
        'utilities'      => empty( $posted['utilities'] ) ? 0 : 1,
    );

    update_site_option( 'vergeml_network_options', $vergeml_network_options );

    // Its own option, read by uninstall.php, which runs without this file.
    update_site_option( 'vergeml_uninstall_wipe_network', empty( $posted['uninstall_wipe'] ) ? 0 : 1 );

    add_settings_error(
        'eml-network-settings',
        'eml_network_settings_saved',
        __('Network settings saved.', 'vergelabs-media-library'),
        'updated'
    );
}



/**
 *  vergeml_settings_export
 *
 *  @since    2.1
 *  @created  25/10/15
 */

add_action( 'admin_init', 'vergeml_settings_export' );

function vergeml_settings_export() {

    if ( ! isset( $_POST['eml-settings-export'] ) )
        return;

    if ( ! isset( $_POST['eml-settings-export-nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['eml-settings-export-nonce'] ) ), 'eml_settings_export_nonce' ) )
        return;

    if ( ! current_user_can( 'manage_options' ) )
        return;

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'utilities' ) )
            return;
    }


    $settings = vergeml_get_settings();

    ignore_user_abort( true );

    nocache_headers();
    header( 'Content-Type: application/json; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=vergeml-settings-' . gmdate( 'm-d-Y_hia' ) . '.json' );
    header( "Expires: 0" );

    echo json_encode( $settings );

    exit;
}



/**
 *  vergeml_settings_import
 *
 *  @since    2.1
 *  @created  25/10/15
 */

add_action( 'admin_init', 'vergeml_settings_import' );

function vergeml_settings_import() {

    if ( ! isset( $_POST['eml-settings-import'] ) )
        return;

    if ( ! isset( $_POST['eml-settings-import-nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['eml-settings-import-nonce'] ) ), 'eml_settings_import_nonce' ) )
        return;

    if ( ! current_user_can( 'manage_options' ) )
        return;

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'utilities' ) )
            return;
    }


    /*
     *  Only tmp_name is read, and only when PHP says it is this request's own
     *  upload -- is_uploaded_file() below. Anything else in tmp_name is
     *  treated as no file at all, so the read can never follow a path that
     *  arrived some other way. The name is sanitised so nothing from the
     *  upload reaches the filesystem or a message unchecked.
     */

    $import_file = array(
        'name'     => isset( $_FILES['import_file']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['import_file']['name'] ) ) : '',
        'type'     => isset( $_FILES['import_file']['type'] ) ? sanitize_mime_type( wp_unslash( $_FILES['import_file']['type'] ) ) : '',
        'tmp_name' => isset( $_FILES['import_file']['tmp_name'] ) ? sanitize_text_field( wp_unslash( $_FILES['import_file']['tmp_name'] ) ) : '',
        'error'    => isset( $_FILES['import_file']['error'] ) ? (int) $_FILES['import_file']['error'] : UPLOAD_ERR_NO_FILE,
        'size'     => isset( $_FILES['import_file']['size'] ) ? (int) $_FILES['import_file']['size'] : 0,
    );

    if ( empty( $import_file['tmp_name'] ) || ! is_uploaded_file( $import_file['tmp_name'] ) ) {

        add_settings_error(
            'eml-settings',
            'eml_settings_file_absent',
            __('Settings cannot be imported. Please upload a file to import settings.', 'vergelabs-media-library'),
            'error'
        );

        return;
    }


    // backup settings
    $settings = vergeml_get_settings();
    update_option( 'vergeml_backup', $settings );


    $json_data = file_get_contents( $import_file['tmp_name'] );
    $settings = json_decode( $json_data, true );

    if ( empty( $settings ) ) {

        add_settings_error(
            'eml-settings',
            'eml_settings_wrong_format',
            __('Settings cannot be imported. Please upload a correct JSON file to import settings.', 'vergelabs-media-library'),
            'error'
        );

        return;
    }


    update_option( 'vergeml_taxonomies', $settings['taxonomies'] );
    update_option( 'vergeml_lib_options', $settings['lib_options'] );
    update_option( 'vergeml_tax_options', $settings['tax_options'] );
    update_option( 'vergeml_mimes', $settings['mimes'] );

    add_settings_error(
        'eml-settings',
        'eml_settings_imported',
        __('Plugin settings imported.', 'vergelabs-media-library'),
        'updated'
    );
}



/**
 *  vergeml_settings_restoring
 *
 *  @since    2.1
 *  @created  25/10/15
 */

add_action( 'admin_init', 'vergeml_settings_restoring' );

function vergeml_settings_restoring() {

    if ( ! isset( $_POST['eml-settings-restore'] ) )
        return;

    if ( ! isset( $_POST['eml-settings-restore-nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['eml-settings-restore-nonce'] ) ), 'eml_settings_restore_nonce' ) )
        return;

    if ( ! current_user_can( 'manage_options' ) )
        return;

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'utilities' ) )
            return;
    }


    $vergeml_backup = get_option( 'vergeml_backup' );

    update_option( 'vergeml_taxonomies', $vergeml_backup['taxonomies'] );
    update_option( 'vergeml_lib_options', $vergeml_backup['lib_options'] );
    update_option( 'vergeml_tax_options', $vergeml_backup['tax_options'] );
    update_option( 'vergeml_mimes', $vergeml_backup['mimes'] );

    do_action( 'vergeml_pro_set_settings', $vergeml_backup );

    update_option( 'vergeml_backup', '' );

    add_settings_error(
        'eml-settings',
        'eml_settings_restored',
        __('Plugin settings restored from the backup.', 'vergelabs-media-library'),
        'updated'
    );
}



/**
 *  vergeml_settings_cleanup
 *
 *  @since    2.2
 *  @created  23/02/16
 */

add_action( 'admin_init', 'vergeml_uninstall_wipe_save' );

function vergeml_uninstall_wipe_save() {

    if ( ! isset( $_POST['vergeml-submit-uninstall-wipe'] ) )
        return;

    if ( ! isset( $_POST['vergeml-uninstall-wipe-nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vergeml-uninstall-wipe-nonce'] ) ), 'vergeml_uninstall_wipe_nonce' ) )
        return;

    if ( ! current_user_can( 'manage_options' ) )
        return;

    update_option( 'vergeml_uninstall_wipe', isset( $_POST['vergeml_uninstall_wipe'] ) ? '1' : '0' );

    add_settings_error(
        'eml-settings',
        'vergeml_uninstall_wipe_saved',
        __( 'Saved.', 'vergelabs-media-library' ),
        'updated'
    );
}


add_action( 'admin_init', 'vergeml_settings_cleanup' );

function vergeml_settings_cleanup() {

    if ( ! isset( $_POST['eml-settings-cleanup'] ) )
        return;

    if ( ! isset( $_POST['eml-settings-cleanup-nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['eml-settings-cleanup-nonce'] ) ), 'eml_settings_cleanup_nonce' ) )
        return;

    if ( ! current_user_can( 'manage_options' ) )
        return;

    /*
     *  On a network this wipes every site, so it is a network administrator's
     *  action -- not a site administrator's, whatever the utilities flag says.
     *  The box was already hidden on subsites; the handler was not gated, and
     *  a hidden button is not a permission.
     */
    if ( is_multisite() && ! current_user_can( 'manage_network_options' ) )
        return;


    $one_site = function () {
        vergeml_term_relationship_cleanup();
        vergeml_options_cleanup();
        vergeml_transients_cleanup();
        vergeml_cleanup_drop_tables();
        wp_clear_scheduled_hook( 'vergeml_meaning_convert' );
        wp_clear_scheduled_hook( 'vergeml_ai_run_tick' );
    };

    if ( is_multisite() ) {

        // Everything per site runs inside the switch: the tables, the
        // transients and the cron are all prefixed by the site they belong to.
        foreach( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) {
            switch_to_blog( $site_id );
            $one_site();
            restore_current_blog();
        }
    }
    else {
        $one_site();
    }

    // we need this one because of = vs LIKE in the DB query
    vergeml_user_meta_cleanup();

    vergeml_site_options_cleanup();
    deactivate_plugins( vergeml_get_basename(), false, is_multisite() );


    wp_safe_redirect( self_admin_url( 'plugins.php' ) );
    exit;
}



/**
 *  vergeml_term_relationship_cleanup
 *
 *  @since    2.6
 *  @created  28/04/18
 */

/*
 *  Deletes this plugin's taxonomies and their attachment relationships in bulk.
 *  There is no core call that removes term relationships for one post type
 *  only, and doing it through wp_remove_object_terms() would be one query per
 *  attachment per term, which on a large library is tens of thousands of
 *  queries. Table names are $wpdb's, every value is placeheld, and the caches
 *  that matter are cleaned by the core hooks fired around the delete.
 */

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter

function vergeml_term_relationship_cleanup() {

    global $wpdb;


    foreach ( get_option( 'vergeml_taxonomies', array() ) as $taxonomy => $params ) {

        $terms = get_terms( array( 'taxonomy' => $taxonomy, 'fields' => 'all', 'get' => 'all' ) );
        $term_pairs = vergeml_get_media_term_pairs( $terms, 'id=>tt_id' );

        if ( (bool) $params['eml_media'] ) {

            foreach ( $term_pairs as $id => $tt_id ) {
                wp_delete_term( $id, $taxonomy );
            }

            $wpdb->delete( $wpdb->term_taxonomy, array( 'taxonomy' => $taxonomy ), array( '%s' ) );
            delete_option( $taxonomy . '_children' );
        }
        elseif ( ! empty( $term_pairs ) ) {

            $deleted_tt_ids = array();
            $rows2remove_format = join( ', ', array_fill( 0, count( $term_pairs ), '%d' ) );

            $results = $wpdb->get_results( $wpdb->prepare(
                "
                    SELECT $wpdb->term_relationships.term_taxonomy_id, $wpdb->term_relationships.object_id
                    FROM $wpdb->term_relationships
                    INNER JOIN $wpdb->posts
                    ON $wpdb->term_relationships.object_id = $wpdb->posts.ID
                    WHERE $wpdb->posts.post_type = 'attachment'
                    AND $wpdb->term_relationships.term_taxonomy_id IN ($rows2remove_format)
                ",
                $term_pairs
            ) );

            foreach ( $results as $result ) {
                $deleted_tt_ids[$result->object_id][] = $result->term_taxonomy_id;
            }

            foreach( $deleted_tt_ids as $attachment_id => $tt_ids ) {
                // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core hook; other plugins and core caches rely on it firing.
                do_action( 'delete_term_relationships', $attachment_id, $tt_ids );
            }

            $removed = $wpdb->query( $wpdb->prepare(
                "
                    DELETE $wpdb->term_relationships.* FROM $wpdb->term_relationships
                    INNER JOIN $wpdb->posts
                    ON $wpdb->term_relationships.object_id = $wpdb->posts.ID
                    WHERE $wpdb->posts.post_type = 'attachment'
                    AND $wpdb->term_relationships.term_taxonomy_id IN ($rows2remove_format)
                ",
                $term_pairs
            ) );

            if ( false !== $removed ) {

                foreach( $deleted_tt_ids as $attachment_id => $tt_ids ) {
                    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core hook; other plugins and core caches rely on it firing.
                    do_action( 'deleted_term_relationships', $attachment_id, $tt_ids );
                }
            }
        }
    }
}



/**
 *  vergeml_user_meta_cleanup
 *
 *  @since    2.8.10
 *  @created  2024/04
 */

/**
 *  vergeml_cleanup_drop_tables
 *
 *  This plugin's four tables for the current site. Prefixed by $wpdb, so
 *  inside switch_to_blog() it drops the right site's. Complete Cleanup used
 *  to drop one of the four, on one site.
 */
function vergeml_cleanup_drop_tables() {

    global $wpdb;

    foreach ( array( 'vergeml_ai_index', 'vergeml_librarian_batches', 'vergeml_librarian_moves', 'vergeml_organize_runs' ) as $table ) {
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- deliberate removal of this plugin's own tables.
    }
}


function vergeml_user_meta_cleanup() {

    global $wpdb;

    $meta_key  = 'vergeml_';
    $id_column = 'umeta_id';
    $table     = _get_meta_table( 'user' );


    /*
     *  $table and $id_column are internal constants from _get_meta_table(), not
     *  user input, so they are interpolated. Every value is placeheld. There is
     *  no cache to prime or invalidate here: this runs once, from the settings
     *  cleanup action, over rows this plugin owns.
     */

    // Both shapes: the plain key, and on a network the per-site copy that
    // carries the blog prefix (wp_2_vergeml_...).
    $meta_ids = $wpdb->get_col(
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- identifiers are internal, values are placeheld below.
        $wpdb->prepare( "SELECT $id_column FROM $table WHERE meta_key LIKE %s OR meta_key LIKE %s",
            $wpdb->esc_like( $meta_key ) . '%',
            $wpdb->esc_like( $wpdb->base_prefix ) . '%' . $wpdb->esc_like( '_' . $meta_key ) . '%' )
    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off cleanup of this plugin's own user meta.


    if ( ! count( $meta_ids ) ) {
        return;
    }

    $meta_ids     = array_map( 'absint', $meta_ids );
    $placeholders = implode( ',', array_fill( 0, count( $meta_ids ), '%d' ) );

    $wpdb->query(
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- identifiers are internal, ids are placeheld.
        $wpdb->prepare( "DELETE FROM $table WHERE $id_column IN ( $placeholders )", $meta_ids )
    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off cleanup of this plugin's own user meta.
}



/**
 *  vergeml_options_cleanup
 *
 *  @since    2.6
 *  @created  28/04/18
 */

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter

function vergeml_options_cleanup() {

    $options = array(
        'vergeml_taxonomies',
        'vergeml_lib_options',
        'vergeml_tax_options',
        'vergeml_mimes_backup', // in case it remains since previous versions
        'vergeml_mimes',
        'vergeml_backup',
        'vergeml_version',
        'vergeml_notices',
        'vergeml_ai',
        'vergeml_ai_credits',
        'vergeml_private_folders',
        'vergeml_folders_version',
        'vergeml_watchdog',
        'vergeml_uninstall_wipe'
    );

    $options = apply_filters( 'vergeml_pro_add_options', $options );

    foreach ( $options as $option ) {
        delete_option( $option );
    }

    /*
     *  And then the sweep, because the list above has never once been
     *  complete: every feature that stores an option would have to remember
     *  to add itself here, and the ones that forgot lingered after a
     *  "complete" cleanup. The list stays for the filter -- Pro options are
     *  not all vergeml_-prefixed.
     */
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'vergeml\_%' AND option_name NOT LIKE '\_transient%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off cleanup of this plugin's own options.
}



/**
 *  vergeml_site_options_cleanup
 *
 *  @since    2.6
 *  @created  28/04/18
 */

function vergeml_site_options_cleanup() {

    $options = array(
        'vergeml_version',
        'vergeml_mimes_backup',
        'vergeml_notices'
    );

    if ( is_multisite() ) {
        $options[] = 'vergeml_network_options';
        $options[] = 'vergeml_ai_network';
        $options[] = 'vergeml_uninstall_wipe_network';
        $options[] = 'vergeml_watchdog_network';
        delete_site_transient( 'vergeml_network_overview' );
    }

    $options = apply_filters( 'vergeml_pro_add_options', $options );

    foreach ( $options as $option ) {
        delete_site_option( $option );
    }
}



/**
 *  vergeml_transients_cleanup
 *
 *  @since    2.6
 *  @created  28/04/18
 */

function vergeml_transients_cleanup() {

    global $wpdb;

    /*
     *  A sweep, not a list: every feature that caches -- the journey facts,
     *  the pending counts, the AI hold -- would otherwise have to remember to
     *  register itself here, and the one that forgot would linger forever.
     *  Underscores escaped so the wildcard is the only wildcard.
     */
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '\_transient\_vergeml\_%'
            OR option_name LIKE '\_transient\_timeout\_vergeml\_%'"
    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off cleanup of this plugin's own transients.

    $transients = apply_filters( 'vergeml_pro_add_transients', array() );

    foreach ( $transients as $transient ) {
        delete_site_transient( $transient );
    }
}



/**
 *  vergeml_get_settings
 *
 *  @since    2.1
 *  @created  25/10/15
 */

function vergeml_get_settings() {

    $vergeml_taxonomies = get_option( 'vergeml_taxonomies' );
    $vergeml_lib_options = get_option( 'vergeml_lib_options' );
    $vergeml_tax_options = get_option( 'vergeml_tax_options' );
    $vergeml_mimes = get_option( 'vergeml_mimes' );

    $settings = array (
        'taxonomies' => $vergeml_taxonomies,
        'lib_options' => $vergeml_lib_options,
        'tax_options' => $vergeml_tax_options,
        'mimes' => $vergeml_mimes,
    );

    return $settings;
}



/**
 *  vergeml_print_media_library_options
 *
 *  @type     callback function
 *  @since    1.0
 *  @created  28/09/13
 */

function vergeml_print_media_library_options() {

    if ( ! current_user_can( 'manage_options' ) )
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'media_settings' ) )
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );
    }


    $vergeml_lib_options = get_option( 'vergeml_lib_options' );
    // Named for the screen, not for the group it used to sit in: the menu entry
    // beside it says "Media Library", and a heading that disagrees with the thing
    // you just clicked is a small lie about where you are.
    ?>


    <div id="vergeml-media-library-options-wrap" class="wrap eml-options">

        <?php
        echo vergeml_pg_head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the helper.
            __( 'Library settings', 'vergelabs-media-library' ),
            __( 'Ordering, filters, search and uploads on the media screen.', 'vergelabs-media-library' )
        );
        ?>


        <div id="poststuff">

            <div id="post-body" class="metabox-holder">

                <div id="postbox-container-2" class="postbox-container">

                    <form id="vergeml-form-media-library" method="post" action="options.php">

                        <?php settings_fields( 'media-library' ); ?>

                        <?php
                        /*
                         *  What each section is set to, on the line beside its
                         *  name, so a closed section still says something. The
                         *  words are the screen's own; nothing here is a label
                         *  invented for the summary.
                         */
                        $vgml_filters_named = array(
                            'types'      => __( 'Types', 'vergelabs-media-library' ),
                            'dates'      => __( 'Dates', 'vergelabs-media-library' ),
                            'authors'    => __( 'Authors', 'vergelabs-media-library' ),
                            'taxonomies' => __( 'Media taxonomies', 'vergelabs-media-library' ),
                            'ai'         => __( 'AI folders', 'vergelabs-media-library' ),
                        );

                        $vgml_search_named = array(
                            'titles'       => __( 'Titles', 'vergelabs-media-library' ),
                            'captions'     => __( 'Captions', 'vergelabs-media-library' ),
                            'descriptions' => __( 'Descriptions', 'vergelabs-media-library' ),
                            'filenames'    => __( 'Filenames', 'vergelabs-media-library' ),
                            'authors'      => __( 'Authors', 'vergelabs-media-library' ),
                            'taxonomies'   => __( 'Media taxonomies', 'vergelabs-media-library' ),
                        );

                        $vgml_shown = array_intersect_key( $vgml_filters_named, array_flip( (array) $vergeml_lib_options['filters_to_show'] ) );
                        $vgml_searched = array_intersect_key( $vgml_search_named, array_flip( (array) $vergeml_lib_options['search_in'] ) );

                        $vgml_orderby_named = array(
                            'date'      => __( 'By date', 'vergelabs-media-library' ),
                            'title'     => __( 'By title', 'vergelabs-media-library' ),
                            'menuOrder' => __( 'In your own order', 'vergelabs-media-library' ),
                        );

                        $vgml_caption_named = array(
                            'title'    => __( 'caption from the title', 'vergelabs-media-library' ),
                            'filename' => __( 'caption from the file name', 'vergelabs-media-library' ),
                            'caption'  => __( 'caption from the caption', 'vergelabs-media-library' ),
                        );

                        if ( ! empty( $vergeml_lib_options['search_on_enter'] ) ) {
                            $vgml_when_search = __( 'on the Enter key', 'vergelabs-media-library' );
                        } elseif ( ! empty( $vergeml_lib_options['search_auto'] ) ) {
                            /* translators: %d: how many letters before the search runs. */
                            $vgml_when_search = sprintf( __( 'as you type, from %d letters', 'vergelabs-media-library' ), (int) $vergeml_lib_options['search_min_letters'] );
                        } else {
                            $vgml_when_search = __( 'on the search button', 'vergelabs-media-library' );
                        }

                        $vgml_facts = array(
                            'order' => vergeml_acc_facts( array(
                                isset( $vgml_orderby_named[ $vergeml_lib_options['media_orderby'] ] ) ? $vgml_orderby_named[ $vergeml_lib_options['media_orderby'] ] : '',
                                'DESC' === $vergeml_lib_options['media_order'] ? __( 'descending', 'vergelabs-media-library' ) : __( 'ascending', 'vergelabs-media-library' ),
                                ! empty( $vergeml_lib_options['natural_sort'] ) ? __( 'natural order', 'vergelabs-media-library' ) : '',
                            ) ),
                            'filters' => vergeml_acc_facts( array(
                                $vgml_shown ? implode( ', ', $vgml_shown ) : __( 'No filters', 'vergelabs-media-library' ),
                                ! empty( $vergeml_lib_options['show_count'] ) ? __( 'with counts', 'vergelabs-media-library' ) : '',
                                ! empty( $vergeml_lib_options['force_filters'] ) ? __( 'in every popup', 'vergelabs-media-library' ) : '',
                            ) ),
                            'scrolling' => vergeml_acc_facts( array(
                                ! empty( $vergeml_lib_options['infinite_scrolling'] ) ? __( 'Loads as you reach the end', 'vergelabs-media-library' ) : __( 'Pages', 'vergelabs-media-library' ),
                                /* translators: %d: how many files load at a time. */
                                sprintf( __( '%d at a time', 'vergelabs-media-library' ), (int) $vergeml_lib_options['loads_per_page'] ),
                            ) ),
                            'search' => vergeml_acc_facts( array(
                                $vgml_searched ? implode( ', ', $vgml_searched ) : __( 'Nothing', 'vergelabs-media-library' ),
                                $vgml_when_search,
                            ) ),
                            'grid' => vergeml_acc_facts( array(
                                /* translators: %d: the thumbnail column width in pixels. */
                                sprintf( __( '%dpx columns', 'vergelabs-media-library' ), (int) $vergeml_lib_options['ideal_column_width'] ),
                                /* translators: %d: the sidebar width in pixels. */
                                sprintf( __( '%dpx sidebar', 'vergelabs-media-library' ), (int) $vergeml_lib_options['grid_sidebar_width'] ),
                                ! empty( $vergeml_lib_options['grid_show_caption'] ) && isset( $vgml_caption_named[ $vergeml_lib_options['grid_caption_type'] ] )
                                    ? $vgml_caption_named[ $vergeml_lib_options['grid_caption_type'] ]
                                    : __( 'no caption', 'vergelabs-media-library' ),
                            ) ),
                            'shortcodes' => ! empty( $vergeml_lib_options['enhance_media_shortcodes'] )
                                ? __( 'On', 'vergelabs-media-library' )
                                : __( 'Off', 'vergelabs-media-library' ),
                        );
                        ?>

                        <div class="vgml-acc" data-acc="media-library">

                        <?php vergeml_acc_start( 'order', __( 'Order', 'vergelabs-media-library' ), $vgml_facts['order'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><label for="vergeml_lib_options[media_orderby]"><?php esc_html_e('Order media items by','vergelabs-media-library'); ?></label><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'media_orderby' ); } ?></th>
                                        <td>
                                            <select name="vergeml_lib_options[media_orderby]" id="vergeml_lib_options_media_orderby">
                                                <option value="date" <?php selected( $vergeml_lib_options['media_orderby'], 'date' ); ?>><?php esc_html_e('Date','vergelabs-media-library'); ?></option>
                                                <option value="title" <?php selected( $vergeml_lib_options['media_orderby'], 'title' ); ?>><?php esc_html_e('Title','vergelabs-media-library'); ?></option>
                                                <option value="menuOrder" <?php selected( $vergeml_lib_options['media_orderby'], 'menuOrder' ); ?>><?php esc_html_e('Custom Order','vergelabs-media-library'); ?></option>
                                            </select>
                                            <?php esc_html_e('For media library and media popups','vergelabs-media-library'); ?>
</td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><label for="vergeml_lib_options[media_order]"><?php esc_html_e('Sort order','vergelabs-media-library'); ?></label><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'media_order' ); } ?></th>
                                        <td>
                                            <select name="vergeml_lib_options[media_order]" id="vergeml_lib_options_media_order">
                                                <option value="ASC" <?php selected( $vergeml_lib_options['media_order'], 'ASC' ); ?>><?php esc_html_e('Ascending','vergelabs-media-library'); ?></option>
                                                <option value="DESC" <?php selected( $vergeml_lib_options['media_order'], 'DESC' ); ?>><?php esc_html_e('Descending','vergelabs-media-library'); ?></option>
                                            </select>
                                            <?php esc_html_e('For media library and media popups','vergelabs-media-library'); ?>
                                        </td>
                                    </tr>

                                    <tr id="vergeml_lib_options_natural_sort">
                                        <th scope="row"><?php esc_html_e('Natural sort order','vergelabs-media-library'); ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Natural sort order','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[natural_sort]" type="hidden" value="0" /><input name="vergeml_lib_options[natural_sort]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['natural_sort'], true ); ?> /> <?php esc_html_e('Apply human-friendly sort order to Media Library and Galleries','vergelabs-media-library'); ?></label>
                                                <p class="description"><?php esc_html_e( 'Example: [1, 2, 3, 10, 18, 22, abc-2, abc-11] instead of [1, 10, 18, 2, 22, 3, abc-11, abc-2]', 'vergelabs-media-library' );  ?></p>
                                            </fieldset>
                                        </td>
                                    </tr>
                                </table>

                            </div>

                        </div>

                        <?php vergeml_acc_end(); ?>

                        <?php vergeml_acc_start( 'filters', __( 'Filters', 'vergelabs-media-library' ), $vgml_facts['filters'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Force filters','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'force_filters' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Force filters','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[force_filters]" type="hidden" value="0" /><input name="vergeml_lib_options[force_filters]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['force_filters'], true ); ?> /> <?php esc_html_e('Show media filters for any media popup','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Filters to show', 'vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'filters_to_show' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Filters to show', 'vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[filters_to_show][]" type="hidden" value="none" /><input name="vergeml_lib_options[filters_to_show][]" type="checkbox" value="types" <?php echo in_array('types', $vergeml_lib_options['filters_to_show']) ? 'checked' : ''; ?> /> <?php esc_html_e('Types','vergelabs-media-library'); ?>
                                                <em>(<?php esc_html_e( 'Can be disabled for Grid Mode only', 'vergelabs-media-library' ); ?>)</em></label><br />
                                                <label><input name="vergeml_lib_options[filters_to_show][]" type="checkbox" value="dates" <?php echo in_array('dates', $vergeml_lib_options['filters_to_show']) ? 'checked' : ''; ?> /> <?php esc_html_e('Dates','vergelabs-media-library'); ?></label><br />
                                                <label><input name="vergeml_lib_options[filters_to_show][]" type="checkbox" value="authors" <?php echo in_array('authors', $vergeml_lib_options['filters_to_show']) ? 'checked' : ''; ?> /> <?php esc_html_e('Authors','vergelabs-media-library'); ?></label><br />
                                                <label><input name="vergeml_lib_options[filters_to_show][]" type="checkbox" value="taxonomies" <?php echo in_array('taxonomies', $vergeml_lib_options['filters_to_show']) ? 'checked' : ''; ?> /> <?php esc_html_e('Media Taxonomies','vergelabs-media-library'); ?></label><br />
                                                <label><input name="vergeml_lib_options[filters_to_show][]" type="checkbox" value="ai" <?php echo in_array('ai', $vergeml_lib_options['filters_to_show']) ? 'checked' : ''; ?> /> <?php esc_html_e('AI folders','vergelabs-media-library'); ?>
                                                <em>(<?php esc_html_e( 'In the folder panel: photos, screenshots, documents and the rest, from the descriptions', 'vergelabs-media-library' ); ?>)</em></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Show count','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'show_count' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Show count','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[show_count]" type="hidden" value="0" /><input name="vergeml_lib_options[show_count]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['show_count'], true ); ?> /> <?php esc_html_e('Show item count per category for media filters','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Include children','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'include_children' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Include children','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[include_children]" type="hidden" value="0" /><input name="vergeml_lib_options[include_children]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['include_children'], true ); ?> /> <?php esc_html_e('Show media items of child media categories as a result of filtering', 'vergelabs-media-library'); ?></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Uploaded to this post by default','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'filter_uploaded' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Uploaded to this post by default','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[filter_uploaded]" type="hidden" value="0" /><input name="vergeml_lib_options[filter_uploaded]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['filter_uploaded'], true ); ?> /> <?php esc_html_e('Show media files initially filtered by Uploaded to this post when applicable', 'vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                </table>

                            </div>

                        </div>

                        <?php vergeml_acc_end(); ?>

                        <?php vergeml_acc_start( 'scrolling', __( 'Scrolling', 'vergelabs-media-library' ), $vgml_facts['scrolling'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Infinite scrolling','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'infinite_scrolling' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Infinite scrolling','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[infinite_scrolling]" type="hidden" value="0" /><input name="vergeml_lib_options[infinite_scrolling]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['infinite_scrolling'], true ); ?> /> <?php esc_html_e('Load more media as you reach the end, instead of pages','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Number per page','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'loads_per_page' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Number per page','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[loads_per_page]" type="number" min="40" step="10" value="<?php echo (int) $vergeml_lib_options['loads_per_page']; ?>" /> <?php esc_html_e('media files loaded per page','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                </table>

                            </div>

                        </div>


                        <?php
                            /*
                             *  This whole box used to be greyed out and labelled
                             *  "/ Premium Feature", even though search on enter, the
                             *  minimum letter count and auto search all work here. Only
                             *  the "Enable search in" fieldset was genuinely paid-only,
                             *  and its option was stored but never read, so that one
                             *  fieldset is gone and the rest is simply enabled.
                             */
                        ?>

                        <?php vergeml_acc_end(); ?>

                        <?php vergeml_acc_start( 'search', __( 'Search', 'vergelabs-media-library' ), $vgml_facts['search'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Search in', 'vergelabs-media-library' ); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'search_in' ); } ?></th>
                                        <td>
                                            <fieldset id="vergeml_lib_options_search_in">
                                                <legend class="screen-reader-text"><span><?php esc_html_e( 'Search in', 'vergelabs-media-library' ); ?></span></legend>
                                                <input name="vergeml_lib_options[search_in][]" type="hidden" value="none" />
<?php
                                                $vergeml_search_fields = array(
                                                    'titles'       => __( 'Titles', 'vergelabs-media-library' ),
                                                    'captions'     => __( 'Captions', 'vergelabs-media-library' ),
                                                    'descriptions' => __( 'Descriptions', 'vergelabs-media-library' ),
                                                    'filenames'    => __( 'Filenames', 'vergelabs-media-library' ),
                                                    'authors'      => __( 'Authors', 'vergelabs-media-library' ),
                                                    'taxonomies'   => __( 'Media taxonomies', 'vergelabs-media-library' ),
                                                );

                                                foreach ( $vergeml_search_fields as $vergeml_field => $vergeml_label ) :
?>
                                                <label><input name="vergeml_lib_options[search_in][]" type="checkbox" value="<?php echo esc_attr( $vergeml_field ); ?>" class="search_columns" <?php checked( in_array( $vergeml_field, (array) $vergeml_lib_options['search_in'], true ) ); ?> /> <?php echo esc_html( $vergeml_label ); ?></label><br />
<?php
                                                endforeach;
?>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Search on enter','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'search_on_enter' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Search on enter','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[search_on_enter]" type="hidden" value="0" /><input id="vergeml_lib_options_search_on_enter" name="vergeml_lib_options[search_on_enter]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['search_on_enter'], true ); ?> /> <?php esc_html_e('Search only on the Enter key','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Auto search','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'search_auto' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Auto search','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[search_auto]" type="hidden" value="0" /><input id="vergeml_lib_options_search_auto" name="vergeml_lib_options[search_auto]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['search_auto'], true ); ?> /> <?php esc_html_e('Search automatically while typing','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr id="vergeml_lib_options_search_min_letters">
                                        <th scope="row"><?php esc_html_e('Minimum number of letters','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'search_min_letters' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Minimun number of letters','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[search_min_letters]" type="number" min="2" step="1" value="<?php echo (int) $vergeml_lib_options['search_min_letters']; ?>" /> <?php esc_html_e('letters before auto search starts — a higher number spares the database','vergelabs-media-library'); ?></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                </table>

                            </div>

                        </div>




                        <?php
                        /*
                         *  Order used to sit here, fourth. Spec section 7: the
                         *  setting that matters most is the first section, and
                         *  on this screen that is the order the library opens
                         *  in. It is at the head of the accordion now.
                         */
                        ?>

                        <?php vergeml_acc_end(); ?>

                        <?php vergeml_acc_start( 'grid', __( 'Grid Mode', 'vergelabs-media-library' ), $vgml_facts['grid'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Right sidebar width','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'grid_sidebar_width' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Right sidebar width','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[grid_sidebar_width]" type="number" min="200" step="10" value="<?php echo (int) $vergeml_lib_options['grid_sidebar_width']; ?>" /> <?php esc_html_e('right sidebar, when the screen is wider than 900px','vergelabs-media-library'); ?></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Ideal column width','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'ideal_column_width' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Ideal column width','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[ideal_column_width]" type="number" min="50" step="10" value="<?php echo (int) $vergeml_lib_options['ideal_column_width']; ?>" /> <?php esc_html_e('ideal thumbnail column, in the library and media popups','vergelabs-media-library'); ?></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Show caption','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'grid_show_caption' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Show caption','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[grid_show_caption]" type="hidden" value="0" /><input id="vergeml_lib_options_grid_show_caption" name="vergeml_lib_options[grid_show_caption]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['grid_show_caption'], true ); ?> /> <?php esc_html_e('Add a text caption under media thumbnails', 'vergelabs-media-library'); ?></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                    <tr id="vergeml_lib_options_grid_caption_type">
                                        <th scope="row"><label for="vergeml_lib_options[grid_caption_type]"><?php esc_html_e('Caption type','vergelabs-media-library'); ?></label></th>
                                        <td>
                                            <select name="vergeml_lib_options[grid_caption_type]">
                                                <option value="title" <?php selected( $vergeml_lib_options['grid_caption_type'], 'title' ); ?>><?php esc_html_e('Title','vergelabs-media-library'); ?></option>
                                                <option value="filename" <?php selected( $vergeml_lib_options['grid_caption_type'], 'filename' ); ?>><?php esc_html_e('Filename','vergelabs-media-library'); ?></option>
                                                <option value="caption" <?php selected( $vergeml_lib_options['grid_caption_type'], 'caption' ); ?>><?php esc_html_e('Caption','vergelabs-media-library'); ?></option>
                                            </select>
                                        </td>
                                    </tr>

                                </table>

                            </div>

                        </div>


                        <?php vergeml_acc_end(); ?>

                        <?php
                        // What this site shares about its library: core/instrument.php.
                        // It prints its own section; the accordion is still open here.
                        if ( function_exists( 'vergeml_stats_settings_section' ) ) {
                            vergeml_stats_settings_section();
                        }
                        ?>

                        <?php vergeml_acc_start( 'shortcodes', __( 'Media Shortcodes', 'vergelabs-media-library' ), $vgml_facts['shortcodes'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Enhanced media shortcodes','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'enhance_media_shortcodes' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Enhanced media shortcodes','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_lib_options[enhance_media_shortcodes]" type="hidden" value="0" /><input name="vergeml_lib_options[enhance_media_shortcodes]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_lib_options['enhance_media_shortcodes'], true ); ?> /> <?php esc_html_e('Let gallery and playlist shortcodes understand media taxonomies, upload date, and an item limit','vergelabs-media-library'); ?></label>
                                                <p class="description vgml-mono">[gallery media_category="5" limit="10" year="2015"]</p>
                                                <p class="description vgml-accent-text"><?php esc_html_e( 'Some themes and gallery plugins replace the default gallery. Check your galleries after turning this on, and report anything broken.', 'vergelabs-media-library' ); ?></p>
                                            </fieldset>
                                        </td>
                                    </tr>
                                </table>

                            </div>

                        </div>

                        <?php vergeml_acc_end(); ?>

                        </div><!-- .vgml-acc -->

                        <?php
                        /*
                         *  One save for the whole screen.
                         *
                         *  There were six, one under each section, all inside
                         *  the same <form> and all saving the same options --
                         *  so five of them were doing nothing the sixth did
                         *  not, while making the page read as six unrelated
                         *  settings pages stacked up. This one sits at the end
                         *  of the form, in normal flow like everything else in
                         *  the shell, and it is outside the accordion so it
                         *  cannot be shut inside a closed section.
                         */
                        ?>
                        <div class="vgml-savebar">
                            <?php submit_button( __( 'Save changes', 'vergelabs-media-library' ), 'primary', 'submit', false, array( 'id' => 'eml-submit-lib-settings' ) ); ?>
                            <span class="vgml-savebar-note"><?php esc_html_e( 'Saves everything on this page.', 'vergelabs-media-library' ); ?></span>
                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

    <?php
}



/**
 *  vergeml_print_taxonomies_options
 *
 *  @type     callback function
 *  @since    1.0
 *  @created  28/09/13
 */

function vergeml_print_taxonomies_options() {

    if ( ! current_user_can( 'manage_options' ) )
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'media_settings' ) )
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );
    }


    $vergeml_taxonomies = get_option( 'vergeml_taxonomies', array() ); ?>


    <div id="vergeml-global-options-wrap" class="wrap eml-options">

        <?php
        echo vergeml_pg_head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the helper.
            __( 'Folders and categories', 'vergelabs-media-library' ),
            __( 'Which categories act as folders, and which other taxonomies apply to media.', 'vergelabs-media-library' )
        );
        ?>

        <?php
        /*
         *  What this screen is, before what it asks.
         *
         *  It opened on "Assign following taxonomies to Media Library" -- the
         *  original plugin's words -- next to a list of checkboxes. Somebody
         *  who does not already know what a taxonomy is learns nothing, and
         *  somebody who does still cannot tell which of them is the folder
         *  tree they have been dragging files into.
         */
        ?>
        <div class="vgml-tax-intro">
            <p class="vgml-note vgml-tax-intro-text">
                <?php
                printf(
                    /* translators: %s: the name of the folder taxonomy, in code formatting. */
                    esc_html__( 'The folder tree beside your media library is a category list — stored as %s, an ordinary WordPress taxonomy. Folders survive if this plugin is ever removed. Anything else you tick below becomes another way to label and filter media, alongside the folders — never a second tree. Unticking hides; it never deletes.', 'vergelabs-media-library' ),
                    '<code class="vgml-mono">media_category</code>'
                );
                ?>
            </p>
        </div>


        <div id="poststuff">

            <div id="post-body" class="metabox-holder">

                <div id="postbox-container-2" class="postbox-container">

                    <form id="vergeml-form-taxonomies" method="post" action="options.php">

                        <?php settings_fields( 'media-taxonomies' ); ?>

                        <?php
                        // What each section is set to, on the line beside its name.
                        $vgml_tax_saved    = (array) get_option( 'vergeml_taxonomies', array() );
                        $vgml_tax_opts     = (array) get_option( 'vergeml_tax_options', array() );
                        $vgml_tax_assigned = 0;

                        foreach ( $vgml_tax_saved as $vgml_tax_row ) {

                            if ( ! empty( $vgml_tax_row['assigned'] ) ) {
                                $vgml_tax_assigned++;
                            }
                        }

                        $vgml_tax_on_media = count( get_object_taxonomies( 'attachment' ) );

                        $vgml_facts = array(
                            /* translators: %d: how many taxonomies are on media. */
                            'taxonomies' => sprintf( _n( '%d on media', '%d on media', $vgml_tax_on_media, 'vergelabs-media-library' ), $vgml_tax_on_media ),
                            'also'       => 0 === $vgml_tax_assigned
                                ? __( 'None', 'vergelabs-media-library' )
                                /* translators: %d: how many other taxonomies also show on media. */
                                : sprintf( _n( '%d also shown', '%d also shown', $vgml_tax_assigned, 'vergelabs-media-library' ), $vgml_tax_assigned ),
                            'options'    => vergeml_acc_facts( array(
                                ! empty( $vgml_tax_opts['one_folder_per_file'] )
                                    ? __( 'One folder per file', 'vergelabs-media-library' )
                                    : __( 'A file may sit in several folders', 'vergelabs-media-library' ),
                                ! empty( $vgml_tax_opts['tax_archives'] ) ? __( 'archive pages on', 'vergelabs-media-library' ) : '',
                                ! empty( $vgml_tax_opts['edit_all_as_hierarchical'] ) ? __( 'all shown as hierarchical', 'vergelabs-media-library' ) : '',
                            ) ),
                        );
                        ?>

                        <div class="vgml-acc" data-acc="media-taxonomies">

                        <?php vergeml_acc_start( 'taxonomies', __( 'Media taxonomies', 'vergelabs-media-library' ), $vgml_facts['taxonomies'] ); ?>

                        <div class="postbox">

                            <div class="inside">

                                
                                <?php $html = '';

                                foreach ( get_taxonomies(array(),'object') as $taxonomy ) {

                                    /*
                                     *  Ours is ours, whatever else it is attached to.
                                     *
                                     *  This asked "is it on attachments and nothing else", which was a fair
                                     *  test of "is this a media taxonomy" right up until a media taxonomy
                                     *  could also be turned on for posts. After that our own folder taxonomy
                                     *  failed it, dropped out of this editor, and reappeared further down the
                                     *  screen in the list of other people's taxonomies -- where the form posts
                                     *  eml_media and four checkboxes and nothing else.
                                     *
                                     *  The sanitiser then read that as a media taxonomy being saved with
                                     *  hierarchical, show_in_rest, sort and post types all absent, and wrote
                                     *  them off. One Save and the folder tree was gone from every screen.
                                     *
                                     *  eml_media is the question that was actually meant.
                                     */
                                    if ( ! empty( $vergeml_taxonomies[$taxonomy->name]['eml_media'] ) ||
                                         (in_array('attachment',$taxonomy->object_type) && count($taxonomy->object_type) == 1) || empty($taxonomy->object_type) ) {

                                        $assigned = (bool) $vergeml_taxonomies[$taxonomy->name]['assigned'];
                                        $eml_media = (bool) $vergeml_taxonomies[$taxonomy->name]['eml_media'];

                                        if ( $eml_media )
                                            $li_class = 'vergeml-taxonomy';
                                        else
                                            $li_class = 'wpuxss-non-eml-taxonomy';

                                        $html .= '<li class="' . $li_class . '" id="' . esc_attr($taxonomy->name) . '">';

                                        $html .= '<input name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][eml_media]" type="hidden" value="' . $eml_media . '" />';
                                        /*
                                         *  This form carries the whole taxonomy.
                                         *
                                         *  Without it the sanitiser cannot tell an unticked checkbox from a control
                                         *  that was never on the form, and has to read both as off -- so any screen
                                         *  posting a partial taxonomy switched off everything it did not mention.
                                         */
                                        $html .= '<input name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][_full]" type="hidden" value="1" />';
                                        $html .= '<label><input class="vergeml-assigned" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][assigned]" type="checkbox" value="1" ' . checked( true, $assigned, false ) . ' title="' . __('Assign Taxonomy','vergelabs-media-library') . '" />' . esc_html($taxonomy->label) . '</label>';
                                        $html .= '<a class="vergeml-button-edit" title="' . __('Edit Taxonomy','vergelabs-media-library') . '" href="javascript:;">' . __('Edit','vergelabs-media-library') . ' &darr;</a>';

                                        if ( $eml_media ) {

                                            $html .= '<a class="vergeml-button-remove" title="' . __('Delete Taxonomy','vergelabs-media-library') . '" href="javascript:;">&ndash;</a>';

                                            $html .= '<div class="vergeml-taxonomy-edit" style="display:none;">';

                                            $html .= '<div class="vergeml-labels-edit">';
                                            $html .= '<h4>' . __('Labels','vergelabs-media-library') . '</h4>';
                                            $html .= '<ul>';
                                            $html .= '<li><label>' . __('Singular','vergelabs-media-library') . '</label><input type="text" class="vergeml-singular_name" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][singular_name]" value="' . esc_html($taxonomy->labels->singular_name) . '" /></li>';
                                            $html .= '<li><label>' . __('Plural','vergelabs-media-library') . '</label><input type="text" class="vergeml-name" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][name]" value="' . esc_html($taxonomy->labels->name) . '" /></li>';
                                            $html .= '<li><label>' . __('Menu Name','vergelabs-media-library') . '</label><input type="text" class="vergeml-menu_name" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][menu_name]" value="' . esc_html($taxonomy->labels->menu_name) . '" /></li>';
                                            $html .= '<li><label>' . __('All','vergelabs-media-library') . '</label><input type="text" class="vergeml-all_items" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][all_items]" value="' . esc_html($taxonomy->labels->all_items) . '" /></li>';
                                            $html .= '<li><label>' . __('Edit','vergelabs-media-library') . '</label><input type="text" class="vergeml-edit_item" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][edit_item]" value="' . esc_html($taxonomy->labels->edit_item) . '" /></li>';
                                            $html .= '<li><label>' . __('View','vergelabs-media-library') . '</label><input type="text" class="vergeml-view_item" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][view_item]" value="' . esc_html($taxonomy->labels->view_item) . '" /></li>';
                                            $html .= '<li><label>' . __('Update','vergelabs-media-library') . '</label><input type="text" class="vergeml-update_item" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][update_item]" value="' . esc_html($taxonomy->labels->update_item) . '" /></li>';
                                            $html .= '<li><label>' . __('Add New','vergelabs-media-library') . '</label><input type="text" class="vergeml-add_new_item" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][add_new_item]" value="' . esc_html($taxonomy->labels->add_new_item) . '" /></li>';
                                            $html .= '<li><label>' . __('New','vergelabs-media-library') . '</label><input type="text" class="vergeml-new_item_name" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][new_item_name]" value="' . esc_html($taxonomy->labels->new_item_name) . '" /></li>';
                                            $html .= '<li><label>' . __('Parent','vergelabs-media-library') . '</label><input type="text" class="vergeml-parent_item" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][parent_item]" value="' . esc_html($taxonomy->labels->parent_item) . '" /></li>';
                                            $html .= '<li><label>' . __('Search','vergelabs-media-library') . '</label><input type="text" class="vergeml-search_items" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][labels][search_items]" value="' . esc_html($taxonomy->labels->search_items) . '" /></li>';
                                            $html .= '</ul>';
                                            $html .= '</div>';

                                            $html .= '<div class="vergeml-settings-edit">';
                                            $html .= '<h4>' . __('Settings','vergelabs-media-library') . '</h4>';
                                            $html .= '<ul>';
                                            $html .= '<li><label>' . __('Taxonomy Name','vergelabs-media-library') . '</label><input type="text" class="vergeml-taxonomy-name" name="" value="' . esc_attr($taxonomy->name) . '" disabled="disabled" /></li>';
                                            /*
                                             *  These four read the stored setting, not the registered taxonomy.
                                             *
                                             *  Reading the live object looks equivalent and is not: this page is one
                                             *  form, so saving anything on it posts every checkbox, and a box that
                                             *  renders from the object writes the object's state back over the setting.
                                             *  The moment the two disagreed -- and they disagree whenever registration
                                             *  falls back for any reason -- Save made the wrong one permanent.
                                             *
                                             *  Hierarchical is the one that hurts: turn it off and the taxonomy is no
                                             *  longer drawn as a tree, so the folder panel disappears from every screen
                                             *  while every folder sits untouched in the database. And because the box
                                             *  then rendered unchecked, saving again kept it off. There was no way back
                                             *  from inside the interface.
                                             */
                                            $html .= '<li><label>' . __('Hierarchical','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-hierarchical" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][hierarchical]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['hierarchical'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Column for List View','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-show_admin_column" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][show_admin_column]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['show_admin_column'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Filter for List View','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-admin_filter" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][admin_filter]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['admin_filter'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Filter for Grid View / Media Popup','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-media_uploader_filter" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][media_uploader_filter]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['media_uploader_filter'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Edit in Media Popup','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-media_popup_taxonomy_edit" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][media_popup_taxonomy_edit]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['media_popup_taxonomy_edit'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Remember Terms Order (sort)','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-sort" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][sort]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['sort'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Show in REST','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-show_in_rest" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][show_in_rest]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['show_in_rest'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Also use for','vergelabs-media-library') . '</label>' . vergeml_folder_post_types_field( $taxonomy->name ) . '</li>';
                                            $html .= '<li><label>' . __('Rewrite Slug','vergelabs-media-library') . '</label><input type="text" class="vergeml-slug" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][rewrite][slug]" value="' . esc_attr($vergeml_taxonomies[$taxonomy->name]['rewrite']['slug']) . '" /></li>';
                                            $html .= '<li><label>' . __('Slug with Front','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-with_front" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][rewrite][with_front]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['rewrite']['with_front'], false ) . ' /></li>';
                                            $html .= '</ul>';
                                            $html .= '</div>';

                                            $html .= '</div>';
                                        }
                                        else {

                                            $html .= '<div class="vergeml-taxonomy-edit" style="display:none;">';

                                            $html .= '<div class="vergeml-settings-edit">';
                                            $html .= '<h4>' . __('Settings','vergelabs-media-library') . '</h4>';
                                            $html .= '<ul>';
                                            $html .= '<li><label>' . __('Filter for List View','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-admin_filter" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][admin_filter]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['admin_filter'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Filter for Grid View / Media Popup','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-media_uploader_filter" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][media_uploader_filter]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['media_uploader_filter'], false ) . ' /></li>';
                                            $html .= '<li><label>' . __('Edit in Media Popup','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-media_popup_taxonomy_edit" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][media_popup_taxonomy_edit]" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['media_popup_taxonomy_edit'], false ) . ' /></li>';
                                            $html .= '</ul>';
                                            $html .= '</div>';
                                            $html .= '</div>';
                                        }
                                        $html .= '</li>';
                                    }
                                }

                                $html .= '<li class="vergeml-clone" style="display:none">';
                                $html .= '<input name="" type="hidden" class="vergeml-eml_media" value="1" />';
                                $html .= '<input name="" type="hidden" class="vergeml-create_taxonomy" value="1" />';
                                $html .= '<label class="vergeml-taxonomy-label"><input class="vergeml-assigned" name="" type="checkbox" class="vergeml-assigned" value="1" checked="checked" title="' . __('Assign Taxonomy','vergelabs-media-library') . '" />' . '<span>' . __('New Taxonomy','vergelabs-media-library') . '</span></label>';

                                $html .= '<a class="vergeml-button-remove" title="' . __('Delete Taxonomy','vergelabs-media-library') . '" href="javascript:;">&ndash;</a>';

                                $html .= '<div class="vergeml-taxonomy-edit">';

                                $html .= '<div class="vergeml-labels-edit">';
                                $html .= '<h4>' . __('Labels','vergelabs-media-library') . '</h4>';
                                $html .= '<ul>';
                                $html .= '<li><label>' . __('Singular','vergelabs-media-library') . '</label><input type="text" class="vergeml-singular_name" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Plural','vergelabs-media-library') . '</label><input type="text" class="vergeml-name" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Menu Name','vergelabs-media-library') . '</label><input type="text" class="vergeml-menu_name" name="" value="" /></li>';
                                $html .= '<li><label>' . __('All','vergelabs-media-library') . '</label><input type="text" class="vergeml-all_items" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Edit','vergelabs-media-library') . '</label><input type="text" class="vergeml-edit_item" name="" value="" /></li>';
                                $html .= '<li><label>' . __('View','vergelabs-media-library') . '</label><input type="text" class="vergeml-view_item" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Update','vergelabs-media-library') . '</label><input type="text" class="vergeml-update_item" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Add New','vergelabs-media-library') . '</label><input type="text" class="vergeml-add_new_item" name="" value="" /></li>';
                                $html .= '<li><label>' . __('New','vergelabs-media-library') . '</label><input type="text" class="vergeml-new_item_name" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Parent','vergelabs-media-library') . '</label><input type="text" class="vergeml-parent_item" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Search','vergelabs-media-library') . '</label><input type="text" class="vergeml-search_items" name="" value="" /></li>';
                                $html .= '</ul>';
                                $html .= '</div>';

                                $html .= '<div class="vergeml-settings-edit">';
                                $html .= '<h4>' . __('Settings','vergelabs-media-library') . '</h4>';
                                $html .= '<ul>';
                                $html .= '<li><label>' . __('Taxonomy Name','vergelabs-media-library') . '</label><input type="text" class="vergeml-taxonomy-name" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Hierarchical','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-hierarchical" name="" value="1" checked="checked" /></li>';
                                $html .= '<li><label>' . __('Column for List View','vergelabs-media-library') . '</label><input class="vergeml-show_admin_column" type="checkbox" name="" value="1" /></li>';
                                $html .= '<li><label>' . __('Filter for List View','vergelabs-media-library') . '</label><input class="vergeml-admin_filter" type="checkbox"  name="" value="1" /></li>';
                                $html .= '<li><label>' . __('Filter for Grid View / Media Popup','vergelabs-media-library') . '</label><input class="vergeml-media_uploader_filter" type="checkbox" name="" value="1" /></li>';
                                $html .= '<li><label>' . __('Edit in Media Popup','vergelabs-media-library') . '</label><input class="vergeml-media_popup_taxonomy_edit" type="checkbox" name="" value="1" /></li>';
                                $html .= '<li><label>' . __('Remember Terms Order (sort)','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-sort" name="" value="1" /></li>';
                                $html .= '<li><label>' . __('Show in REST','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-show_in_rest" name="" value="1" /></li>';
                                $html .= '<li><label>' . __('Rewrite Slug','vergelabs-media-library') . '</label><input type="text" class="vergeml-slug" name="" value="" /></li>';
                                $html .= '<li><label>' . __('Slug with Front','vergelabs-media-library') . '</label><input type="checkbox" class="vergeml-with_front" name="" value="1" checked="checked" /></li>';
                                $html .= '</ul>';
                                $html .= '</div>';

                                $html .= '</div>';
                                $html .= '</li>'; ?>

                                <?php if ( ! empty( $html ) ) : ?>

                                    <ul class="vergeml-settings-list vergeml-media-taxonomy-list">
                                        <?php
                                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- assembled above from esc_attr() and esc_html() parts plus literal form markup, which wp_kses would strip.
                                        echo $html;
                                        ?>
                                    </ul>
                                    <div class="vergeml-button-container-right"><a class="vgml-btn vgml-btn-ghost vergeml-button-create-taxonomy" href="javascript:;">+ <?php esc_html_e( 'Add a new taxonomy', 'vergelabs-media-library' ); ?></a></div>
                                <?php endif; ?>

                            </div>

                        </div>

                        <?php vergeml_acc_end(); ?>

                        <?php vergeml_acc_start( 'also', __( 'Also show on media', 'vergelabs-media-library' ), $vgml_facts['also'] ); ?>

                        <div class="postbox">
                            <p class="vgml-note vgml-tax-other-note"><?php esc_html_e( 'Taxonomies from posts, products and the theme. Ticked ones appear in the filter bar and edit panel.', 'vergelabs-media-library' ); ?></p>

                            <div class="inside">

                                
                                <?php $unuse = array('revision','nav_menu_item','attachment');

                                foreach ( get_post_types(array(),'object') as $post_type ) {

                                    if ( ! in_array( $post_type->name, $unuse ) ) {

                                        $taxonomies = get_object_taxonomies($post_type->name,'object');
                                        if ( ! empty( $taxonomies ) ) {

                                            $html = '';

                                            foreach ( $taxonomies as $taxonomy ) {

                                                if ( $taxonomy->name == 'post_format' || 
                                                     $taxonomy->name == 'wp_theme'||
                                                     $taxonomy->name == 'wp_pattern_category'||
                                                     $taxonomy->name == 'wp_template_part_area' ) {
                                                    continue;
                                                }

                                                /*
                                                 *  A media taxonomy of ours is edited above, in full. Listing it
                                                 *  here as well put it on the page twice, and the partial form
                                                 *  down here overwrote everything the full one had just set.
                                                 */
                                                if ( ! empty( $vergeml_taxonomies[$taxonomy->name]['eml_media'] ) ) {
                                                    continue;
                                                }


                                                $html .= '<li class="wpuxss-non-eml-taxonomy" id="' . esc_attr($taxonomy->name) . '">';
                                                $html .= '<input name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][eml_media]" type="hidden" value="' . esc_attr($vergeml_taxonomies[$taxonomy->name]['eml_media']) . '" />';
                                                $html .= '<label><input class="vergeml-assigned" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][assigned]" type="checkbox" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['assigned'], false ) . ' title="' . __('Assign Taxonomy','vergelabs-media-library') . '" />' . esc_html($taxonomy->label) . '</label>';
                                                $html .= '<a class="vergeml-button-edit" title="' . __('Edit Taxonomy','vergelabs-media-library') . '" href="javascript:;">' . __('Edit','vergelabs-media-library') . ' &darr;</a>';
                                                $html .= '<div class="vergeml-taxonomy-edit" style="display:none;">';

                                                $html .= '<h4>' . __('Settings','vergelabs-media-library') . '</h4>';
                                                $html .= '<ul>';
                                                $html .= '<li><input type="checkbox" class="vergeml-admin_filter" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][admin_filter]" id="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-admin_filter" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['admin_filter'], false ) . ' /><label for="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-admin_filter">' . __('Filter for List View','vergelabs-media-library') . '</label></li>';
                                                $html .= '<li><input type="checkbox" class="vergeml-media_uploader_filter" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][media_uploader_filter]" id="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-media_uploader_filter" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['media_uploader_filter'], false ) . ' /><label for="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-media_uploader_filter">' . __('Filter for Grid View / Media Popup','vergelabs-media-library') . '</label></li>';
                                                $html .= '<li><input type="checkbox" class="vergeml-media_popup_taxonomy_edit" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][media_popup_taxonomy_edit]" id="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-media_popup_taxonomy_edit" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['media_popup_taxonomy_edit'], false ) . ' /><label for="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-media_popup_taxonomy_edit">' . __('Edit in Media Popup','vergelabs-media-library') . '</label></li>';

                                                /*
                                                 *  Auto-assign. This used to be greyed out and labelled
                                                 *  "/ Premium Feature" with nothing behind it; it now
                                                 *  works, see core/auto-assign.php. Only offered for a
                                                 *  taxonomy the parent post type actually has, because a
                                                 *  post cannot pass on terms of a taxonomy it lacks.
                                                 */

                                                $vergeml_auto_assign_types = array();

                                                foreach ( (array) $taxonomy->object_type as $vergeml_object_type ) {
                                                    if ( 'attachment' === $vergeml_object_type )
                                                        continue;
                                                    $vergeml_pt = get_post_type_object( $vergeml_object_type );
                                                    if ( $vergeml_pt )
                                                        $vergeml_auto_assign_types[] = strtolower( $vergeml_pt->labels->singular_name );
                                                }

                                                if ( ! empty( $vergeml_auto_assign_types ) ) {

                                                    $html .= '<li><input type="checkbox" class="vergeml-taxonomy_auto_assign" name="vergeml_taxonomies[' . esc_attr($taxonomy->name) . '][taxonomy_auto_assign]" id="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-taxonomy_auto_assign" value="1" ' . checked( true, (bool) $vergeml_taxonomies[$taxonomy->name]['taxonomy_auto_assign'], false ) . ' />';
                                                    $html .= '<label for="vergeml_taxonomies-' . esc_attr($taxonomy->name) . '-taxonomy_auto_assign">' . sprintf(
                                                        /* translators: 1: taxonomy name, for example "Categories", 2: post type name, for example "post" */
                                                        esc_html__( 'On upload, give media the %1$s of the %2$s it was uploaded to', 'vergelabs-media-library' ),
                                                        esc_html( $taxonomy->label ),
                                                        esc_html( implode( ' / ', $vergeml_auto_assign_types ) )
                                                    ) . '</label></li>';
                                                }

                                                $html .= '</ul>';

                                                $html .= '</div>';
                                                $html .= '</li>';
                                            } ?>

                                            <?php if ( ! empty( $html ) ) : ?>

                                                <h4><?php echo esc_html($post_type->label); ?></h4>
                                                <ul class="vergeml-settings-list vergeml-non-media-taxonomy-list">
                                                    <?php
                                                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- assembled above from esc_attr() and esc_html() parts plus literal form markup, which wp_kses would strip.
                                                    echo $html;
                                                    ?>
                                                </ul>

                                            <?php endif;
                                        }
                                    }
                                }

                                ?>

                            </div>

                        </div>

                        <?php vergeml_acc_end(); ?>

                        <?php vergeml_acc_start( 'options', __( 'Options', 'vergelabs-media-library' ), $vgml_facts['options'] ); ?>

                        <?php $vergeml_tax_options = get_option( 'vergeml_tax_options' ); ?>

                        <div class="postbox">

                            <div class="inside">

                                <table class="form-table">
                                    <tr>
                                        <th scope="row"><?php esc_html_e('Taxonomy archive pages','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'tax_archives' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Taxonomy archive pages','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_tax_options[tax_archives]" type="hidden" value="0" /><input name="vergeml_tax_options[tax_archives]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_tax_options['tax_archives'], true ); ?> /> <?php esc_html_e('Turn on media taxonomy archive pages on the front-end','vergelabs-media-library'); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php esc_html_e('Assign all like hierarchical','vergelabs-media-library'); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'edit_all_as_hierarchical' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e('Assign all like hierarchical','vergelabs-media-library'); ?></span></legend>
                                                <label><input name="vergeml_tax_options[edit_all_as_hierarchical]" type="hidden" value="0" /><input name="vergeml_tax_options[edit_all_as_hierarchical]" type="checkbox" value="1" <?php checked( true, (bool) $vergeml_tax_options['edit_all_as_hierarchical'], true ); ?> /> <?php esc_html_e('Show non-hierarchical taxonomies like hierarchical in Grid View / Media Popup','vergelabs-media-library'); ?></label>
                                            </fieldset>
                                        </td>
                                    </tr>

                                    <?php
                                        /*
                                         *  The one setting that makes this behave like the folder
                                         *  plugins people arrive from.
                                         *
                                         *  A file here can sit in several folders at once, which is
                                         *  the thing neither FileBird nor Folders can do. It is also
                                         *  not what somebody switching from them expects: after years
                                         *  of folders that hold a file once, a drag that adds rather
                                         *  than moves reads as a bug.
                                         *
                                         *  Off by default, because the capability is the point. On,
                                         *  a plain drag moves and the library behaves exactly like
                                         *  the one they left. Either way nothing already filed is
                                         *  touched -- it changes what a drag means, not the data.
                                         */
                                    ?>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'One folder per file', 'vergelabs-media-library' ); ?><?php if ( function_exists( 'vergeml_help' ) ) { vergeml_help( 'one_folder_per_file' ); } ?></th>
                                        <td>
                                            <fieldset>
                                                <legend class="screen-reader-text"><span><?php esc_html_e( 'One folder per file', 'vergelabs-media-library' ); ?></span></legend>
                                                <label><input name="vergeml_tax_options[one_folder_per_file]" type="hidden" value="0" /><input name="vergeml_tax_options[one_folder_per_file]" type="checkbox" value="1" <?php checked( true, ! empty( $vergeml_tax_options['one_folder_per_file'] ), true ); ?> /> <?php esc_html_e( 'Dragging a file into a folder moves it, instead of adding it', 'vergelabs-media-library' ); ?></label>
</fieldset>
                                        </td>
                                    </tr>

                                </table>

                            </div>

                        </div>

                        <?php vergeml_acc_end(); ?>

                        </div><!-- .vgml-acc -->

                        <div class="vgml-savebar">
                            <?php submit_button( __( 'Save changes', 'vergelabs-media-library' ), 'primary', 'submit', false, array( 'id' => 'eml-submit-tax-settings' ) ); ?>
                            <span class="vgml-savebar-note"><?php esc_html_e( 'Saves everything on this page.', 'vergelabs-media-library' ); ?></span>
                        </div>

                        <?php
                            /*
                             *  A "Bulk Edit" settings box used to sit here, permanently
                             *  greyed out and labelled "/ Premium Feature". Its one
                             *  option, bulk_edit_save_button, was stored and validated
                             *  but never read by anything in this plugin: the behaviour
                             *  lived in the paid add-on. Removed rather than shipped as
                             *  a locked teaser for a product this is not.
                             */
                        ?>

                    </form>

                </div>

            </div>

        </div>

    </div>

    <?php
}



/**
 *  vergeml_print_mimetypes_options
 *
 *  @type     callback function
 *  @since    1.0
 *  @created  28/09/13
 */

function vergeml_print_mimetypes_options() {

    if ( ! current_user_can('manage_options' ) )
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );

    if ( is_multisite() ) {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        if ( ! current_user_can( 'manage_network_options' ) && ! vergeml_network_flag( 'media_settings' ) )
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'vergelabs-media-library' ) );
    }


    $vergeml_mimes = get_option('vergeml_mimes'); ?>

    <div id="vergeml-global-options-wrap" class="wrap eml-options">

        <?php
        echo vergeml_pg_head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the helper.
            __( 'File types', 'vergelabs-media-library' ),
            __( 'What may be uploaded, and how each type is labelled and filtered.', 'vergelabs-media-library' ),
            '<button type="button" class="button" id="eml-restore-mime-types-settings" name="eml-restore-mime-types-settings" value="1">' . esc_html__( 'Restore WordPress defaults', 'vergelabs-media-library' ) . '</button>'
                . '<a class="button button-primary vergeml-button-create-mime" href="javascript:;">' . esc_html__( 'Add a file type', 'vergelabs-media-library' ) . '</a>'
        );
        ?>
        <p class="vgml-ft-safety"><?php esc_html_e( 'WordPress role restrictions still apply to allowed types. SVG can carry scripts — keep it off unless a sanitizer plugin is installed and you trust the uploader with HTML.', 'vergelabs-media-library' ); ?></p>


        <div id="poststuff">

            <div id="post-body" class="metabox-holder">

                <div id="postbox-container-2" class="postbox-container">

                    <form method="post" action="options.php" id="vergeml-form-mimetypes">

                        <?php settings_fields( 'mime-types' ); ?>

                        <div class="vgml-ft-toolbar">
                            <input type="search" class="vgml-input" id="vgml-ft-q" placeholder="<?php esc_attr_e( 'Filter extensions or MIME types…', 'vergelabs-media-library' ); ?>" aria-label="<?php esc_attr_e( 'Filter file types', 'vergelabs-media-library' ); ?>">
                            <div class="vgml-ft-kinds" role="group" aria-label="<?php esc_attr_e( 'Kind of file', 'vergelabs-media-library' ); ?>">
                                <?php foreach ( array( 'all' => __( 'All', 'vergelabs-media-library' ), 'image' => __( 'Images', 'vergelabs-media-library' ), 'video' => __( 'Video', 'vergelabs-media-library' ), 'audio' => __( 'Audio', 'vergelabs-media-library' ), 'doc' => __( 'Documents', 'vergelabs-media-library' ), 'other' => __( 'Other', 'vergelabs-media-library' ) ) as $kind => $kind_label ) : ?>
                                    <button type="button" data-kind="<?php echo esc_attr( $kind ); ?>"<?php echo 'all' === $kind ? ' class="is-on"' : ''; ?>><?php echo esc_html( $kind_label ); ?></button>
                                <?php endforeach; ?>
                            </div>
                            <span class="vgml-ft-count" id="vgml-ft-count"></span>
                        </div>

                        <?php
                        $all_mimes = wp_get_mime_types();
                        ksort( $all_mimes, SORT_STRING );
                        $kind_of = function ( $mime ) {
                            if ( 0 === strpos( $mime, 'image/' ) ) { return 'image'; }
                            if ( 0 === strpos( $mime, 'video/' ) ) { return 'video'; }
                            if ( 0 === strpos( $mime, 'audio/' ) ) { return 'audio'; }
                            if ( preg_match( '#pdf|msword|officedocument|ms-excel|ms-powerpoint|text/plain|text/csv|rtf|opendocument|keynote|pages|numbers|wordperfect#', $mime ) ) { return 'doc'; }
                            return 'other';
                        };
                        $notes = array(
                            'svg'  => __( 'off until a sanitizer is installed — SVG can carry scripts', 'vergelabs-media-library' ),
                            'exe'  => __( 'blocked for safety', 'vergelabs-media-library' ),
                            'js'   => __( 'blocked for safety', 'vergelabs-media-library' ),
                            'html' => __( 'blocked for safety', 'vergelabs-media-library' ),
                            'php'  => __( 'blocked for safety', 'vergelabs-media-library' ),
                        );

                        /*
                         *  One section per kind, the kinds the filter above
                         *  already names. Ninety-eight types in one table was a
                         *  4,600px screen; a person came here to change one of
                         *  them and had to scroll past the other ninety-seven.
                         *
                         *  A new type goes into Other and stays there until it
                         *  is saved, because its kind is not known until it has
                         *  a MIME type. eml-mimetype-options.js clones into
                         *  .vgml-ft-new for that reason.
                         */
                        $vgml_ft_kinds = array(
                            'image' => __( 'Images', 'vergelabs-media-library' ),
                            'video' => __( 'Video', 'vergelabs-media-library' ),
                            'audio' => __( 'Audio', 'vergelabs-media-library' ),
                            'doc'   => __( 'Documents', 'vergelabs-media-library' ),
                            'other' => __( 'Other', 'vergelabs-media-library' ),
                        );

                        $vgml_ft_rows = array_fill_keys( array_keys( $vgml_ft_kinds ), array() );

                        foreach ( $all_mimes as $type => $mime ) {

                            if ( isset( $vergeml_mimes[ $type ] ) ) {
                                $vgml_ft_rows[ $kind_of( (string) $mime ) ][ $type ] = $mime;
                            }
                        }
                        ?>

                        <div class="vgml-acc" data-acc="mime-types">

                        <?php foreach ( $vgml_ft_kinds as $vgml_kind => $vgml_kind_label ) :

                            $vgml_kind_rows = $vgml_ft_rows[ $vgml_kind ];
                            $vgml_kind_up   = 0;

                            foreach ( $vgml_kind_rows as $vgml_row_type => $vgml_row_mime ) {

                                if ( ! empty( $vergeml_mimes[ $vgml_row_type ]['upload'] ) ) {
                                    $vgml_kind_up++;
                                }
                            }

                            vergeml_acc_start(
                                $vgml_kind,
                                $vgml_kind_label,
                                vergeml_acc_facts( array(
                                    /* translators: %d: how many file types are in this section. */
                                    sprintf( _n( '%d type', '%d types', count( $vgml_kind_rows ), 'vergelabs-media-library' ), count( $vgml_kind_rows ) ),
                                    /* translators: %d: how many of them may be uploaded. */
                                    sprintf( __( '%d may be uploaded', 'vergelabs-media-library' ), $vgml_kind_up ),
                                ) )
                            );
                            ?>

                        <table class="vergeml-mime-type-list wp-list-table widefat<?php echo 'other' === $vgml_kind ? ' vgml-ft-new' : ''; ?>" cellspacing="0">
                            <thead>
                            <tr>
                                <th scope="col" class="manage-column vergeml-column-extension"><?php esc_html_e('Extension','vergelabs-media-library'); ?></th>
                                <th scope="col" class="manage-column vergeml-column-mime"><?php esc_html_e('MIME type','vergelabs-media-library'); ?></th>
                                <th scope="col" class="manage-column vergeml-column-singular"><?php esc_html_e('Label','vergelabs-media-library'); ?></th>
                                <th scope="col" class="manage-column vergeml-column-plural"><?php esc_html_e('Plural','vergelabs-media-library'); ?></th>
                                <th scope="col" class="manage-column vergeml-column-filter"><?php esc_html_e('Filter','vergelabs-media-library'); ?></th>
                                <th scope="col" class="manage-column vergeml-column-upload"><?php esc_html_e('Upload','vergelabs-media-library'); ?></th>
                                <th scope="col" class="manage-column vergeml-column-delete"></th>
                            </tr>
                            </thead>


                            <tbody>

                            <?php foreach ( $vgml_kind_rows as $type => $mime ) :

                                if ( isset( $vergeml_mimes[$type] ) ) :

                                    $label = str_replace( '|', ' · ', esc_html( $type ) );
                                    $note  = '';
                                    foreach ( $notes as $ext => $text ) {
                                        if ( in_array( $ext, array_map( 'strtolower', explode( '|', $type ) ), true ) ) { $note = $text; break; }
                                    }

                                    $allowed = (bool) $vergeml_mimes[$type]['upload']; ?>
                                    <tr data-kind="<?php echo esc_attr( $kind_of( (string) $mime ) ); ?>" data-search="<?php echo esc_attr( strtolower( $type . ' ' . $mime . ' ' . $vergeml_mimes[$type]['singular'] . ' ' . $vergeml_mimes[$type]['plural'] ) ); ?>">
                                    <td id="<?php echo esc_attr( $type ); ?>"><?php echo esc_html( $label ); ?></td>
                                    <td><code><?php echo esc_html($mime); ?></code><?php if ( '' !== $note ) : ?><span class="vgml-ft-note"><?php echo esc_html( $note ); ?></span><?php endif; ?><input type="hidden" class="vergeml-mime" name="vergeml_mimes[<?php echo esc_attr($type); ?>][mime]" value="<?php echo esc_html($vergeml_mimes[$type]['mime']); ?>" /></td>
                                    <td><input type="text" name="vergeml_mimes[<?php echo esc_attr($type); ?>][singular]" value="<?php echo esc_html($vergeml_mimes[$type]['singular']); ?>" /></td>
                                    <td><input type="text" name="vergeml_mimes[<?php echo esc_attr($type); ?>][plural]" value="<?php echo esc_html($vergeml_mimes[$type]['plural']); ?>" /></td>
                                    <td class="checkbox_td"><input type="checkbox" name="vergeml_mimes[<?php echo esc_attr($type); ?>][filter]" title="<?php esc_html_e('Add Filter','vergelabs-media-library'); ?>" value="1" <?php checked(true, (bool) $vergeml_mimes[$type]['filter']); ?> /></td>
                                    <td class="checkbox_td"><input type="checkbox" name="vergeml_mimes[<?php echo esc_attr($type); ?>][upload]" title="<?php esc_html_e('Allow Upload','vergelabs-media-library'); ?>" value="1" <?php checked(true, $allowed); ?> /></td>
                                    <td><a class="vergeml-button-remove" title="<?php esc_html_e('Delete MIME Type','vergelabs-media-library'); ?>" href="javascript:;">&ndash;</a></td>
                                    </tr>

                                <?php endif; ?>
                            <?php endforeach; ?>

                            <?php if ( 'other' === $vgml_kind ) : ?>
                            <tr class="vergeml-clone" style="display:none;">
                                <td><input type="text" class="vergeml-type" placeholder="jpg|jpeg|jpe" /></td>
                                <td><input type="text" class="vergeml-mime" placeholder="image/jpeg" /></td>
                                <td><input type="text" class="vergeml-singular" placeholder="Image" /></td>
                                <td><input type="text" class="vergeml-plural" placeholder="Images" /></td>
                                <td class="checkbox_td"><input type="checkbox" class="vergeml-filter" title="<?php esc_html_e('Add Filter','vergelabs-media-library'); ?>" value="1" /></td>
                                <td class="checkbox_td"><input type="checkbox" class="vergeml-upload" title="<?php esc_html_e('Allow Upload','vergelabs-media-library'); ?>" value="1" /></td>
                                <td><a class="vergeml-button-remove" title="<?php esc_html_e('Delete MIME Type','vergelabs-media-library'); ?>" href="javascript:;">&ndash;</a></td>
                            </tr>
                            <?php endif; ?>

                            </tbody>
                        </table>

                        <?php vergeml_acc_end(); ?>

                        <?php endforeach; ?>

                        </div><!-- .vgml-acc -->

                        <div class="vgml-ft-empty" id="vgml-ft-empty" hidden>
                            <span><?php esc_html_e( 'Nothing matches that filter.', 'vergelabs-media-library' ); ?></span>
                            <button type="button" class="button" id="vgml-ft-clear"><?php esc_html_e( 'Clear the filter', 'vergelabs-media-library' ); ?></button>
                        </div>
                        <?php vergeml_print_mimetypes_buttons(); ?>
                        <script>
                        ( function () {
                            var q = document.getElementById( 'vgml-ft-q' );
                            var kinds = document.querySelectorAll( '.vgml-ft-kinds button' );
                            var rows = document.querySelectorAll( '.vergeml-mime-type-list tbody tr[data-kind]' );
                            var count = document.getElementById( 'vgml-ft-count' );
                            var empty = document.getElementById( 'vgml-ft-empty' );
                            var clear = document.getElementById( 'vgml-ft-clear' );
                            var kind = 'all';
                            var total = rows.length;
                            <?php /* translators: 1: how many file types are shown, 2: how many there are */ ?>
                            var shownOf = <?php echo wp_json_encode( __( '%1$s of %2$s types shown', 'vergelabs-media-library' ) ); ?>;
                            var sections = document.querySelectorAll( '.vgml-acc-item' );
                            /*
                             *  A filter that hides rows inside closed sections
                             *  finds nothing a person can see. So a filter opens
                             *  the sections that still have a row and closes the
                             *  ones that do not; with no filter on, the sections
                             *  are theirs again and js/vergeml-settings.js has
                             *  the last word.
                             */
                            function apply() {
                                var needle = ( q.value || '' ).trim().toLowerCase();
                                var shown = 0;
                                var live = {};
                                Array.prototype.forEach.call( rows, function ( r ) {
                                    var ok = ( kind === 'all' || r.getAttribute( 'data-kind' ) === kind ) && ( ! needle || r.getAttribute( 'data-search' ).indexOf( needle ) >= 0 );
                                    r.classList.toggle( 'is-hidden', ! ok );
                                    if ( ok ) { shown++; live[ r.getAttribute( 'data-kind' ) ] = true; }
                                } );
                                if ( 'all' !== kind || needle ) {
                                    Array.prototype.forEach.call( sections, function ( s ) {
                                        s.open = live[ s.getAttribute( 'data-section' ) ] === true;
                                    } );
                                }
                                count.textContent = shownOf.replace( '%1$s', String( shown ) ).replace( '%2$s', String( total ) );
                                empty.hidden = shown > 0;
                            }
                            q.addEventListener( 'input', apply );
                            Array.prototype.forEach.call( kinds, function ( b ) {
                                b.addEventListener( 'click', function () {
                                    kind = b.getAttribute( 'data-kind' );
                                    Array.prototype.forEach.call( kinds, function ( x ) { x.classList.toggle( 'is-on', x === b ); } );
                                    apply();
                                } );
                            } );
                            clear.addEventListener( 'click', function () {
                                q.value = '';
                                kind = 'all';
                                Array.prototype.forEach.call( kinds, function ( x ) { x.classList.toggle( 'is-on', x.getAttribute( 'data-kind' ) === 'all' ); } );
                                apply();
                            } );
                            apply();
                        }() );
                        </script>

                    </form>

                </div>

            </div>

        </div>

    </div>

    <?php
}



/**
 *  vergeml_print_mimetypes_buttons
 *
 *  @since    2.3.1
 *  @created  01/08/16
 */

function vergeml_print_mimetypes_buttons() { ?>

    <div class="vgml-savebar">
        <?php submit_button( __( 'Save changes', 'vergelabs-media-library' ), 'primary', 'eml-save-mime-types-settings', false, array( 'id' => 'eml-submit-settings-save-mime-types' ) ); ?>
        <span class="vgml-savebar-note"><?php esc_html_e( 'Saves everything on this page.', 'vergelabs-media-library' ); ?></span>
    </div>

    <?php
}



/**
 *  vergeml_print_credits
 *
 *  @since    1.0
 *  @created  28/09/13
 */

function vergeml_print_credits() { ?>

    <div class="postbox" id="vergeml-credits">

        <h3 class="hndle">VergeLabs Media Library <?php echo esc_html( VERGEML_VERSION ); ?></h3>

        <div class="inside">

            <h4><?php esc_html_e( 'Changelog', 'vergelabs-media-library' ); ?></h4>
            <p><?php esc_html_e( 'What\'s new in', 'vergelabs-media-library' ); ?> <a href="https://github.com/vergelabsnathan/vergelabs-media-library/releases"><?php esc_html_e( 'version', 'vergelabs-media-library' ); echo ' ' . esc_html( VERGEML_VERSION ); ?></a>.</p>

            <h4><?php esc_html_e( 'Support', 'vergelabs-media-library' ); ?></h4>
            <p><?php esc_html_e( 'Report a problem on', 'vergelabs-media-library' ); ?> <a href="https://github.com/vergelabsnathan/vergelabs-media-library/issues">GitHub</a>.</p>

            <div class="author">
                <span><?php esc_html_e( 'Based on', 'vergelabs-media-library' ); ?> <a href="https://wordpress.org/plugins/enhanced-media-library/">Enhanced Media Library</a> <?php esc_html_e( 'by', 'vergelabs-media-library' ); ?> <a href="https://wpuxsolutions.com/">wpUXsolutions</a></span>
            </div>

        </div>

    </div>

    <?php
}







/**
 *  vergeml_admin_notice
 *
 *  Shows a notice
 * 
 *  @since    2.8.10
 *  @created  2024/04
 */

add_action( 'admin_notices', 'vergeml_admin_notice' );
add_action( 'network_admin_notices', 'vergeml_admin_notice' );

function vergeml_admin_notice() {

    global // $pagenow,
           $current_screen;


    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }


    $notices = get_site_option( 'vergeml_notices', array() );


    if ( empty( $notices ) ) {
        return;
    }


    if ( ! isset( $notices['current'] ) ) {
        return;
    }


    $notice_id = $notices['current'];


    $user_id = get_current_user_id();
    if ( get_user_meta( $user_id, "vergeml_{$notice_id}_notice_dismissed" ) ) {
        return;
    }


    $notice = $notices[$notice_id];


    if (    ! empty( $notice['version'] ) && 
            version_compare( VERGEML_VERSION, $notice['version'], '>=' ) 
        ) {
        return;
    }


    if (    ! empty( $notice['for'] ) ) {

        // a notice for multisite users only
        if ( in_array( 'multisite', $notice['for'] ) && ! is_multisite() ) {
            return;
        }
    }


    if (    ! isset( $notice['screens'] ) || 
            ! in_array( $current_screen->base, $notice['screens'] ) 
        ) {
        return;
    }


    printf(
        '<div class="notice notice-%2$s is-dismissible eml-admin-notice dashicons-before" id="%3$s">
            %1$s
        </div>',
        wp_kses(
            $notice['message'],
            array(
                'p'      => array(),
                'a'      => array(
                    'href'   => array(),
                    'title'  => array(),
                    'class'  => array(),
                    'target' => array()
                ),
                'br'     => array(),
                'em'     => array(),
                'strong' => array( 
                    'class'  => array()
                )
            )
        ),
        esc_attr( $notice['type'] ),
        esc_html( $notice_id )
    );
}



/**
 *  vergeml_admin_notice_dismiss
 *
 *  Associates a dismissed notice mark with a user
 * 
 *  @since    2.8.10
 *  @created  2024/04
 */

add_action( 'wp_ajax_vergeml-admin-notice-dismiss', 'vergeml_admin_notice_dismiss' );

function vergeml_admin_notice_dismiss() {

    if ( ! isset( $_POST['notice_id'] ) )
        wp_die();


    check_ajax_referer( 'eml-admin-notice-nonce', 'nonce' );


    if ( ! isset( $_POST['notice_id'] ) )
        wp_send_json_error();

    $notice_id = sanitize_text_field( wp_unslash( $_POST['notice_id'] ) );
    $user_id = get_current_user_id();

    update_user_meta( $user_id, "vergeml_{$notice_id}_notice_dismissed", true );


    wp_die();
}




