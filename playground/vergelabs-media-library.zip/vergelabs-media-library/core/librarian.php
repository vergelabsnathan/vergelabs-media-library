<?php

if ( ! defined( 'ABSPATH' ) )
    exit;


/**
 *  The Librarian: review a proposed tree, apply it, take it back.
 *
 *  Phase 2 produced a proposal and stored it as data. Nothing read it, and
 *  nothing could act on it -- which meant the one thing the feature is for,
 *  showing somebody the folders their own library would get and letting them
 *  say yes, did not exist. This is that half.
 *
 *  Three things shape everything below.
 *
 *  1. **Undo is the feature, not the apology.** Applying writes one row per
 *     assignment it makes, with a flag saying whether this batch created the
 *     folder as well. Undo walks that log backwards and removes only what it
 *     finds there: a file the user has moved since is skipped and counted, a
 *     folder that has picked up manual content is kept and reported. Nothing
 *     is inferred from the proposal, because the proposal is what was asked
 *     for and the log is what actually happened -- and only one of those is
 *     safe to reverse.
 *
 *  2. **Only the unfiled.** A file that already sits in a folder is left
 *     alone and counted as skipped. Existing folders and existing assignments
 *     are never modified, so the worst case of pressing Apply on a library
 *     somebody has already organised by hand is that nothing happens.
 *
 *  3. **A chunk at a time, resumable, pausable.** The same shape as the
 *     importer and the scans: shared hosts time out at thirty seconds, the
 *     browser drives the loop, and the chunk size is the valve. A batch that
 *     is interrupted is `paused` with its exact progress rather than rolled
 *     back, because a half-applied batch that can be resumed or undone is
 *     recoverable and an automatic rollback of work somebody watched happen
 *     is not.
 *
 *  Two schemes are offered: the subject tree from the latest finished
 *  organise run, and a date/type scheme built here from post_date and the
 *  index's `kind`. The second costs no model call and no credit, which makes
 *  it the one a library with no AI index can still use.
 *
 *  @since 3.3
 */


const VERGEML_LIBRARIAN_BATCHES = 'vergeml_librarian_batches';
const VERGEML_LIBRARIAN_MOVES   = 'vergeml_librarian_moves';
const VERGEML_LIBRARIAN_VERSION = 4; // 3: a batch records who approved it, and a refusal the folder it nearly went to. 4: a move records the source of its hit (S16).
const VERGEML_LIBRARIAN_OPTION  = 'vergeml_librarian';

/*
 *  Files per step, and the floor it may be narrowed to.
 *
 *  Twenty-five rather than the importer's five hundred because each one is a
 *  term assignment rather than a row copy, and because this loop is watched:
 *  a step that returns in a second is a progress bar that moves, and a step
 *  that returns in ten is a page somebody reloads.
 */
const VERGEML_LIBRARIAN_CHUNK     = 25;
const VERGEML_LIBRARIAN_CHUNK_MIN = 5;

// What one step aims to take. Well under the thirty seconds shared hosting
// allows, because the aim is measured from the last step and the next one has
// to be wrong by a wide margin before it hurts.
const VERGEML_LIBRARIAN_STEP_MS = 3500;

// Batches kept per site, with their moves. The same rule as organise runs.
const VERGEML_LIBRARIAN_KEEP = 10;

// Thumbnails a branch shows on the review screen. Six is what fits a card
// without the card becoming a gallery.
const VERGEML_LIBRARIAN_SAMPLES = 6;


/**
 *  Both tables, registered on $wpdb the way core registers its own, and for
 *  the reason ai-index and organize do it: a name interpolated from a helper
 *  is a string the static analysis cannot follow, so every query built that
 *  way reads to Plugin Check as an unprepared one.
 */

vergeml_librarian_register_tables();

function vergeml_librarian_register_tables() {

    global $wpdb;

    $wpdb->vergeml_librarian_batches = $wpdb->prefix . VERGEML_LIBRARIAN_BATCHES;
    $wpdb->vergeml_librarian_moves   = $wpdb->prefix . VERGEML_LIBRARIAN_MOVES;

    foreach ( array( VERGEML_LIBRARIAN_BATCHES, VERGEML_LIBRARIAN_MOVES ) as $table ) {
        if ( ! in_array( $table, $wpdb->tables, true ) ) {
            $wpdb->tables[] = $table;
        }
    }
}


function vergeml_librarian_batches_table() {
    global $wpdb;
    return $wpdb->vergeml_librarian_batches;
}


function vergeml_librarian_moves_table() {
    global $wpdb;
    return $wpdb->vergeml_librarian_moves;
}


function vergeml_librarian_state() {
    $state = get_option( VERGEML_LIBRARIAN_OPTION, array() );
    return is_array( $state ) ? $state : array();
}


/**
 *  The taxonomy Apply targets.
 *
 *  The first media taxonomy the tree knows about, and only that one. A site
 *  with several must not see assignments leak into the others: one folder per
 *  file is a promise about one taxonomy, and honouring it across two would
 *  mean deciding which of somebody's own taxonomies is the real one.
 */

function vergeml_librarian_taxonomy() {

    $taxonomies = function_exists( 'vergeml_tree_taxonomies' ) ? vergeml_tree_taxonomies() : array();

    $primary = $taxonomies ? (string) $taxonomies[0] : '';

    return (string) apply_filters( 'vergeml_librarian_taxonomy', $primary );
}


/* ------------------------------------------------------------------ schema */

/**
 *  vergeml_librarian_install
 *
 *  Two tables: one row per batch, one row per assignment it made. Safe to
 *  call on every load -- dbDelta compares and issues only the difference.
 *
 *  The progress column is `step_cursor` and not `cursor` because CURSOR is a
 *  reserved word: MariaDB refuses the CREATE outright and dbDelta reports
 *  nothing when it does. organize.php learned this the same way. The REST
 *  field is still called `cursor`; only the column had to move.
 */

function vergeml_librarian_install() {

    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $batches = vergeml_librarian_batches_table();
    $moves   = vergeml_librarian_moves_table();
    $collate = $wpdb->get_charset_collate();

    /*
     *  dbDelta parses these rather than executing them, and is fussy in ways
     *  that fail silently: two spaces after PRIMARY KEY, KEY rather than
     *  INDEX, one field per line. TEXT columns carry no DEFAULT -- MySQL
     *  before 8.0.13 refuses one, and this plugin's floor is much older.
     *
     *  `user_id` and `approved_at` are who pressed it and when. A 0 there is
     *  not a gap: it is a batch nobody pressed -- cron, the nightly watch, a
     *  WP-CLI run -- and it has to stay readable as exactly that, the same way
     *  an empty `why` on a move does. `approved_at` is null beside it, because
     *  a moment nobody chose is not a moment. It is a column of its own rather
     *  than a reading of `created_at` because the two come apart as soon as
     *  anything is ever approved after the fact.
     */
    $sql = "CREATE TABLE {$batches} (
        batch_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        run_id bigint(20) unsigned NOT NULL DEFAULT 0,
        scheme varchar(32) NOT NULL DEFAULT '',
        status varchar(16) NOT NULL DEFAULT 'running',
        step_cursor int(10) unsigned NOT NULL DEFAULT 0,
        done_n int(10) unsigned NOT NULL DEFAULT 0,
        skip_n int(10) unsigned NOT NULL DEFAULT 0,
        params longtext NULL,
        reason varchar(191) NOT NULL DEFAULT '',
        user_id bigint(20) unsigned NOT NULL DEFAULT 0,
        approved_at datetime NULL,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY  (batch_id),
        KEY status (status),
        KEY created_at (created_at)
    ) {$collate};";

    dbDelta( $sql );

    /*
     *  One row per assignment this plugin made, which is the whole basis of
     *  undo. `term_created` says whether the folder came with it -- a folder
     *  that already existed is one the user owns, and undo must never delete
     *  it however empty it ends up.
     *
     *  And why it went there, which the matcher worked out and this plugin
     *  used to throw away the moment it had acted on it. `why` is the
     *  matcher's own word -- ok, floor, margin, gated -- or `plan` when a
     *  proposal chose the folder and a person approved it, or `by hand` when
     *  a person named it outright. `score` and `runner_score` are null on
     *  those last two, because there is no score: a null says nobody
     *  computed one, where 0.0 would say the matcher looked and found
     *  nothing.
     *
     *  `term_id = 0` is the row for a picture the matcher refused to move.
     *  It is the only row that answers the negative question -- which
     *  pictures sit somewhere the evidence does not support -- and it costs
     *  one row per picture a run looked at and left alone.
     *
     *  `prompt_hash` and `model_version` are copied from the index row the
     *  score was computed from, so a move points back at the exact
     *  description it rests on and that description already names the model
     *  and the prompt behind it.
     *
     *  `nearest` is the folder the matcher scored best and refused anyway --
     *  the one a `floor` or a `margin` row was about. Without it a refusal can
     *  say what it beat but not what it nearly was, which is the half of the
     *  sentence somebody actually wants: `runner_up` is the folder that came
     *  second, `nearest` the folder that came first and was not good enough.
     *  It is 0 on a placement, where the folder it went to is already the row.
     *
     *  `source` and `hit` (S16) say where the winning folder's best class hit
     *  came from -- plan, name, members, matches, word, or vector when no
     *  class hit at all -- and the pair it was, "picture phrase ~ folder
     *  word". Nathan's S15 verdict, "six of the seven wrong sures are words
     *  the folders learned from the fill's own misses", took a probe to say;
     *  with these two it is a query over the trail, and the why card can say
     *  it of one picture.
     *
     *  Additive and nullable, and nothing is backfilled: an empty `why` on an
     *  old row means the move happened before any of this shipped, and it has
     *  to stay readable as exactly that.
     */
    $sql = "CREATE TABLE {$moves} (
        move_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        batch_id bigint(20) unsigned NOT NULL DEFAULT 0,
        attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
        term_id bigint(20) unsigned NOT NULL DEFAULT 0,
        term_created tinyint(1) NOT NULL DEFAULT 0,
        undone tinyint(1) NOT NULL DEFAULT 0,
        why varchar(16) NOT NULL DEFAULT '',
        score float NULL,
        runner_up bigint(20) unsigned NOT NULL DEFAULT 0,
        runner_score float NULL,
        prompt_hash varchar(64) NOT NULL DEFAULT '',
        model_version varchar(64) NOT NULL DEFAULT '',
        nearest bigint(20) unsigned NOT NULL DEFAULT 0,
        source varchar(16) NOT NULL DEFAULT '',
        hit varchar(160) NOT NULL DEFAULT '',
        PRIMARY KEY  (move_id),
        KEY batch_id (batch_id),
        KEY batch_undone (batch_id,undone),
        KEY attachment_id (attachment_id)
    ) {$collate};";

    dbDelta( $sql );

    $state           = vergeml_librarian_state();
    $state['schema'] = VERGEML_LIBRARIAN_VERSION;

    update_option( VERGEML_LIBRARIAN_OPTION, $state, false );
}


// Called by name from vergeml_provision_site() (the main plugin file) on activation and on a version change.


/**
 *  Both tables, asked of the database rather than of the option.
 *
 *  One query for the pair -- the prefix plus the shared stem matches exactly
 *  these two -- because this is asked when a batch is created and the step
 *  loop after it has a budget to keep.
 */

function vergeml_librarian_tables_exist() {

    global $wpdb;

    $like = $wpdb->esc_like( $wpdb->prefix . 'vergeml_librarian_' ) . '%';

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $found = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );

    return in_array( vergeml_librarian_batches_table(), $found, true )
        && in_array( vergeml_librarian_moves_table(), $found, true );
}


/**
 *  A site that upgrades without ever visiting an admin screen never fires the
 *  activation hook, and the first thing it would do here is write to a table
 *  that does not exist. So the schema is also checked from the one endpoint
 *  that creates rows -- once, when a batch is created, never on the steps
 *  that follow, because those have a query budget and this would spend it.
 *
 *  The option alone is not enough to decide that, for ai-index.php's reason:
 *  a table dropped by hand, by a host's migration or by a half-restored
 *  backup leaves the option still saying the schema is current, and trusting
 *  it there means the next Apply writes into a table that is not there. So
 *  the database is asked as well.
 */

function vergeml_librarian_maybe_install() {

    $state = vergeml_librarian_state();

    if ( empty( $state['schema'] ) || VERGEML_LIBRARIAN_VERSION !== (int) $state['schema'] ) {
        vergeml_librarian_install();
        return;
    }

    if ( ! vergeml_librarian_tables_exist() ) {
        vergeml_librarian_install();
    }
}


add_action( 'admin_init', 'vergeml_librarian_housekeeping' );

function vergeml_librarian_housekeeping() {

    // admin_init also runs for admin-post.php without a login: an administrator's screen only.
    if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) ) {
        return;
    }

    vergeml_librarian_maybe_install();

    $state = vergeml_librarian_state();

    /*
     *  Pruning lives here rather than on a step, for organize's reason: the
     *  queries that find and drop the eleventh-oldest batch would come out of
     *  somebody's step budget, and dropping old rows is housekeeping.
     */
    $last = isset( $state['pruned'] ) ? (int) $state['pruned'] : 0;

    if ( time() - $last < DAY_IN_SECONDS ) {
        return;
    }

    vergeml_librarian_prune();

    $state['pruned'] = time();

    update_option( VERGEML_LIBRARIAN_OPTION, $state, false );
}


/* ------------------------------------------------------------ batch storage */

function vergeml_librarian_batch_get( $batch_id ) {

    global $wpdb;

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- this plugin's own table; there is no core API for it.
    $row = $wpdb->get_row( $wpdb->prepare(
        'SELECT * FROM %i WHERE batch_id = %d',
        $wpdb->vergeml_librarian_batches,
        (int) $batch_id
    ), ARRAY_A );
    // phpcs:enable

    return $row ? vergeml_librarian_batch_out( $row ) : null;
}


function vergeml_librarian_batch_out( $row ) {

    $params = json_decode( (string) $row['params'], true );

    return array(
        'batch_id'    => (int) $row['batch_id'],
        'run_id'      => (int) $row['run_id'],
        'scheme'      => (string) $row['scheme'],
        'status'      => (string) $row['status'],
        'cursor'      => (int) $row['step_cursor'],
        'done'        => (int) $row['done_n'],
        'skipped'     => (int) $row['skip_n'],
        'params'      => is_array( $params ) ? $params : array(),
        'reason'      => (string) $row['reason'],
        /*
         *  Read defensively: a batch row written before the columns shipped
         *  comes back without them, and this is also what the step loop reads
         *  on its way through vergeml_librarian_batch_save().
         */
        'user_id'     => isset( $row['user_id'] ) ? (int) $row['user_id'] : 0,
        'approved_at' => isset( $row['approved_at'] ) && null !== $row['approved_at'] ? (string) $row['approved_at'] : '',
        'created_at'  => (string) $row['created_at'],
        'updated_at'  => (string) $row['updated_at'],
    );
}


/**
 *  vergeml_librarian_batch_save
 *
 *  One query. A prepared UPDATE rather than $wpdb->update() for organize's
 *  reason: $wpdb->update() asks the table for its column charsets before it
 *  writes -- SHOW FULL COLUMNS, a query like any other -- and a step's budget
 *  cannot carry an introspection it does not need.
 */

function vergeml_librarian_batch_save( $batch ) {

    global $wpdb;

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    return false !== $wpdb->query( $wpdb->prepare(
        'UPDATE %i
            SET status = %s, step_cursor = %d, done_n = %d, skip_n = %d,
                params = %s, reason = %s, updated_at = %s
          WHERE batch_id = %d',
        $wpdb->vergeml_librarian_batches,
        (string) $batch['status'],
        (int) $batch['cursor'],
        (int) $batch['done'],
        (int) $batch['skipped'],
        wp_json_encode( $batch['params'] ),
        vergeml_librarian_reason( $batch['reason'] ),
        current_time( 'mysql', true ),
        (int) $batch['batch_id']
    ) );
    // phpcs:enable
}


/**
 *  A pause cause, cut to what the column holds.
 *
 *  Trimmed here rather than left to MySQL: a silent truncation on the way in
 *  is how a reason turns into half a sentence nobody can act on, and the
 *  reasons this carries are short by construction anyway.
 */

function vergeml_librarian_reason( $reason ) {

    $reason = trim( (string) $reason );

    if ( '' === $reason ) {
        return '';
    }

    // 188 plus the ellipsis: the column is 191, and a reason that reaches it
    // should say so rather than end mid-word.
    return mb_strlen( $reason ) > 191 ? mb_substr( $reason, 0, 188 ) . '…' : $reason;
}


/* -------------------------------------------------------------- the schemes */

/**
 *  vergeml_librarian_scheme_datetype
 *
 *  Year, then month, from post_date -- with the index's `kind` on each file's
 *  reason line so the folder says what it holds as well as when it arrived.
 *
 *  One query, whatever the library's size, and no model call: this is the
 *  scheme a site with no AI index can still use, and the one that costs
 *  nothing to offer. Deterministic by construction -- the rows come back in
 *  attachment id order and every grouping decision below is arithmetic on
 *  that order, so two calls produce the same tree and the suite says so.
 *
 *  Months smaller than a folder is worth fold up into their year, for the
 *  reason organize folds small clusters: eleven folders of two files each is
 *  not an organised library, it is the same mess with more clicking.
 */

function vergeml_librarian_scheme_datetype() {

    global $wpdb;

    $limits = function_exists( 'vergeml_organize_limits' )
        ? vergeml_organize_limits()
        : array( 'min_branch' => 5 );

    $min = max( 1, (int) $limits['min_branch'] );

    /*
     *  One pass. The join is LEFT because the index is optional here: a
     *  library that has never been described still has dates, and a scheme
     *  that needed the index would not be the fallback it exists to be.
     */
    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT p.ID AS id,
                    YEAR( p.post_date ) AS y,
                    MONTH( p.post_date ) AS m,
                    p.post_mime_type AS mime,
                    i.kind AS kind
               FROM {$wpdb->posts} p
               LEFT JOIN %i i ON i.attachment_id = p.ID
              WHERE p.post_type = 'attachment'
              ORDER BY p.ID ASC",
            $wpdb->vergeml_ai_index
        ),
        ARRAY_A
    );
    // phpcs:enable

    if ( ! $rows ) {
        return array();
    }

    // Grouped by year then month, in the order the rows arrived, so the tree
    // is a property of the library rather than of PHP's hashing.
    $years = array();

    foreach ( $rows as $row ) {

        $year  = (int) $row['y'];
        $month = (int) $row['m'];

        if ( ! isset( $years[ $year ] ) ) {
            $years[ $year ] = array();
        }

        if ( ! isset( $years[ $year ][ $month ] ) ) {
            $years[ $year ][ $month ] = array();
        }

        $years[ $year ][ $month ][] = array(
            'id'   => (int) $row['id'],
            'kind' => vergeml_librarian_kind( $row['kind'], $row['mime'] ),
        );
    }

    krsort( $years, SORT_NUMERIC ); // newest year first, which is what people look for

    $branches = array();

    foreach ( $years as $year => $months ) {

        ksort( $months, SORT_NUMERIC );

        $label   = (string) $year;
        $folded  = array();
        $kept    = array();

        foreach ( $months as $month => $files ) {
            if ( count( $files ) < $min ) {
                foreach ( $files as $file ) {
                    $folded[] = array( 'file' => $file, 'month' => $month );
                }
            } else {
                $kept[ $month ] = $files;
            }
        }

        $members = array();

        foreach ( $folded as $entry ) {
            $members[] = vergeml_librarian_datetype_member(
                $entry['file'],
                $entry['month'],
                (int) $year,
                true
            );
        }

        $total = count( $folded );

        foreach ( $kept as $files ) {
            $total += count( $files );
        }

        $branches[] = array(
            'key'     => $label,
            'label'   => $label,
            'path'    => array( $label ),
            'depth'   => 0,
            'parent'  => '',
            'size'    => count( $members ),
            'total'   => $total,
            'members' => $members,
            'capped'  => false,
            'reason'  => sprintf(
                /* translators: %s: a year, e.g. "2026". */
                __( 'Everything uploaded in %s. Months too small to be a folder of their own sit here rather than alone.', 'vergelabs-media-library' ),
                $label
            ),
        );

        foreach ( $kept as $month => $files ) {

            $name = vergeml_librarian_month_name( $month );

            $rows_out = array();

            foreach ( $files as $file ) {
                $rows_out[] = vergeml_librarian_datetype_member( $file, $month, (int) $year, false );
            }

            $branches[] = array(
                'key'     => $label . ' / ' . $name,
                'label'   => $name,
                'path'    => array( $label, $name ),
                'depth'   => 1,
                'parent'  => $label,
                'size'    => count( $rows_out ),
                'total'   => count( $rows_out ),
                'members' => $rows_out,
                'capped'  => false,
                'reason'  => sprintf(
                    /* translators: 1: a month name, 2: a year, 3: how many files. */
                    __( 'The %1$d files uploaded in %2$s %3$s.', 'vergelabs-media-library' ),
                    count( $rows_out ),
                    $name,
                    $label
                ),
            );
        }
    }

    /*
     *  The same shape organize emits, down to the agreement buckets, so the
     *  review screen renders both schemes with one code path. The distances
     *  are null here because there is no centre to be far from -- a date is
     *  not a guess -- and the buckets come out empty, which is the honest
     *  answer rather than a confidence figure invented for symmetry.
     */
    foreach ( $branches as $i => $branch ) {
        $branches[ $i ]['agreement'] = function_exists( 'vergeml_organize_agreement' )
            ? vergeml_organize_agreement( $branch['members'] )
            : array( 'close' => 0, 'mid' => 0, 'far' => 0 );
    }

    return function_exists( 'vergeml_organize_hydrate' )
        ? vergeml_organize_hydrate( $branches )
        : $branches;
}


function vergeml_librarian_datetype_member( $file, $month, $year, $folded ) {

    $name = vergeml_librarian_month_name( $month );

    if ( $folded ) {
        $why = sprintf(
            /* translators: 1: month and year, e.g. "March 2026", 2: what kind of file it is. */
            __( 'Uploaded %1$s · %2$s — filed under the year, because that month held too few files to be a folder.', 'vergelabs-media-library' ),
            $name . ' ' . $year,
            $file['kind']
        );
    } else {
        $why = sprintf(
            /* translators: 1: month and year, e.g. "March 2026", 2: what kind of file it is. */
            __( 'Uploaded %1$s · %2$s', 'vergelabs-media-library' ),
            $name . ' ' . $year,
            $file['kind']
        );
    }

    return array(
        'id'       => (int) $file['id'],
        'distance' => null,
        'why'      => $why,
    );
}


/**
 *  What a file is, in one word.
 *
 *  The index's answer when there is one, and the top half of the mime type
 *  when there is not -- a library nobody has described still knows the
 *  difference between an image and a PDF, and saying "photo" about a file
 *  nothing has looked at would be the kind of confident wrong answer this
 *  plugin exists not to give.
 */

function vergeml_librarian_kind( $kind, $mime ) {

    $kind = trim( (string) $kind );

    if ( '' !== $kind ) {
        return $kind;
    }

    $mime = (string) $mime;
    $at   = strpos( $mime, '/' );

    return false === $at ? __( 'file', 'vergelabs-media-library' ) : substr( $mime, 0, $at );
}


/**
 *  A month's name in the site's language, without a date object per file.
 */

function vergeml_librarian_month_name( $month ) {

    global $wp_locale;

    $month = max( 1, min( 12, (int) $month ) );

    if ( $wp_locale instanceof WP_Locale ) {
        return $wp_locale->get_month( $month );
    }

    return gmdate( 'F', gmmktime( 0, 0, 0, $month, 1, 2000 ) );
}


/**
 *  The newest finished organise run, or null.
 *
 *  Deliberately not vergeml_organize_run_latest(), which returns the newest
 *  run whatever state it is in: a run that is still clustering has no tree to
 *  review, and offering it as a scheme would open the review screen on an
 *  empty proposal.
 */

function vergeml_librarian_latest_done_run() {

    global $wpdb;

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $row = $wpdb->get_row(
        $wpdb->prepare( "SELECT * FROM %i WHERE status = 'done' ORDER BY run_id DESC LIMIT 1", $wpdb->vergeml_organize_runs ),
        ARRAY_A
    );
    // phpcs:enable

    return $row ? vergeml_organize_row_out( $row ) : null;
}


/**
 *  Whether a branch starts unchecked on the review screen.
 *
 *  "Needs a look" and anything the depth cap forced together are the two
 *  places the proposal is least sure of itself, so they are the two the
 *  person is asked about rather than told.
 */

function vergeml_librarian_flagged( $branch ) {

    if ( isset( $branch['key'] ) && 'needs-a-look' === $branch['key'] ) {
        return true;
    }

    return ! empty( $branch['capped'] );
}


/**
 *  The tree behind a scheme id.
 */

function vergeml_librarian_scheme_tree( $scheme, $run_id = 0 ) {

    if ( 'datetype' === $scheme ) {
        return vergeml_librarian_scheme_datetype();
    }

    if ( 'subject' !== $scheme ) {
        return array();
    }

    $run = $run_id > 0 ? vergeml_organize_run_get( $run_id ) : vergeml_librarian_latest_done_run();

    return ( $run && ! empty( $run['tree'] ) ) ? $run['tree'] : array();
}


/* ------------------------------------------------------------- the pre-flight */

/**
 *  vergeml_librarian_preflight
 *
 *  What pressing Apply would do, counted.
 *
 *  Built on organize's quote, which refuses rather than estimating when the
 *  duplicate scan has not run -- the same refusal is passed straight through,
 *  because a screen that quietly downgraded to an estimate would be exactly
 *  the thing the quote exists to prevent.
 */

function vergeml_librarian_preflight( $scheme, $run_id, $branches ) {

    $quote = vergeml_organize_quote();

    if ( is_wp_error( $quote ) ) {
        return $quote;
    }

    $taxonomy = vergeml_librarian_taxonomy();

    if ( '' === $taxonomy ) {
        return new WP_Error(
            'vergeml_librarian_no_taxonomy',
            __( 'You have no folders switched on yet, so there is nowhere to put anything.', 'vergelabs-media-library' ),
            array( 'status' => 409 )
        );
    }

    $plan = vergeml_librarian_plan( $scheme, $run_id, $branches, $taxonomy );

    if ( is_wp_error( $plan ) ) {
        return $plan;
    }

    $ids = array();

    foreach ( $plan['work'] as $pair ) {
        $ids[] = (int) $pair[0];
    }

    $filed = vergeml_librarian_filed( $ids, $taxonomy );

    $unfiled = count( $ids ) - count( $filed );

    $create = 0;
    $reuse  = 0;

    foreach ( $plan['terms'] as $term ) {
        if ( $term['id'] > 0 ) {
            $reuse++;
        } else {
            $create++;
        }
    }

    $state = vergeml_librarian_state();
    $rate  = isset( $state['rate_ms'] ) ? (float) $state['rate_ms'] : 0.0;

    /*
     *  The estimate is organize's: extrapolated from work actually measured,
     *  and honest about not being known when nothing has been measured yet.
     *  The rate comes from the last batch this site ran, so the first Apply
     *  says "not known" and every one after it says a number that came from
     *  this server rather than from a table in a plan.
     */
    $estimate = $rate > 0
        ? vergeml_organize_estimate( 1, $rate, $unfiled )
        : vergeml_organize_estimate( 0, 0.0, $unfiled );

    return array(
        'scheme'     => (string) $scheme,
        'run_id'     => (int) $plan['run_id'],
        'taxonomy'   => $taxonomy,
        'branches'   => count( $plan['branches'] ),
        'files'      => count( $ids ),
        'unfiled'    => $unfiled,
        'filed'      => count( $filed ),
        'folders'    => array( 'create' => $create, 'reuse' => $reuse ),
        'estimate'   => $estimate,
        'quote'      => $quote,
    );
}


/**
 *  Which of these files already sit in a folder.
 *
 *  One query for the whole set rather than a membership read per file: the
 *  pre-flight is allowed six queries and the review screen may hand it every
 *  id in the library.
 */

function vergeml_librarian_filed( $ids, $taxonomy ) {

    global $wpdb;

    $ids = array_values( array_unique( array_map( 'intval', (array) $ids ) ) );

    if ( ! $ids ) {
        return array();
    }

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $found = $wpdb->get_col( $wpdb->prepare(
        "SELECT DISTINCT tr.object_id
           FROM {$wpdb->term_relationships} tr
           JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
          WHERE tt.taxonomy = %s AND tr.object_id IN ( " . implode( ', ', array_fill( 0, count( $ids ), '%d' ) ) . ' )',
        array_merge( array( $taxonomy ), $ids )
    ) );
    // phpcs:enable

    return array_map( 'intval', (array) $found );
}


/* ------------------------------------------------------------------ the plan */

/**
 *  vergeml_librarian_plan
 *
 *  A tree plus the person's edits, resolved into the work a batch does.
 *
 *  Everything the review screen can say -- which branches are in, what they
 *  were renamed to, which were refused -- is settled here, once, at batch
 *  creation. A step then reads a list and does not have to know what a branch
 *  is, which is what keeps its query count flat.
 *
 *  Two queries at most: the run (for the subject scheme) or the library (for
 *  the date one), and the existing folders this plan would land in.
 */

function vergeml_librarian_plan( $scheme, $run_id, $branches, $taxonomy ) {

    $scheme = in_array( $scheme, array( 'subject', 'datetype' ), true ) ? $scheme : 'subject';

    if ( 'subject' === $scheme && $run_id <= 0 ) {
        $run = vergeml_librarian_latest_done_run();
        if ( $run ) {
            $run_id = (int) $run['run_id'];
        }
    }

    $tree = vergeml_librarian_scheme_tree( $scheme, $run_id );

    if ( ! $tree ) {
        return new WP_Error(
            'vergeml_librarian_no_tree',
            'subject' === $scheme
                ? __( 'There are no folders worked out yet. Do the “Work out the folders” step first.', 'vergelabs-media-library' )
                : __( 'This library has no files to file.', 'vergelabs-media-library' ),
            array( 'status' => 409 )
        );
    }

    /*
     *  The screen's edits, by branch key. A branch the caller said nothing
     *  about takes the default: in, unless it is one of the two kinds the
     *  proposal is least sure about.
     */
    $edits = array();

    foreach ( (array) $branches as $edit ) {

        if ( ! is_array( $edit ) || empty( $edit['key'] ) ) {
            continue;
        }

        $edits[ (string) $edit['key'] ] = array(
            'label'   => isset( $edit['label'] ) ? (string) $edit['label'] : '',
            'enabled' => ! isset( $edit['enabled'] ) || (bool) $edit['enabled'],
        );
    }

    $chosen = array();
    $work   = array();

    foreach ( $tree as $branch ) {

        $key = isset( $branch['key'] ) ? (string) $branch['key'] : '';

        if ( '' === $key || empty( $branch['members'] ) ) {
            continue;
        }

        $edit = isset( $edits[ $key ] ) ? $edits[ $key ] : null;

        if ( $edit ) {
            if ( ! $edit['enabled'] ) {
                continue; // "not this one": its members stay unfiled
            }
        } elseif ( vergeml_librarian_flagged( $branch ) ) {
            continue; // flagged branches are opted into, never defaulted in
        }

        $label = ( $edit && '' !== $edit['label'] ) ? $edit['label'] : (string) $branch['label'];

        $path = isset( $branch['path'] ) ? array_map( 'strval', (array) $branch['path'] ) : array( $label );

        // The rename is the folder's name, so it replaces the last step of
        // the path -- the ancestors keep the names their own branches gave
        // them, whether or not those branches are in this batch.
        if ( $path ) {
            $path[ count( $path ) - 1 ] = $label;
        } else {
            $path = array( $label );
        }

        $path = vergeml_librarian_clean_path( $path );

        if ( ! $path ) {
            continue;
        }

        $index = count( $chosen );

        $chosen[] = array(
            'key'   => $key,
            'label' => $path[ count( $path ) - 1 ],
            'path'  => $path,
        );

        foreach ( $branch['members'] as $member ) {
            if ( isset( $member['id'] ) ) {
                $work[] = array( (int) $member['id'], $index );
            }
        }
    }

    if ( ! $work ) {
        return new WP_Error(
            'vergeml_librarian_nothing_chosen',
            __( 'Nothing was chosen to file.', 'vergelabs-media-library' ),
            array( 'status' => 400 )
        );
    }

    return array(
        'scheme'   => $scheme,
        'run_id'   => (int) $run_id,
        'taxonomy' => $taxonomy,
        'branches' => $chosen,
        'terms'    => vergeml_librarian_resolve_terms( $chosen, $taxonomy ),
        'work'     => $work,
    );
}


/**
 *  A branch label, made into something a taxonomy will accept.
 *
 *  Clustering produces labels from tags, and tags come from a model: they can
 *  arrive with markup in them, as whitespace, or as an emoji. Sanitised, but
 *  never sanitised into nothing -- a folder called "" is worse than a folder
 *  with an odd name, so anything that empties falls back to a name that says
 *  what it is.
 */

function vergeml_librarian_clean_path( $path ) {

    $out = array();

    foreach ( (array) $path as $step ) {

        $name = sanitize_text_field( (string) $step );
        $name = trim( preg_replace( '/\s+/u', ' ', $name ) );

        if ( '' === $name ) {
            $name = __( 'Untitled folder', 'vergelabs-media-library' );
        }

        // Term names are stored in a 200-character column; a label that long
        // is a bug upstream, but it must not become a failed insert here.
        if ( mb_strlen( $name ) > 190 ) {
            $name = mb_substr( $name, 0, 190 );
        }

        $out[] = $name;
    }

    return $out;
}


/**
 *  vergeml_librarian_resolve_terms
 *
 *  Every folder this plan touches, and whether it already exists.
 *
 *  Existing folders are reused -- the decision, and the reason there is no
 *  suffixing anywhere in this file. A name that is already there at the same
 *  level is the user's folder, this batch adds to it, and the moves log says
 *  the folder was not created so undo will never remove it.
 *
 *  One query: every term in the taxonomy, name and parent, which is the same
 *  read the folder tree does on every page load.
 */

function vergeml_librarian_resolve_terms( $branches, $taxonomy ) {

    $existing = get_terms( array(
        'taxonomy'   => $taxonomy,
        'hide_empty' => false,
        // Names and parents are all this needs, and priming the meta for
        // every folder on the site is a query the pre-flight would spend for
        // nothing.
        'update_term_meta_cache' => false,
    ) );

    $by_parent = array();

    if ( ! is_wp_error( $existing ) ) {
        foreach ( $existing as $term ) {
            $by_parent[ (int) $term->parent ][ vergeml_librarian_name_key( $term->name ) ] = (int) $term->term_id;
        }
    }

    $terms = array();

    foreach ( $branches as $branch ) {

        $parent  = 0;
        $walked  = array();

        /*
         *  Once an ancestor is one this plan will have to create, nothing
         *  below it can already exist -- and looking it up anyway is how a
         *  folder gets reused that merely shares a name with one somewhere
         *  else in the tree. "2026 / March" under a year that is not there
         *  yet must not resolve to a top-level "March" somebody already has.
         */
        $pending = false;

        foreach ( $branch['path'] as $step ) {

            $walked[] = $step;
            $key      = implode( ' / ', $walked );

            if ( isset( $terms[ $key ] ) ) {
                $parent  = (int) $terms[ $key ]['id'];
                $pending = $pending || $parent <= 0;
                continue;
            }

            $name_key = vergeml_librarian_name_key( $step );

            $found = ( ! $pending && isset( $by_parent[ $parent ][ $name_key ] ) )
                ? (int) $by_parent[ $parent ][ $name_key ]
                : 0;

            $terms[ $key ] = array(
                'name'    => $step,
                'parent'  => $parent,
                'id'      => $found,
                'created' => 0,
            );

            $parent  = $found;
            $pending = $pending || $found <= 0;
        }
    }

    return $terms;
}


/**
 *  Names compared the way a person would compare them: case and surrounding
 *  space are not a difference. wp_insert_term takes the same view, so a plan
 *  that thought otherwise would ask for a folder the database then refuses as
 *  a duplicate.
 */

function vergeml_librarian_name_key( $name ) {
    return function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( (string) $name ) ) : strtolower( trim( (string) $name ) );
}


/* ----------------------------------------------------------------- applying */

/**
 *  vergeml_librarian_batch_create
 *
 *  The plan, resolved and written down. Two queries beyond the plan's own:
 *  none, and the insert.
 */

function vergeml_librarian_batch_create( $scheme, $run_id, $branches ) {

    global $wpdb;

    vergeml_librarian_maybe_install();

    $taxonomy = vergeml_librarian_taxonomy();

    if ( '' === $taxonomy ) {
        return new WP_Error(
            'vergeml_librarian_no_taxonomy',
            __( 'No category is set up to act as a folder yet, so there is nowhere to put anything.', 'vergelabs-media-library' ),
            array( 'status' => 409 )
        );
    }

    $plan = vergeml_librarian_plan( $scheme, $run_id, $branches, $taxonomy );

    if ( is_wp_error( $plan ) ) {
        return $plan;
    }

    /*
     *  The files that already have a folder are dropped here rather than
     *  skipped one at a time later, and it buys two things.
     *
     *  The first is the promise: a folder is never created for a branch whose
     *  files all turn out to be filed already, because that branch is not in
     *  the work list at all.
     *
     *  The second is the budget. Creating the folders a chunk happened to
     *  need made a step cost more the more branches it spanned -- 20 branches
     *  cost 198 queries against 123 for the same 80 files in 2 branches,
     *  measured, which is the shape of an N+1 even though nothing loops over
     *  a file. Knowing the whole work list up front means the folders can be
     *  made in a phase of their own, and every filing step after that is
     *  filing and nothing else.
     */
    $ids = array();

    foreach ( $plan['work'] as $pair ) {
        $ids[] = (int) $pair[0];
    }

    $filed = array_flip( vergeml_librarian_filed( $ids, $taxonomy ) );

    $work    = array();
    $wanted  = array();
    $skipped = 0;

    foreach ( $plan['work'] as $pair ) {

        if ( isset( $filed[ (int) $pair[0] ] ) ) {
            $skipped++;
            continue;
        }

        $work[] = $pair;

        $branch = $plan['branches'][ (int) $pair[1] ];

        $wanted[ implode( ' / ', $branch['path'] ) ] = true;
    }

    // Ancestors before the folders under them, so a term is never inserted
    // beneath a parent that does not exist yet.
    $folders = vergeml_librarian_folder_order( array_keys( $wanted ), $plan['terms'] );

    $params = array(
        'taxonomy' => $taxonomy,
        'branches' => $plan['branches'],
        'terms'    => $plan['terms'],
        'work'     => $work,
        'n'        => count( $work ),
        'folders'  => $folders,
        'folder_n' => 0,
        'phase'    => $folders ? 'folders' : 'files',
        'chunk'    => vergeml_librarian_chunk( 0.0 ),
        'timing'   => array( 'ms' => 0.0, 'n' => 0 ),
        'undo'     => array( 'cursor' => 0, 'undone' => 0, 'touched' => 0, 'removed' => 0, 'kept' => 0 ),
    );

    $now = current_time( 'mysql', true );

    /*
     *  Who is asking for this batch. A person pressing Sort has an id; the
     *  scheduler, the nightly watch and WP-CLI have none, and 0 with a null
     *  moment beside it is the honest record of that rather than a gap.
     */
    $user = (int) get_current_user_id();

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->insert(
        vergeml_librarian_batches_table(),
        array(
            'run_id'      => (int) $plan['run_id'],
            'scheme'      => (string) $plan['scheme'],
            'status'      => 'running',
            'step_cursor' => 0,
            'done_n'      => 0,
            'skip_n'      => $skipped,
            'params'      => wp_json_encode( $params ),
            'reason'      => '',
            'user_id'     => $user,
            'approved_at' => $user ? $now : null,
            'created_at'  => $now,
            'updated_at'  => $now,
        ),
        array( '%d', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s' )
    );
    // phpcs:enable

    return array(
        'batch_id'    => (int) $wpdb->insert_id,
        'run_id'      => (int) $plan['run_id'],
        'scheme'      => (string) $plan['scheme'],
        'status'      => 'running',
        'cursor'      => 0,
        'done'        => 0,
        'skipped'     => $skipped,
        'params'      => $params,
        'reason'      => '',
        'user_id'     => $user,
        'approved_at' => $user ? $now : '',
        'created_at'  => $now,
        'updated_at'  => $now,
    );
}


/**
 *  Every folder the work needs, ancestors first.
 *
 *  A branch two levels down needs its parent, and its parent may not be a
 *  branch anybody chose -- so the list is walked out of the resolved paths
 *  rather than out of the branches, and sorted by depth so a parent is always
 *  made before the folder that goes inside it.
 */

function vergeml_librarian_folder_order( $keys, $terms ) {

    $needed = array();

    foreach ( $keys as $key ) {

        $walked = array();

        foreach ( explode( ' / ', (string) $key ) as $step ) {
            $walked[] = $step;
            $needed[ implode( ' / ', $walked ) ] = true;
        }
    }

    $order = array();

    foreach ( array_keys( $needed ) as $key ) {
        // A folder that is already there needs no making, and putting it in
        // the list would only cost a lookup to discover that.
        if ( empty( $terms[ $key ]['id'] ) ) {
            $order[] = $key;
        }
    }

    usort( $order, 'vergeml_librarian_by_depth_asc' );

    return $order;
}


function vergeml_librarian_by_depth_asc( $a, $b ) {

    $depth_a = substr_count( (string) $a, ' / ' );
    $depth_b = substr_count( (string) $b, ' / ' );

    if ( $depth_a !== $depth_b ) {
        return $depth_a - $depth_b;
    }

    return strcmp( (string) $a, (string) $b );
}


/**
 *  How many files the next step takes.
 *
 *  Measured rather than chosen: the constant is a guess about somebody else's
 *  server, and the rate this host actually managed is not. Narrowed only --
 *  a fast host does not get a bigger chunk, because the browser is watching
 *  and a step that returns quickly is the point.
 */

function vergeml_librarian_chunk( $per_item_ms ) {

    $chunk = max( VERGEML_LIBRARIAN_CHUNK_MIN, (int) apply_filters( 'vergeml_librarian_chunk', VERGEML_LIBRARIAN_CHUNK ) );

    if ( $per_item_ms <= 0 ) {
        return $chunk;
    }

    $fits = (int) floor( VERGEML_LIBRARIAN_STEP_MS / $per_item_ms );

    return max( VERGEML_LIBRARIAN_CHUNK_MIN, min( $chunk, $fits ) );
}


/**
 *  vergeml_librarian_apply_step
 *
 *  One chunk of one batch: create the folders this chunk needs, file the
 *  files that are not filed already, and write down every assignment made.
 *
 *  Flat by construction. The work list was resolved when the batch was
 *  created, so a step reads a row, slices an array, and spends the rest of
 *  its budget on the files themselves -- it never walks the tree, never
 *  counts the branches, and costs the same on the fortieth step as on the
 *  first.
 */

function vergeml_librarian_apply_step( $batch_id ) {

    global $wpdb;

    $started = microtime( true );

    $batch = vergeml_librarian_batch_get( $batch_id );

    if ( ! $batch ) {
        return new WP_Error( 'vergeml_librarian_no_batch', __( 'That batch is not on record.', 'vergelabs-media-library' ), array( 'status' => 404 ) );
    }

    if ( in_array( $batch['status'], array( 'done', 'undone', 'undoing' ), true ) ) {
        return vergeml_librarian_report( $batch, $started );
    }

    $params = $batch['params'];
    $work   = isset( $params['work'] ) ? (array) $params['work'] : array();
    $total  = count( $work );

    if ( 'paused' === $batch['status'] ) {
        // Resuming is what asking for a step on a paused batch means.
        $batch['status'] = 'running';
        $batch['reason'] = '';
    }

    $cursor = (int) $batch['cursor'];

    $phase = isset( $params['phase'] ) ? (string) $params['phase'] : 'files';

    if ( 'folders' !== $phase && $cursor >= $total ) {
        $batch['status'] = 'done';
        vergeml_librarian_batch_save( $batch );
        return vergeml_librarian_report( $batch, $started );
    }

    $taxonomy = isset( $params['taxonomy'] ) ? (string) $params['taxonomy'] : vergeml_librarian_taxonomy();
    $chunk    = vergeml_librarian_chunk( vergeml_librarian_rate( $params ) );

    /*
     *  The folders first, in a phase of their own.
     *
     *  Making them here rather than inside the filing loop is what keeps a
     *  filing step's cost flat: it costs the same whether the batch has two
     *  branches or two hundred, and the same on its fortieth step as on its
     *  first. This phase is bounded too -- at most a chunk of folders a step
     *  -- so no single request has to make an unbounded number of them.
     */
    if ( isset( $params['phase'] ) && 'folders' === $params['phase'] ) {

        $made = 0;

        while ( $params['folder_n'] < count( $params['folders'] ) && $made < $chunk ) {

            $key = (string) $params['folders'][ $params['folder_n'] ];

            vergeml_librarian_term_for( $key, $params, $taxonomy );

            $params['folder_n'] = (int) $params['folder_n'] + 1;
            $made++;
        }

        if ( $params['folder_n'] >= count( $params['folders'] ) ) {
            $params['phase'] = 'files';
        }

        $batch['params'] = $params;
        $batch['status'] = 'running';

        vergeml_librarian_batch_save( $batch );

        return vergeml_librarian_report( $batch, $started );
    }

    $slice = array_slice( $work, $cursor, $chunk );

    $ids = array();

    foreach ( $slice as $pair ) {
        $ids[] = (int) $pair[0];
    }

    /*
     *  Both caches primed in one go, so the loop below asks the database
     *  nothing it could have been told once. Without this every file costs a
     *  membership read of its own and the budget goes from two a file to
     *  four.
     */
    if ( $ids ) {
        update_object_term_cache( $ids, 'attachment' );
    }

    /*
     *  The matcher (core/filing.php) as a veto. The scheme's clusters decide
     *  the branch; the matcher stops the placements it can prove wrong -- a
     *  picture gated out of that branch by kind or audience, or a misfit in a
     *  branch the planner has described. Everything it cannot judge, the
     *  cluster keeps.
     */
    $veto_rows = array();
    $veto_prof = array();
    if ( $ids && function_exists( 'vergeml_filing_pick' ) && isset( $wpdb->vergeml_ai_index ) ) {
        $branch_ids = array();
        foreach ( (array) $params['terms'] as $t ) {
            if ( ! empty( $t['id'] ) ) {
                $branch_ids[] = (int) $t['id'];
            }
        }
        $veto_prof = $branch_ids ? vergeml_filing_profiles( $branch_ids, $taxonomy ) : array();
        if ( $veto_prof ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- this plugin's own table, bound as an identifier; one %d per id and the ids are bound.
            foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT attachment_id, embedding, kind, filing FROM %i WHERE error = '' AND embedding IS NOT NULL AND attachment_id IN ( " . implode( ', ', array_fill( 0, count( $ids ), '%d' ) ) . ' )', array_merge( array( $wpdb->vergeml_ai_index ), $ids ) ), ARRAY_A ) as $r ) {
                $veto_rows[ (int) $r['attachment_id'] ] = $r;
            }
        }
    }

    $moves = array();
    $done  = (int) $batch['done'];
    $skip  = (int) $batch['skipped'];

    wp_defer_term_counting( true );

    foreach ( $slice as $pair ) {

        $attachment_id = (int) $pair[0];
        $branch_index  = (int) $pair[1];

        if ( ! isset( $params['branches'][ $branch_index ] ) ) {
            $skip++;
            continue;
        }

        $branch = $params['branches'][ $branch_index ];
        $key    = implode( ' / ', $branch['path'] );

        $current = get_object_term_cache( $attachment_id, $taxonomy );

        if ( false === $current ) {
            $current = wp_get_object_terms( $attachment_id, $taxonomy, array( 'fields' => 'all_with_object_id' ) );
            $current = is_wp_error( $current ) ? array() : $current;
        }

        // Already filed: left exactly as it is, and counted. This is the
        // promise the whole feature rests on -- Apply adds folders to files
        // that have none, and touches nothing else.
        if ( ! empty( $current ) ) {
            $skip++;
            continue;
        }

        /*
         *  Looked up, never made. Every folder this batch needs was created
         *  in the phase before this one, and a step that could still insert a
         *  term is a step whose cost depends on how many branches its chunk
         *  happened to span.
         */
        $term_id = isset( $params['terms'][ $key ]['id'] ) ? (int) $params['terms'][ $key ]['id'] : 0;

        if ( ! $term_id ) {
            $skip++;
            continue;
        }

        if ( isset( $veto_rows[ $attachment_id ], $veto_prof[ (int) $term_id ] ) ) {
            $facts  = vergeml_filing_facts( $veto_rows[ $attachment_id ] );
            $pick   = vergeml_filing_pick( $facts, $veto_prof );
            $gated  = isset( $pick['gated'][ (int) $term_id ] );
            $misfit = $facts['classes'] && 'plan' === $veto_prof[ (int) $term_id ]['source']
                && isset( $pick['scores'][ (int) $term_id ] ) && $pick['scores'][ (int) $term_id ] < VERGEML_FILING_MISFIT;
            if ( $gated || $misfit ) {
                $skip++;
                continue;
            }
        }
        $set = wp_set_object_terms( $attachment_id, array( (int) $term_id ), $taxonomy, false );

        if ( is_wp_error( $set ) ) {
            $skip++;
            continue;
        }

        /*
         *  The proposal put this picture in this branch and a person pressed
         *  Move on it, so 'plan' is the word: not the matcher, which only
         *  ever gets a veto here, and not a finger on one picture either.
         *  Nothing scored this placement, so nothing is written where the
         *  scores go.
         */
        $moves[] = array(
            (int) $batch['batch_id'],
            $attachment_id,
            (int) $term_id,
            (int) $params['terms'][ $key ]['created'],
            array( 'why' => 'plan' ),
        );

        $done++;
    }

    wp_defer_term_counting( false );

    if ( $moves ) {
        vergeml_librarian_moves_insert( $moves );
    }

    wp_cache_delete( 'vergeml_unassigned_' . $taxonomy, 'vergeml' );

    $cursor += count( $slice );

    $elapsed = ( microtime( true ) - $started ) * 1000;

    $params['timing']['ms'] = (float) $params['timing']['ms'] + $elapsed;
    $params['timing']['n']  = (int) $params['timing']['n'] + count( $slice );
    $params['chunk']        = $chunk;

    $batch['params']  = $params;
    $batch['cursor']  = $cursor;
    $batch['done']    = $done;
    $batch['skipped'] = $skip;
    $batch['status']  = $cursor >= $total ? 'done' : 'running';

    vergeml_librarian_batch_save( $batch );

    if ( 'done' === $batch['status'] ) {
        vergeml_librarian_remember_rate( $params );
        // The Move is complete: every open surface re-reads the tree and its counts.
        if ( function_exists( 'vergeml_folders_moved' ) ) {
            vergeml_folders_moved( 'librarian' );
        }
    }

    return vergeml_librarian_report( $batch, $started );
}


/**
 *  The folder a branch files into, created on the way if it is not there.
 *
 *  Ancestors first, because a term cannot be inserted under a parent that
 *  does not exist yet. Only the levels this chunk actually needs are created,
 *  so a batch of forty branches does not pay for forty folders on its first
 *  step -- which is what keeps a step's cost flat in the number of branches.
 */

function vergeml_librarian_term_for( $key, &$params, $taxonomy ) {

    if ( ! isset( $params['terms'][ $key ] ) ) {
        return 0;
    }

    if ( $params['terms'][ $key ]['id'] > 0 ) {
        return (int) $params['terms'][ $key ]['id'];
    }

    $parent_key = '';
    $at         = strrpos( $key, ' / ' );

    if ( false !== $at ) {
        $parent_key = substr( $key, 0, $at );
    }

    $parent = 0;

    if ( '' !== $parent_key ) {
        $parent = vergeml_librarian_term_for( $parent_key, $params, $taxonomy );

        if ( ! $parent ) {
            return 0;
        }
    }

    $name = (string) $params['terms'][ $key ]['name'];

    $term = wp_insert_term( $name, $taxonomy, array( 'parent' => (int) $parent ) );

    if ( is_wp_error( $term ) ) {

        /*
         *  The name is taken at this level. That is not a failure: the
         *  decision is that a collision reuses the folder somebody already
         *  has, so this batch adds to it and the moves log records that the
         *  folder was not created here -- which is what stops undo removing
         *  a folder it did not make.
         */
        $data = $term->get_error_data();

        $existing = 0;

        if ( is_array( $data ) && isset( $data['term_id'] ) ) {
            $existing = (int) $data['term_id'];
        } elseif ( is_numeric( $data ) ) {
            $existing = (int) $data;
        }

        if ( ! $existing ) {
            return 0;
        }

        $params['terms'][ $key ]['id']      = $existing;
        $params['terms'][ $key ]['created'] = 0;

        return $existing;
    }

    $params['terms'][ $key ]['id']      = (int) $term['term_id'];
    $params['terms'][ $key ]['created'] = 1;

    return (int) $term['term_id'];
}


/**
 *  The reason a move happened, in the shape the row keeps it.
 *
 *  What vergeml_filing_pick() returns is what this reads -- 'why', 'score',
 *  'runner_up', 'runner_score' -- so a caller that has a pick hands over the
 *  pick and assembles nothing. 'prompt_hash' and 'model_version' come from
 *  the index row the score was computed from, when the caller has it.
 *
 *  The words: 'ok', 'floor', 'margin' and 'gated' are the matcher's own, and
 *  come with numbers; so are 'agree' (the rules and the text model named the
 *  same folder, S18) and 'doubt' (the rules named one, the model said nothing
 *  fits -- left where it was, `nearest` the rules' folder). Their lines are
 *  Nathan's words (2026-09-18): "In X · both matches agree", "Left where it
 *  was · matched X, but in doubt". 'plan' is a proposal's
 *  placement a person approved, and
 *  'by hand' is a person naming the folder outright -- neither was scored, so
 *  both leave score and runner_score null. A null there says nobody computed
 *  one; a 0.0 would say the matcher looked and found nothing, which is a
 *  different thing and a false one.
 *
 *  An empty word is the fifth state: a move made before any of this shipped,
 *  or by a caller that has nothing to say. It is never backfilled.
 */

function vergeml_librarian_move_reason( $reason ) {

    $reason = is_array( $reason ) ? $reason : array();

    return array(
        'why'           => isset( $reason['why'] ) ? mb_substr( (string) $reason['why'], 0, 16 ) : '',
        'score'         => isset( $reason['score'] ) ? (float) $reason['score'] : null,
        'runner_up'     => isset( $reason['runner_up'] ) ? (int) $reason['runner_up'] : 0,
        'runner_score'  => isset( $reason['runner_score'] ) ? (float) $reason['runner_score'] : null,
        'prompt_hash'   => isset( $reason['prompt_hash'] ) ? mb_substr( (string) $reason['prompt_hash'], 0, 64 ) : '',
        'model_version' => isset( $reason['model_version'] ) ? mb_substr( (string) $reason['model_version'], 0, 64 ) : '',
        'nearest'       => isset( $reason['nearest'] ) ? (int) $reason['nearest'] : 0,
        'source'        => isset( $reason['source'] ) ? mb_substr( (string) $reason['source'], 0, 16 ) : '',
        'hit'           => isset( $reason['hit'] ) ? mb_substr( (string) $reason['hit'], 0, 160 ) : '',
    );
}


/**
 *  One INSERT for the whole chunk.
 *
 *  Twenty-five inserts would be twenty-five queries against a budget that has
 *  to hold two per file for the assignment itself. The rows are small and
 *  identical in shape, which is exactly the case a multi-row insert is for.
 *
 *  A row is [ batch, attachment, term, term_created ] and may carry a fifth
 *  element, the reason. Four elements still work and always will: a plan that
 *  was already in flight when this shipped finishes on the rows it started
 *  with, and writes an empty reason rather than a fatal.
 *
 *  The two scores are the one place a row can differ. A null cannot travel
 *  through prepare as %f -- it would arrive as 0.000000, which is the exact
 *  lie this column exists to avoid -- so each score travels with a flag, and
 *  the row turns a flag of 0 into NULL. Every row has the same shape, so the
 *  statement is one literal template repeated once per move.
 */

function vergeml_librarian_moves_insert( $moves ) {

    global $wpdb;

    $values = array( $wpdb->vergeml_librarian_moves );

    foreach ( $moves as $move ) {

        $reason = vergeml_librarian_move_reason( isset( $move[4] ) ? $move[4] : null );

        $values[] = (int) $move[0];
        $values[] = (int) $move[1];
        $values[] = (int) $move[2];
        $values[] = (int) $move[3];
        $values[] = $reason['why'];
        $values[] = null === $reason['score'] ? 0 : 1;
        $values[] = null === $reason['score'] ? 0.0 : $reason['score'];
        $values[] = $reason['runner_up'];
        $values[] = null === $reason['runner_score'] ? 0 : 1;
        $values[] = null === $reason['runner_score'] ? 0.0 : $reason['runner_score'];
        $values[] = $reason['prompt_hash'];
        $values[] = $reason['model_version'];
        $values[] = $reason['nearest'];
        $values[] = $reason['source'];
        $values[] = $reason['hit'];
    }

    // The table is an identifier (%i), then one row template per move; the number of placeholders grows with the number of moves, which the sniff cannot count.
    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
    $wpdb->query( $wpdb->prepare(
        'INSERT INTO %i
             ( batch_id, attachment_id, term_id, term_created, undone,
               why, score, runner_up, runner_score, prompt_hash, model_version,
               nearest, source, hit )
         VALUES ' . implode( ', ', array_fill( 0, count( $moves ), '( %d, %d, %d, %d, 0, %s, CASE WHEN %d = 1 THEN %f END, %d, CASE WHEN %d = 1 THEN %f END, %s, %s, %d, %s, %s )' ) ),
        $values
    ) );
    // phpcs:enable
}


function vergeml_librarian_rate( $params ) {

    $n = isset( $params['timing']['n'] ) ? (int) $params['timing']['n'] : 0;

    if ( $n <= 0 ) {
        return 0.0;
    }

    return (float) $params['timing']['ms'] / $n;
}


/**
 *  What this host managed, kept for the next batch's pre-flight.
 *
 *  The estimate on the review screen has to come from somewhere, and the only
 *  honest somewhere is the last time this server did this work.
 */

function vergeml_librarian_remember_rate( $params ) {

    $rate = vergeml_librarian_rate( $params );

    if ( $rate <= 0 ) {
        return;
    }

    $state            = vergeml_librarian_state();
    $state['rate_ms'] = round( $rate, 4 );

    update_option( VERGEML_LIBRARIAN_OPTION, $state, false );
}


/* -------------------------------------------------------------------- undo */

/**
 *  vergeml_librarian_undo_step
 *
 *  One chunk of a batch, taken back.
 *
 *  Newest first, and only what the log says this batch did. Three things it
 *  refuses to do, each of them a way a naive undo destroys work:
 *
 *  - a file the user has moved since keeps its new folder, and is counted;
 *  - a file that has gone is stepped over rather than fataled on;
 *  - a folder this batch created is deleted only if it is empty afterwards,
 *    and a folder that was already there is never deleted at all.
 */

function vergeml_librarian_undo_step( $batch_id ) {

    $started = microtime( true );

    $batch = vergeml_librarian_batch_get( $batch_id );

    if ( ! $batch ) {
        return new WP_Error( 'vergeml_librarian_no_batch', __( 'That batch is not on record.', 'vergelabs-media-library' ), array( 'status' => 404 ) );
    }

    if ( 'undone' === $batch['status'] ) {
        return vergeml_librarian_undo_report( $batch, 0, $started );
    }

    $params   = $batch['params'];
    $taxonomy = isset( $params['taxonomy'] ) ? (string) $params['taxonomy'] : vergeml_librarian_taxonomy();
    $undo     = isset( $params['undo'] ) ? (array) $params['undo'] : array( 'undone' => 0, 'touched' => 0, 'removed' => 0, 'kept' => 0 );

    /*
     *  Who pressed Undo, and when, recorded once.
     *
     *  It goes beside what the undo did rather than in a column of its own,
     *  because `user_id` and `approved_at` on the batch are the approval of the
     *  Move -- overwriting them with the undo's actor would lose the very thing
     *  they were added for. An undo walks in steps over the same request path,
     *  so the first step is the person and the rest are that person's browser
     *  finishing the job; 0 is cron or WP-CLI, the same reading as everywhere.
     */
    if ( ! isset( $undo['user_id'] ) ) {
        $undo['user_id'] = (int) get_current_user_id();
        $undo['at']      = current_time( 'mysql', true );
    }

    $batch['status'] = 'undoing';

    $chunk = vergeml_librarian_chunk( vergeml_librarian_rate( $params ) );

    $rows = vergeml_librarian_moves_pending( (int) $batch['batch_id'], $chunk );

    if ( ! $rows ) {

        $undo = vergeml_librarian_undo_folders( $params, $taxonomy, $undo );

        $batch['status'] = 'undone';
        $params['undo']  = $undo;
        $batch['params'] = $params;

        vergeml_librarian_batch_save( $batch );

        wp_cache_delete( 'vergeml_unassigned_' . $taxonomy, 'vergeml' );

        if ( function_exists( 'vergeml_folders_moved' ) ) {
            vergeml_folders_moved( 'librarian-undo' );
        }

        return vergeml_librarian_undo_report( $batch, 0, $started );
    }

    $ids = array();

    foreach ( $rows as $row ) {
        $ids[] = (int) $row['attachment_id'];
    }

    update_object_term_cache( $ids, 'attachment' );

    $done_ids = array();

    wp_defer_term_counting( true );

    foreach ( $rows as $row ) {

        $attachment_id = (int) $row['attachment_id'];
        $term_id       = (int) $row['term_id'];

        $done_ids[] = (int) $row['move_id'];

        $current = get_object_term_cache( $attachment_id, $taxonomy );

        if ( false === $current ) {
            $current = wp_get_object_terms( $attachment_id, $taxonomy, array( 'fields' => 'all_with_object_id' ) );
            $current = is_wp_error( $current ) ? array() : $current;
        }

        $held = array();

        foreach ( (array) $current as $term ) {
            $held[] = (int) $term->term_id;
        }

        // Moved, or gone. Either way this is not ours to take back, and the
        // person is told rather than the difference being quietly absorbed.
        if ( ! in_array( $term_id, $held, true ) ) {
            $undo['touched'] = (int) $undo['touched'] + 1;
            continue;
        }

        wp_remove_object_terms( $attachment_id, array( $term_id ), $taxonomy );

        $undo['undone'] = (int) $undo['undone'] + 1;
    }

    wp_defer_term_counting( false );

    if ( $done_ids ) {
        vergeml_librarian_moves_mark( $done_ids );
    }

    wp_cache_delete( 'vergeml_unassigned_' . $taxonomy, 'vergeml' );

    $params['undo']  = $undo;
    $batch['params'] = $params;

    vergeml_librarian_batch_save( $batch );

    return vergeml_librarian_undo_report( $batch, count( $rows ), $started );
}


/**
 *  The folders this batch created, removed if they are empty afterwards.
 *
 *  Once, on the step that finds nothing left to take back, rather than per
 *  chunk -- and over the batch's own record of what it created rather than
 *  over the folders the moves happen to name. Those are different sets, and
 *  the difference is a leak: a branch two levels deep makes its parent as
 *  well, no move ever names that parent, and a sweep driven by the moves
 *  leaves it behind empty for ever.
 *
 *  Deepest first, so a parent is judged after the children that would have
 *  kept it alive have already gone.
 *
 *  A folder that has picked up content since -- a manual drag, an upload
 *  filed into it -- is kept and counted, because deleting it would take
 *  somebody else's work with it. So is one that still has children: those are
 *  folders too, and they are not this batch's to judge.
 */

function vergeml_librarian_undo_folders( $params, $taxonomy, $undo ) {

    $terms = isset( $params['terms'] ) ? (array) $params['terms'] : array();

    $mine = array();

    foreach ( $terms as $key => $term ) {
        if ( ! empty( $term['created'] ) && ! empty( $term['id'] ) ) {
            $mine[ (string) $key ] = (int) $term['id'];
        }
    }

    if ( ! $mine ) {
        return $undo;
    }

    // By depth, deepest first. The key is the path, so its depth is how many
    // separators it carries.
    $keys = array_keys( $mine );

    usort( $keys, 'vergeml_librarian_by_depth' );

    $held = vergeml_librarian_term_objects( array_values( $mine ), $taxonomy );

    foreach ( $keys as $key ) {

        $term_id = $mine[ $key ];

        if ( ! get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
            continue;
        }

        $children = get_term_children( $term_id, $taxonomy );
        $children = is_wp_error( $children ) ? array() : $children;

        $in_it = isset( $held[ $term_id ] ) ? (int) $held[ $term_id ] : 0;

        if ( $in_it > 0 || $children ) {
            $undo['kept'] = (int) $undo['kept'] + 1;
            continue;
        }

        wp_delete_term( $term_id, $taxonomy );

        $undo['removed'] = (int) $undo['removed'] + 1;
    }

    return $undo;
}


function vergeml_librarian_by_depth( $a, $b ) {

    $depth_a = substr_count( (string) $a, ' / ' );
    $depth_b = substr_count( (string) $b, ' / ' );

    if ( $depth_a !== $depth_b ) {
        return $depth_b - $depth_a;
    }

    return strcmp( (string) $b, (string) $a );
}


/**
 *  The moves still to take back, newest first.
 *
 *  A row with no term is a picture a run looked at and left alone, and there
 *  is nothing in it to take back. It is excluded here rather than skipped in
 *  the loop, because the loop's skip counts as "moved, or gone" and would
 *  tell somebody that hundreds of their pictures had been touched since -- a
 *  sentence about an abstention that never moved anything.
 */

function vergeml_librarian_moves_pending( $batch_id, $limit ) {

    global $wpdb;

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    return (array) $wpdb->get_results( $wpdb->prepare(
        'SELECT move_id, attachment_id, term_id, term_created
           FROM %i
          WHERE batch_id = %d AND undone = 0 AND term_id > 0
          ORDER BY move_id DESC
          LIMIT %d',
        $wpdb->vergeml_librarian_moves,
        (int) $batch_id,
        (int) $limit
    ), ARRAY_A );
    // phpcs:enable
}


/**
 *  How many things are in these folders, asked of the database.
 *
 *  Not $term->count, and this is not fussiness: on this plugin's own test box
 *  a term holding three attachments reported a count of zero, because the
 *  cached figure is maintained by a callback that does not always run for
 *  attachments and is stale whenever it does not. Undo deletes folders. A
 *  destructive decision taken from a cached number that can be wrong is how
 *  somebody's folder disappears with their files' assignments inside it --
 *  which is the exact failure this whole feature exists to make impossible.
 *
 *  One query for the whole chunk, so asking honestly costs nothing.
 */

function vergeml_librarian_term_objects( $term_ids, $taxonomy ) {

    global $wpdb;

    $term_ids = array_values( array_unique( array_map( 'intval', (array) $term_ids ) ) );

    if ( ! $term_ids ) {
        return array();
    }

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $rows = (array) $wpdb->get_results( $wpdb->prepare(
        "SELECT tt.term_id AS term_id, COUNT( tr.object_id ) AS held
           FROM {$wpdb->term_taxonomy} tt
           LEFT JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
          WHERE tt.taxonomy = %s AND tt.term_id IN ( " . implode( ', ', array_fill( 0, count( $term_ids ), '%d' ) ) . ' )
          GROUP BY tt.term_id',
        array_merge( array( $taxonomy ), $term_ids )
    ), ARRAY_A );
    // phpcs:enable

    $out = array();

    foreach ( $rows as $row ) {
        $out[ (int) $row['term_id'] ] = (int) $row['held'];
    }

    return $out;
}


function vergeml_librarian_moves_mark( $move_ids ) {

    global $wpdb;

    $move_ids = array_map( 'intval', (array) $move_ids );

    if ( ! $move_ids ) {
        return;
    }

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->query( $wpdb->prepare(
        'UPDATE %i SET undone = 1 WHERE move_id IN ( ' . implode( ', ', array_fill( 0, count( $move_ids ), '%d' ) ) . ' )',
        array_merge( array( $wpdb->vergeml_librarian_moves ), $move_ids )
    ) );
    // phpcs:enable
}


/**
 *  The rows a Move's own undo reversed, marked as reversed.
 *
 *  vergeml_librarian_undo_step() marks the rows it walks through
 *  vergeml_librarian_moves_mark(); the Folders screen's undo put the terms
 *  back without touching the table at all, so its rows went on asserting
 *  placements that no longer held. `undone = 0` meant "no undo ran" on some
 *  rows and "an undo ran and this row does not know" on others, and nothing
 *  could tell them apart -- which is why vergeml_librarian_why() has to check
 *  whether the picture is still in the folder its newest row claims.
 *
 *  Two fences, and each one is a row that must not be marked:
 *
 *      term_id = 0   an abstention. Nothing moved, so nothing was reversed,
 *                    and the record of a picture the run looked at and left
 *                    alone stays true whatever the undo does.
 *      undone = 1    already marked, by this or by the librarian's own undo.
 *
 * @param array $batch_ids      The batches the Move's pass wrote.
 * @param array $attachment_ids The pictures the undo actually put back.
 * @return int How many rows were marked.
 */

function vergeml_librarian_moves_undone( $batch_ids, $attachment_ids ) {

    global $wpdb;

    $batch_ids      = array_values( array_unique( array_filter( array_map( 'intval', (array) $batch_ids ) ) ) );
    $attachment_ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $attachment_ids ) ) ) );

    if ( ! $batch_ids || ! $attachment_ids ) {
        return 0;
    }

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $done = $wpdb->query( $wpdb->prepare(
        'UPDATE %i
            SET undone = 1
          WHERE undone = 0
            AND term_id <> 0
            AND batch_id IN ( ' . implode( ', ', array_fill( 0, count( $batch_ids ), '%d' ) ) . ' )
            AND attachment_id IN ( ' . implode( ', ', array_fill( 0, count( $attachment_ids ), '%d' ) ) . ' )',
        array_merge( array( $wpdb->vergeml_librarian_moves ), $batch_ids, $attachment_ids )
    ) );
    // phpcs:enable

    return false === $done ? 0 : (int) $done;
}


/**
 *  Who reversed these batches, and when.
 *
 *  The Folders screen's undo is one press over a whole Move, so it stamps each
 *  batch that Move wrote. It goes in the batch's `params` beside what the undo
 *  did -- `user_id` and `approved_at` on the row are the approval of the Move
 *  itself, and an undo writing over those would lose exactly the fact they were
 *  added to keep.
 *
 *  Best effort, like everything on this path: an undo that puts a library back
 *  must not fail because a record could not be annotated.
 *
 * @param array $batch_ids The batches the Move wrote.
 * @param int   $user_id   Who pressed it; 0 for cron or WP-CLI.
 * @return int How many batches were stamped.
 */

function vergeml_librarian_batches_undone_by( $batch_ids, $user_id ) {

    $batch_ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $batch_ids ) ) ) );

    if ( ! $batch_ids ) {
        return 0;
    }

    $now     = current_time( 'mysql', true );
    $stamped = 0;

    foreach ( $batch_ids as $batch_id ) {

        $batch = vergeml_librarian_batch_get( $batch_id );

        if ( ! $batch ) {
            continue;
        }

        $params = $batch['params'];
        $undo   = isset( $params['undo'] ) ? (array) $params['undo'] : array();

        if ( isset( $undo['user_id'] ) ) {
            continue;
        }

        $undo['user_id'] = (int) $user_id;
        $undo['at']      = $now;

        $params['undo']  = $undo;
        $batch['params'] = $params;

        vergeml_librarian_batch_save( $batch );

        $stamped++;
    }

    return $stamped;
}


/* ----------------------------------------------------------------- reports */

function vergeml_librarian_report( $batch, $started ) {

    $params    = $batch['params'];
    $total     = isset( $params['n'] ) ? (int) $params['n'] : 0;
    $remaining = max( 0, $total - (int) $batch['cursor'] );

    return array(
        'batch_id'  => (int) $batch['batch_id'],
        'run_id'    => (int) $batch['run_id'],
        'scheme'    => (string) $batch['scheme'],
        'status'    => (string) $batch['status'],
        'done'      => (int) $batch['done'],
        'skipped'   => (int) $batch['skipped'],
        'cursor'    => (int) $batch['cursor'],
        'n'         => $total,
        'remaining' => $remaining,
        'phase'     => isset( $params['phase'] ) ? (string) $params['phase'] : 'files',
        'folders'   => array(
            'made'   => isset( $params['folder_n'] ) ? (int) $params['folder_n'] : 0,
            'needed' => isset( $params['folders'] ) ? count( $params['folders'] ) : 0,
        ),
        'chunk'     => isset( $params['chunk'] ) ? (int) $params['chunk'] : VERGEML_LIBRARIAN_CHUNK,
        'reason'    => (string) $batch['reason'],
        'step_ms'   => round( ( microtime( true ) - $started ) * 1000, 1 ),
        'estimate'  => vergeml_organize_estimate(
            isset( $params['timing']['n'] ) ? (int) $params['timing']['n'] : 0,
            isset( $params['timing']['ms'] ) ? (float) $params['timing']['ms'] : 0.0,
            $remaining
        ),
    );
}


function vergeml_librarian_undo_report( $batch, $walked, $started ) {

    $params = $batch['params'];
    $undo   = isset( $params['undo'] ) ? (array) $params['undo'] : array();

    $undone  = isset( $undo['undone'] ) ? (int) $undo['undone'] : 0;
    $touched = isset( $undo['touched'] ) ? (int) $undo['touched'] : 0;

    $total = isset( $params['n'] ) ? (int) $params['n'] : 0;

    return array(
        'batch_id'        => (int) $batch['batch_id'],
        'status'          => (string) $batch['status'],
        'undone'          => $undone,
        'skipped_touched' => $touched,
        'folders_removed' => isset( $undo['removed'] ) ? (int) $undo['removed'] : 0,
        'folders_kept'    => isset( $undo['kept'] ) ? (int) $undo['kept'] : 0,
        'remaining'       => max( 0, (int) $batch['done'] - $undone - $touched ),
        'n'               => $total,
        'walked'          => (int) $walked,
        'step_ms'         => round( ( microtime( true ) - $started ) * 1000, 1 ),
    );
}


/**
 *  vergeml_librarian_batches
 *
 *  The last few batches, for the history list and its Undo buttons. One
 *  query: every count the list shows is already a column on the row.
 */

function vergeml_librarian_batches( $limit = VERGEML_LIBRARIAN_KEEP ) {

    global $wpdb;

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $rows = (array) $wpdb->get_results( $wpdb->prepare(
        'SELECT batch_id, run_id, scheme, status, step_cursor, done_n, skip_n, reason, created_at, updated_at
           FROM %i
          ORDER BY batch_id DESC
          LIMIT %d',
        $wpdb->vergeml_librarian_batches,
        (int) $limit
    ), ARRAY_A );
    // phpcs:enable

    $out = array();

    foreach ( $rows as $row ) {
        $out[] = array(
            'batch_id'   => (int) $row['batch_id'],
            'run_id'     => (int) $row['run_id'],
            'scheme'     => (string) $row['scheme'],
            'status'     => (string) $row['status'],
            'cursor'     => (int) $row['step_cursor'],
            'done'       => (int) $row['done_n'],
            'skipped'    => (int) $row['skip_n'],
            'reason'     => (string) $row['reason'],
            'created_at' => (string) $row['created_at'],
            'updated_at' => (string) $row['updated_at'],
        );
    }

    return $out;
}


/* ----------------------------------------------------------------- pruning */

/**
 *  vergeml_librarian_prune
 *
 *  Keep the last few batches and their moves; drop the rest.
 *
 *  The only destructive act in this file that is not somebody pressing Undo,
 *  and it touches exactly two tables -- both of them ours. Never posts, never
 *  terms, never a relationship: a pruned batch is a batch that can no longer
 *  be undone, which is a smaller loss than a batch whose undo deleted a
 *  folder somebody had started using.
 */

function vergeml_librarian_prune( $keep = VERGEML_LIBRARIAN_KEEP ) {

    global $wpdb;

    $keep = max( 1, (int) $keep );

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $cutoff = (int) $wpdb->get_var( $wpdb->prepare(
        'SELECT batch_id FROM %i ORDER BY batch_id DESC LIMIT %d, 1',
        $wpdb->vergeml_librarian_batches,
        $keep
    ) );

    if ( $cutoff <= 0 ) {
        return 0;
    }

    $wpdb->query( $wpdb->prepare(
        'DELETE FROM %i WHERE batch_id <= %d',
        $wpdb->vergeml_librarian_moves,
        $cutoff
    ) );

    return (int) $wpdb->query( $wpdb->prepare(
        'DELETE FROM %i WHERE batch_id <= %d',
        $wpdb->vergeml_librarian_batches,
        $cutoff
    ) );
    // phpcs:enable
}


/* --------------------------------------------------------------------- REST */

add_action( 'rest_api_init', 'vergeml_librarian_routes' );

function vergeml_librarian_routes() {


    register_rest_route( VERGEML_REST_NS, '/librarian-schemes', array(
        'methods'             => WP_REST_Server::READABLE,
        'permission_callback' => 'vergeml_rest_can_manage_options',
        'callback'            => 'vergeml_librarian_rest_schemes',
        'args'                => array(
            // Naming one asks for its whole tree as well as its summary: the
            // review screen needs the members, and the date scheme has no run
            // row to fetch them from.
            'scheme' => array( 'type' => 'string', 'default' => '' ),
        ),
    ) );

    /*
     *  Readable, and creatable as well.
     *
     *  It is a read -- it changes nothing — but its input is the whole review
     *  screen: every branch, its rename and whether it is in. Forty of those
     *  in a query string is a URL long enough for a proxy to refuse, so the
     *  screen POSTs the same question and gets the same answer.
     */
    register_rest_route( VERGEML_REST_NS, '/librarian-preflight', array(
        'methods'             => 'GET, POST',
        'permission_callback' => 'vergeml_rest_can_manage_options',
        'callback'            => 'vergeml_librarian_rest_preflight',
        'args'                => array(
            'scheme'   => array( 'type' => 'string', 'default' => 'subject' ),
            'run_id'   => array( 'type' => 'integer', 'default' => 0 ),
            'branches' => array( 'type' => array( 'array', 'string' ), 'default' => array() ),
        ),
    ) );

    register_rest_route( VERGEML_REST_NS, '/librarian-apply-step', array(
        'methods'             => WP_REST_Server::CREATABLE,
        'permission_callback' => 'vergeml_rest_can_manage_options',
        'callback'            => 'vergeml_librarian_rest_apply',
        'args'                => array(
            'batch_id' => array( 'type' => 'integer', 'default' => 0 ),
            'scheme'   => array( 'type' => 'string', 'default' => 'subject' ),
            'run_id'   => array( 'type' => 'integer', 'default' => 0 ),
            'branches' => array( 'type' => array( 'array', 'string' ), 'default' => array() ),
        ),
    ) );

    /*
     *  Its own endpoint for the reason organize-cancel is one: a pause that
     *  had to wait for the step it was pausing would not be a pause.
     */
    register_rest_route( VERGEML_REST_NS, '/librarian-pause', array(
        'methods'             => WP_REST_Server::CREATABLE,
        'permission_callback' => 'vergeml_rest_can_manage_options',
        'callback'            => 'vergeml_librarian_rest_pause',
        'args'                => array(
            'batch_id' => array( 'type' => 'integer', 'required' => true ),
        ),
    ) );

    register_rest_route( VERGEML_REST_NS, '/librarian-undo-step', array(
        'methods'             => WP_REST_Server::CREATABLE,
        'permission_callback' => 'vergeml_rest_can_manage_options',
        'callback'            => 'vergeml_librarian_rest_undo',
        'args'                => array(
            'batch_id' => array( 'type' => 'integer', 'required' => true ),
        ),
    ) );

    register_rest_route( VERGEML_REST_NS, '/librarian-batches', array(
        'methods'             => WP_REST_Server::READABLE,
        'permission_callback' => 'vergeml_rest_can_manage_options',
        'callback'            => 'vergeml_librarian_rest_batches',
    ) );

    /*
     *  One picture's answer, asked for one picture at a time.
     *
     *  vergeml_why_here_field() is kept off `query-attachments` because that
     *  listing runs attachment_fields_to_edit for every item on the page --
     *  5.7 queries a picture, measured -- and the grid's modal renders from
     *  that same response, so the field never reaches it. This is how the
     *  modal gets the answer instead: on demand, for the picture somebody
     *  opened, and never for the eighty they scrolled past.
     *
     *  manage_categories is the librarian's permission and is not the one
     *  here: this reads one attachment's own record, so it asks the same
     *  question the screen it appears on asks -- may this person edit this
     *  picture. Mirrors core/quick-edit.php's route.
     */
    register_rest_route( VERGEML_REST_NS, '/librarian-why/(?P<id>\d+)', array(
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'vergeml_librarian_rest_why',
        'permission_callback' => 'vergeml_rest_can_edit_this_file',
    ) );
}


/**
 *  Both schemes, as much of them as was asked for.
 *
 *  A summary each -- what the top folders would be called and how big they
 *  are -- so the chooser can show two cards without loading two whole trees,
 *  and the full tree only for the one somebody picked.
 */

function vergeml_librarian_rest_schemes( WP_REST_Request $request ) {

    $wanted = (string) $request->get_param( 'scheme' );

    $run = vergeml_librarian_latest_done_run();

    $subject = ( $run && ! empty( $run['tree'] ) ) ? $run['tree'] : array();

    $datetype = ( 'datetype' === $wanted || ! $subject ) ? vergeml_librarian_scheme_datetype() : null;

    $out = array(
        'taxonomy' => vergeml_librarian_taxonomy(),
        'schemes'  => array(
            array(
                'id'      => 'subject',
                'label'   => __( 'By subject', 'vergelabs-media-library' ),
                'note'    => __( 'Pictures of the same thing end up together, and each folder is named after whatever most of the pictures in it show. Needs the describing step finished first.', 'vergelabs-media-library' ),
                'run_id'  => $run ? (int) $run['run_id'] : null,
                'ready'   => (bool) $subject,
                'total'   => vergeml_librarian_scheme_total( $subject ),
                'top'     => vergeml_librarian_scheme_top( $subject ),
            ),
            array(
                'id'      => 'datetype',
                'label'   => __( 'By date', 'vergelabs-media-library' ),
                'note'    => __( 'A folder per year, and a folder per month inside it, based on when each file was uploaded. Works on everything including videos and documents, and costs nothing.', 'vergelabs-media-library' ),
                'run_id'  => null,
                'ready'   => true,
                'total'   => null === $datetype ? null : vergeml_librarian_scheme_total( $datetype ),
                'top'     => null === $datetype ? array() : vergeml_librarian_scheme_top( $datetype ),
            ),
        ),
    );

    if ( 'subject' === $wanted ) {
        $out['tree']   = $subject;
        $out['scheme'] = 'subject';
        $out['run_id'] = $run ? (int) $run['run_id'] : 0;
    } elseif ( 'datetype' === $wanted ) {
        $out['tree']   = null === $datetype ? vergeml_librarian_scheme_datetype() : $datetype;
        $out['scheme'] = 'datetype';
        $out['run_id'] = 0;
    }

    return rest_ensure_response( $out );
}


function vergeml_librarian_scheme_total( $tree ) {

    $total = 0;

    foreach ( (array) $tree as $branch ) {
        $total += isset( $branch['size'] ) ? (int) $branch['size'] : 0;
    }

    return $total;
}


/**
 *  The handful of folders a scheme card shows. Label and size only -- a card
 *  that listed every branch would be the review screen with none of its
 *  controls.
 */

function vergeml_librarian_scheme_top( $tree, $take = 5 ) {

    $top = array();

    foreach ( (array) $tree as $branch ) {

        if ( count( $top ) >= $take ) {
            break;
        }

        if ( empty( $branch['size'] ) ) {
            continue;
        }

        $top[] = array(
            'key'     => isset( $branch['key'] ) ? (string) $branch['key'] : '',
            'label'   => isset( $branch['label'] ) ? (string) $branch['label'] : '',
            'size'    => (int) $branch['size'],
            'flagged' => vergeml_librarian_flagged( $branch ),
        );
    }

    return $top;
}


/**
 *  The branches a caller named, however they were sent.
 *
 *  A POST carries them as an array; a GET can only carry them as a string, so
 *  a JSON one is accepted too. Both end up as the same list, and neither is
 *  trusted further than key, label and a boolean.
 */

function vergeml_librarian_branch_arg( $value ) {

    if ( is_string( $value ) ) {
        $decoded = json_decode( $value, true );
        $value   = is_array( $decoded ) ? $decoded : array();
    }

    return is_array( $value ) ? $value : array();
}


function vergeml_librarian_rest_preflight( WP_REST_Request $request ) {

    $preflight = vergeml_librarian_preflight(
        (string) $request->get_param( 'scheme' ),
        (int) $request->get_param( 'run_id' ),
        vergeml_librarian_branch_arg( $request->get_param( 'branches' ) )
    );

    return is_wp_error( $preflight ) ? $preflight : rest_ensure_response( $preflight );
}


function vergeml_librarian_rest_apply( WP_REST_Request $request ) {

    $batch_id = (int) $request->get_param( 'batch_id' );

    if ( $batch_id <= 0 ) {

        $batch = vergeml_librarian_batch_create(
            (string) $request->get_param( 'scheme' ),
            (int) $request->get_param( 'run_id' ),
            vergeml_librarian_branch_arg( $request->get_param( 'branches' ) )
        );

        if ( is_wp_error( $batch ) ) {
            return $batch;
        }

        $batch_id = (int) $batch['batch_id'];
    }

    $result = vergeml_librarian_apply_step( $batch_id );

    return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
}


function vergeml_librarian_rest_pause( WP_REST_Request $request ) {

    $batch = vergeml_librarian_batch_get( (int) $request->get_param( 'batch_id' ) );

    if ( ! $batch ) {
        return new WP_Error( 'vergeml_librarian_no_batch', __( 'That batch is not on record.', 'vergelabs-media-library' ), array( 'status' => 404 ) );
    }

    if ( 'running' === $batch['status'] ) {
        $batch['status'] = 'paused';
        $batch['reason'] = __( 'Paused here.', 'vergelabs-media-library' );
        vergeml_librarian_batch_save( $batch );
    }

    return rest_ensure_response( vergeml_librarian_report( $batch, microtime( true ) ) );
}


function vergeml_librarian_rest_undo( WP_REST_Request $request ) {

    $result = vergeml_librarian_undo_step( (int) $request->get_param( 'batch_id' ) );

    return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
}


function vergeml_librarian_rest_batches() {
    return rest_ensure_response( array( 'batches' => vergeml_librarian_batches() ) );
}
/* ------------------------------------------------------------------- screen */

/**
 *  Where this library is on the ladder.
 *
 *  Four states, and each of them is a thing the screen can start in place
 *  rather than a message pointing at another page. The home card says which
 *  one applies so somebody can see whether there is anything to do here
 *  before clicking.
 */

function vergeml_librarian_stage() {

    $health = function_exists( 'vergeml_health_state' ) ? vergeml_health_state() : array();

    if ( empty( $health['finished'] ) ) {
        return 'unscanned';
    }

    $run = vergeml_librarian_latest_done_run();

    if ( $run && ! empty( $run['tree'] ) ) {
        return 'ready';
    }

    /*
     *  Described enough to move on, or not.
     *
     *  This used to be "has anything been described at all", which is true of
     *  a library where one picture in fifty has been looked at. On a library
     *  of ten that reads as a rounding error; on a library of five hundred it
     *  put "Describe the pictures — Done" on the screen with four hundred and
     *  ninety still undescribed, and then offered to build folders out of the
     *  ten. The step is finished when there is nothing left to describe.
     *
     *  Somebody who wants to go on with a part-described library still can --
     *  the step itself offers it -- but that is their decision to make and not
     *  something to decide for them by calling it done.
     */
    if ( function_exists( 'vergeml_ai_pending_count' ) && vergeml_ai_pending_count( 'unindexed' ) > 0 ) {
        return 'unindexed';
    }

    return function_exists( 'vergeml_organize_count' ) && vergeml_organize_count() > 0
        ? 'unproposed'
        : 'unindexed';
}


/**
 *  The steps, in order, with what each one is for.
 *
 *  Named here rather than in the script because they are sentences somebody
 *  reads, and sentences are translated. The script decides which one you are
 *  on; this decides what they are called and what they say.
 *
 *  Five, not three. The old ladder had three rungs and then silently became
 *  two more screens -- choosing a scheme, then reviewing it -- which is why
 *  somebody who had just watched a progress bar finish had no idea whether
 *  they were nearly done or halfway.
 */

/**
 *  Whether the tools below the flow have anything to work with.
 *
 *  Both of them move files into folders by comparing descriptions, so both
 *  need at least one folder to move into and at least one described file to
 *  compare. Either missing and every answer they can give is "nothing to do",
 *  which is not worth a heading, a paragraph and a button.
 */

function vergeml_librarian_tools_ready() {

    // reset() takes its argument by reference, so it cannot be handed a
    // function's return value directly -- PHP notices that on every load.
    $taxonomies = function_exists( 'vergeml_tree_taxonomies' ) ? vergeml_tree_taxonomies() : array();
    $taxonomy   = $taxonomies ? reset( $taxonomies ) : '';

    if ( ! $taxonomy ) {
        return false;
    }

    $folders = wp_count_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );

    if ( is_wp_error( $folders ) || (int) $folders < 1 ) {
        return false;
    }

    global $wpdb;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- this plugin's own table.
    return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE error = ''", $wpdb->vergeml_ai_index ) ) > 0;
}



/**
 *  Whether the looking is done.
 *
 *  One question, one answer, asked the same way by the screen and by the card
 *  on the dashboard. The scan and the describing are one step now, so this
 *  means both: a half-scanned library is not ready, and neither is one with
 *  four hundred pictures nobody has looked at.
 */

function vergeml_librarian_ready() {

    $health = function_exists( 'vergeml_health_state' ) ? vergeml_health_state() : array();

    if ( empty( $health['finished'] ) ) {
        return false;
    }

    return function_exists( 'vergeml_ai_pending_count' ) && 0 === vergeml_ai_pending_count( 'unindexed' );
}


function vergeml_librarian_card_text() {

    $stage = vergeml_librarian_stage();

    if ( 'unscanned' === $stage ) {
        return __( 'See the folders this library would get. We check for duplicates first, and start that for you.', 'vergelabs-media-library' );
    }

    if ( 'unindexed' === $stage ) {
        return __( 'See the folders this library would get. We look at your pictures first, and start that for you.', 'vergelabs-media-library' );
    }

    if ( 'unproposed' === $stage ) {
        return __( 'Your pictures are described. Next we work out what folders they should go in, show you the list, and file them once you say so — or file them by date instead, which costs nothing.', 'vergelabs-media-library' );
    }

    return __( 'A list of folders is waiting for you. Read it, drop any you do not want, file the rest in one go — and put everything back with one click if you change your mind.', 'vergelabs-media-library' );
}



function vergeml_librarian_page() {
    // The page is Folders (core/guide.php); this name stays for anything that still calls it.
    if ( function_exists( 'vergeml_folders_page' ) ) {
        vergeml_folders_page();
    }
}


/* ------------------------------------------------- why is this picture here */

/**
 *  What the record says about where one picture sits.
 *
 *  The moves table has carried the matcher's reasoning since the trail
 *  shipped, and nothing has ever read it back. This is the read: the folder,
 *  the word the matcher used, the score it reached, the folder it could not
 *  beat, the description the score was computed from, and the batch a person
 *  approved. All of it out of two tables that were written as a byproduct of
 *  the move -- nothing here reconstructs a score, and nothing re-runs the
 *  matcher, because a number worked out now would answer a question about
 *  today rather than about the day the picture moved.
 *
 *  It reads the row that explains where the picture is **now**, which is not
 *  always the last row written about it. The guide's own undo marks its rows
 *  undone now, and this still does not lean on that: a picture can be
 *  moved by hand, by a plugin or by another Move afterwards, and the newest
 *  row can describe a placement that no longer holds without any undo being
 *  involved. A row is only allowed to speak for a placement the library still
 *  agrees with. Failing that, an abstention -- which is a
 *  statement about a picture that did not move and so cannot go stale. Failing
 *  both, a row with no reason on it, which says only that the move happened
 *  before any of this was recorded.
 *
 *  One picture, on demand. Nothing calls this from a list.
 *
 *  @param int $attachment_id
 *  @return array|null The row's own values plus the lines that say them, or
 *                     null when the record has nothing about this picture.
 */
function vergeml_librarian_why( $attachment_id ) {

    global $wpdb;

    $attachment_id = (int) $attachment_id;

    if ( ! $attachment_id || ! isset( $wpdb->vergeml_librarian_moves ) ) {
        return null;
    }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- this plugin's own table, one picture, on demand.
    $rows = (array) $wpdb->get_results( $wpdb->prepare(
        'SELECT * FROM %i WHERE attachment_id = %d AND undone = 0 ORDER BY move_id DESC LIMIT 20',
        $wpdb->vergeml_librarian_moves,
        $attachment_id
    ), ARRAY_A );

    /*
     *  No record, but the person's own mark (a drag, VERGEML_FILING_PLACED_BY):
     *  that is one true thing to say, and the word beside it is "by you".
     */
    if ( ! $rows ) {
        if ( defined( 'VERGEML_FILING_PLACED_BY' ) && 'user' === (string) get_post_meta( $attachment_id, VERGEML_FILING_PLACED_BY, true ) ) {
            return array(
                'why' => 'by hand', 'term_id' => 0, 'term' => '', 'score' => null, 'runner_up' => 0, 'runner' => '', 'runner_score' => null,
                'nearest' => 0, 'near' => '', 'prompt_hash' => '', 'model_version' => '', 'batch_id' => 0, 'filed_at' => '',
                'confidence' => 'by you',
                'lines'      => array( __( 'Put here by hand · nothing scored it', 'vergelabs-media-library' ) ),
            );
        }
        return null;
    }

    $taxonomy = function_exists( 'vergeml_librarian_taxonomy' ) ? vergeml_librarian_taxonomy() : '';
    $in       = $taxonomy ? wp_get_object_terms( $attachment_id, $taxonomy, array( 'fields' => 'ids' ) ) : array();
    $in       = is_wp_error( $in ) ? array() : array_map( 'intval', (array) $in );

    $row = null;

    foreach ( $rows as $r ) {
        if ( (int) $r['term_id'] && in_array( (int) $r['term_id'], $in, true ) ) {
            $row = $r;
            break;
        }
    }

    if ( ! $row ) {
        foreach ( $rows as $r ) {
            if ( 0 === (int) $r['term_id'] && '' !== (string) $r['why'] ) {
                $row = $r;
                break;
            }
        }
    }

    /*
     *  Nothing left that speaks for where the picture is. A row with no reason
     *  on it still says one true thing -- that the move predates the record --
     *  so it is kept; a row with a reason that names a folder the picture is no
     *  longer in is dropped, because repeating it would explain a placement
     *  that is not the one on screen.
     */
    if ( ! $row && '' === (string) $rows[0]['why'] ) {
        $row = $rows[0];
    }

    if ( ! $row ) {
        return null;
    }

    $why    = (string) $row['why'];
    $term   = (int) $row['term_id'] ? get_term( (int) $row['term_id'], $taxonomy ) : null;
    $runner = (int) $row['runner_up'] ? get_term( (int) $row['runner_up'], $taxonomy ) : null;
    $term   = $term instanceof WP_Term ? $term->name : '';
    $runner = $runner instanceof WP_Term ? $runner->name : '';

    /*
     *  The folder a refusal was about, read out beside the one it beat.
     *
     *  Phase 4 stored the column and left the sentence alone because the
     *  wording was Nathan's and unsettled. It is settled now, and the margin
     *  line below names both folders from it.
     */
    $near = isset( $row['nearest'] ) && (int) $row['nearest'] ? get_term( (int) $row['nearest'], $taxonomy ) : null;
    $near = $near instanceof WP_Term ? $near->name : '';

    $score  = null === $row['score'] ? null : (float) $row['score'];
    $rscore = null === $row['runner_score'] ? null : (float) $row['runner_score'];

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- this plugin's own table.
    $filed = (int) $row['batch_id'] ? (string) $wpdb->get_var( $wpdb->prepare(
        'SELECT created_at FROM %i WHERE batch_id = %d',
        $wpdb->vergeml_librarian_batches,
        (int) $row['batch_id']
    ) ) : '';

    $out = array(
        'why'           => $why,
        'term_id'       => (int) $row['term_id'],
        'term'          => $term,
        'score'         => $score,
        'runner_up'     => (int) $row['runner_up'],
        'runner'        => $runner,
        'runner_score'  => $rscore,
        'nearest'       => isset( $row['nearest'] ) ? (int) $row['nearest'] : 0,
        'near'          => $near,
        'source'        => isset( $row['source'] ) ? (string) $row['source'] : '',
        'hit'           => isset( $row['hit'] ) ? (string) $row['hit'] : '',
        'prompt_hash'   => (string) $row['prompt_hash'],
        'model_version' => (string) $row['model_version'],
        'batch_id'      => (int) $row['batch_id'],
        'filed_at'      => $filed,
        // The pill beside the folder: by you / sure / likely, or nothing to claim.
        'confidence'    => function_exists( 'vergeml_filing_confidence' ) ? vergeml_filing_confidence( $attachment_id, $row ) : '',
        'lines'         => array(),
    );

    $n = function ( $v ) {
        return number_format_i18n( (float) $v, 2 );
    };

    if ( '' === $why ) {

        $out['lines'][] = __( 'Moved before the reason was recorded', 'vergelabs-media-library' );
        return $out;

    } elseif ( 'by hand' === $why ) {

        $out['lines'][] = __( 'Put here by hand · nothing scored it', 'vergelabs-media-library' );

    } elseif ( 'plan' === $why ) {

        $out['lines'][] = __( 'Chosen in a draft you approved · nothing scored it', 'vergelabs-media-library' );

    } elseif ( 'product' === $why ) {

        /* translators: 1: a folder name */
        $out['lines'][] = sprintf( __( 'In %1$s · by the product it belongs to', 'vergelabs-media-library' ), $term );

    } elseif ( 'doubt' === $why ) {

        // The rules named a folder, the text model said nothing fits (S18): left where it was. Nathan's words, 2026-09-18.
        if ( '' !== $near ) {
            /* translators: %s: the folder the rules would have used */
            $out['lines'][] = sprintf( __( 'Left where it was · matched %s, but in doubt', 'vergelabs-media-library' ), $near );
        }

    } elseif ( $out['term_id'] ) {

        if ( 'agree' === $why ) {
            // The rules and the text model named the same folder (S18): no score line, the two agreeing is the reason. Nathan's words, 2026-09-18.
            /* translators: %s: a folder name */
            $out['lines'][] = sprintf( __( 'In %s · both matches agree', 'vergelabs-media-library' ), $term );
        } else {
            /* translators: 1: a folder name, 2: a score, for example 0.81 */
            $out['lines'][] = sprintf( __( 'In %1$s · scored %2$s', 'vergelabs-media-library' ), $term, $n( $score ) );
        }

        if ( 'agree' !== $why && '' !== $runner && null !== $rscore ) {
            /* translators: 1: a folder name, 2: that folder's score, 3: the difference between the two scores */
            $out['lines'][] = sprintf( __( 'Ahead of %1$s at %2$s · by %3$s', 'vergelabs-media-library' ), $runner, $n( $rscore ), $n( $score - $rscore ) );
        }

        /*
         *  What the hit was, and whose word (S16). A row written before the
         *  columns existed says nothing here rather than half a sentence.
         */
        if ( '' !== $out['source'] && '' !== $out['hit'] ) {
            $whose = array(
                'plan'    => __( 'a word the planner gave the folder', 'vergelabs-media-library' ),
                'name'    => __( 'the folder\'s own name', 'vergelabs-media-library' ),
                'members' => __( 'a word its pictures taught it', 'vergelabs-media-library' ),
                'matches' => __( 'the planner\'s description of the folder', 'vergelabs-media-library' ),
                'word'    => __( 'the picture\'s own filename or title', 'vergelabs-media-library' ),
            );
            if ( isset( $whose[ $out['source'] ] ) ) {
                /* translators: 1: the pair "picture phrase ~ folder word", 2: whose word it was */
                $out['lines'][] = sprintf( __( 'Matched %1$s · %2$s', 'vergelabs-media-library' ), $out['hit'], $whose[ $out['source'] ] );
            }
        } elseif ( 'vector' === $out['source'] ) {
            $out['lines'][] = __( 'No word matched · placed by likeness alone', 'vergelabs-media-library' );
        }

        /*
         *  Why "likely" and not a child: the word mostly means "the parent,
         *  because no folder inside it claims the picture" (11 of 14 likely
         *  marked too broad on 2026-09-16 were Hardware at 0.60-0.63). The
         *  matcher descends to a child within 0.03 of the parent, so a parent
         *  that stands is one no child came near -- or two children tied for.
         */
        if ( 'siblings' === $why ) {
            $out['lines'][] = __( 'Two folders inside it tie for it', 'vergelabs-media-library' );
        } elseif ( 'likely' === $out['confidence'] && $out['term_id'] ) {
            $kids = get_term_children( $out['term_id'], $taxonomy );
            if ( ! is_wp_error( $kids ) && $kids ) {
                $out['lines'][] = __( 'No folder inside it fits better', 'vergelabs-media-library' );
            }
        }

    } elseif ( 'floor' === $why ) {

        /* translators: 1: the best score any folder reached, 2: the floor a score has to clear */
        $out['lines'][] = sprintf( __( 'Left where it was · best score %1$s, below the floor of %2$s', 'vergelabs-media-library' ), $n( $score ), $n( VERGEML_FILING_FLOOR ) );

    } elseif ( 'margin' === $why ) {

        /*
         *  Both folders, now that the row carries both names.
         *
         *  `nearest` is the folder the matcher scored best and refused anyway;
         *  the runner-up is the one it could not beat by the margin. A row
         *  written before either column existed can name neither, and the line
         *  is left off there rather than half-written -- the same choice the
         *  "Ahead of" line above makes when the record cannot say it.
         */
        if ( '' !== $near && null !== $score && '' !== $runner && null !== $rscore ) {
            /* translators: 1: the folder that scored best, 2: its score, 3: the runner-up's folder name, 4: the runner-up's score */
            $out['lines'][] = sprintf( __( 'Left where it was · %1$s scored %2$s against %3$s at %4$s, too close to call', 'vergelabs-media-library' ), $near, $n( $score ), $runner, $n( $rscore ) );
        }

    } elseif ( 'gated' === $why ) {

        $out['lines'][] = __( 'Left where it was · the wrong kind for the folder that fit', 'vergelabs-media-library' );

    }

    if ( '' !== $out['model_version'] || '' !== $out['prompt_hash'] ) {
        /* translators: 1: a model version, 2: the first characters of the prompt's hash */
        $out['lines'][] = sprintf(
            /* translators: 1: the name of the model that described the picture, 2: the prompt it used */
            __( 'Described by %1$s · prompt %2$s', 'vergelabs-media-library' ),
            '' === $out['model_version'] ? __( 'an earlier model', 'vergelabs-media-library' ) : $out['model_version'],
            '' === $out['prompt_hash'] ? __( 'unrecorded', 'vergelabs-media-library' ) : substr( $out['prompt_hash'], 0, 8 )
        );
    }

    /*
     *  Only a picture that was filed was filed. An abstention was looked at in
     *  the same batch on the same day, which is the same two facts under an
     *  honest verb -- so it gets the line as well, and not the one that would
     *  claim a move nobody made.
     */
    if ( $out['batch_id'] ) {

        $when = $filed
            ? wp_date( 'j F', strtotime( $filed . ' UTC' ) )
            : __( 'at an unrecorded moment', 'vergelabs-media-library' );

        $out['lines'][] = $out['term_id']
            /* translators: 1: a date, 2: the batch's number */
            ? sprintf( __( 'Filed %1$s · batch %2$s', 'vergelabs-media-library' ), $when, number_format_i18n( $out['batch_id'] ) )
            /* translators: 1: a date, 2: the batch's number */
            : sprintf( __( 'Looked at %1$s · batch %2$s', 'vergelabs-media-library' ), $when, number_format_i18n( $out['batch_id'] ) );
    }

    return $out;
}


/**
 *  "Why is it here", on every attachment's details.
 *
 *  Mirrors "Used in" (core/smart-folders.php): a field beside the delete
 *  button, answering the one question the screen could not. The list is the
 *  vgml-facts list the Folders screen uses, so a fact reads the same wherever
 *  it is read.
 */

add_filter( 'attachment_fields_to_edit', 'vergeml_why_here_field', 13, 2 );

function vergeml_why_here_field( $fields, $post ) {

    /*
     *  Not on the way past.
     *
     *  This filter is not only the details panel: wp_prepare_attachment_for_js()
     *  runs it through get_compat_media_markup() for every attachment it
     *  prepares, and the media grid's own `query-attachments` request prepares
     *  a whole page of them at once. Two queries a picture is nothing on the
     *  one picture somebody opened and eighty times that on a listing nobody
     *  asked this question of. So the listing is left alone and the answer is
     *  worked out where it is read.
     */
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- reading which request this is, not acting on it.
    if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'query-attachments' === sanitize_key( wp_unslash( $_REQUEST[ 'action' ] ) ) ) {
        return $fields;
    }

    $why = vergeml_librarian_why( $post->ID );

    if ( ! $why || ! $why['lines'] ) {
        return $fields; // No record, no claims.
    }

    $html = '<ul class="vgml-why-facts">';

    foreach ( $why['lines'] as $line ) {
        $html .= '<li>' . esc_html( $line ) . '</li>';
    }

    $html .= '</ul>';

    $fields['vergeml_why_here'] = array(
        'label' => __( 'Why is it here', 'vergelabs-media-library' ),
        'input' => 'html',
        'html'  => $html,
    );

    return $fields;
}


/**
 *  The same answer, for the screen the filter cannot reach.
 *
 *  The grid's modal is where most people meet a picture, and it draws its
 *  fields from the listing's response rather than asking for the picture it
 *  opened -- so the field above, which the listing is spared, is not in it.
 *  The lines come from vergeml_librarian_why() either way: one reader, two
 *  surfaces, and no second answer to keep in step with the first.
 */

function vergeml_librarian_rest_why( WP_REST_Request $request ) {

    $id   = (int) $request['id'];
    $post = get_post( $id );

    if ( ! $post || 'attachment' !== $post->post_type ) {
        return new WP_Error( 'vergeml_not_a_file', __( 'That is not a file in the library.', 'vergelabs-media-library' ), array( 'status' => 404 ) );
    }

    $why = vergeml_librarian_why( $id );

    // A picture with no record answers with no lines, and the view shows no
    // section -- exactly what the field does with the same nothing.
    return array(
        'id'         => $id,
        'label'      => __( 'Why is it here', 'vergelabs-media-library' ),
        'lines'      => ( $why && ! empty( $why['lines'] ) ) ? array_values( $why['lines'] ) : array(),
        // The word beside the folder (spec §3): 'by you' | 'sure' | 'likely' | '', and how the pill says it.
        'confidence' => $why ? (string) $why['confidence'] : '',
        'word'       => $why ? vergeml_librarian_word( (string) $why['confidence'] ) : '',
        'term'       => $why ? (string) $why['term'] : '',
    );
}

/** The confidence word as the pill says it. */
function vergeml_librarian_word( $confidence ) {
    $words = array(
        'sure'   => __( 'sure', 'vergelabs-media-library' ),
        'likely' => __( 'likely', 'vergelabs-media-library' ),
        'by you' => __( 'by you', 'vergelabs-media-library' ),
    );
    return isset( $words[ $confidence ] ) ? $words[ $confidence ] : '';
}


add_action( 'wp_enqueue_media', 'vergeml_why_here_assets' );

function vergeml_why_here_assets() {

    if ( ! is_admin() ) {
        return;
    }

    wp_enqueue_script(
        'vergeml-why-view',
        plugins_url( 'js/vergeml-why-view.js', VERGEML_FILE ),
        array( 'media-views', 'vergeml-transport' ),
        vergeml_asset_ver( 'js/vergeml-why-view.js' ),
        true
    );
}


