<?php

if ( ! defined( 'ABSPATH' ) )
    exit;


/**
 *  The folder tree, on Media > Library.
 *
 *  Grid and list, and nothing else in this phase -- the media modal is its own
 *  problem with seven contexts and it gets its own phase rather than being
 *  smuggled in here.
 *
 *  This file loads assets and hands the browser what it needs. It deliberately
 *  does not render the tree: the markup is built from the same endpoint the
 *  tree refreshes from, so there is one code path producing it and no chance of
 *  the first paint disagreeing with every paint after it.
 *
 *  @since 3.1
 */


/*
 *  Late on purpose. Whether a screen has a media modal is only knowable after
 *  whoever wanted one has asked for it, and wp_enqueue_media() is itself usually
 *  called from this same hook. At the default priority the answer is a coin toss
 *  depending on which plugin registered first.
 */
add_action( 'admin_enqueue_scripts', 'vergeml_tree_assets', 20 );

function vergeml_tree_assets( $hook ) {

    /*
     *  Which post type's list screen this is, if it is one and folders are on for
     *  it. Worked out first because it decides both whether to load at all and
     *  what to load -- a post screen gets one taxonomy and counts for that post
     *  type, not the media library's tree with the media library's numbers.
     */
    $folder_post_type = '';

    if ( 'edit.php' === $hook && function_exists( 'vergeml_folder_taxonomy_for' ) ) {

        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        $type   = ( $screen && $screen->post_type ) ? $screen->post_type : 'post';

        if ( vergeml_folder_taxonomy_for( $type ) ) {
            $folder_post_type = $type;
        }
    }

    /*
     *  Uploading is the wrong question on a post screen. Somebody who edits posts
     *  and cannot upload still has folders on their posts; what they may actually
     *  change is decided per object by the endpoint.
     */
    if ( $folder_post_type ) {
        if ( ! current_user_can( 'edit_posts' ) )
            return;
    } elseif ( ! current_user_can( 'upload_files' ) ) {
        return;
    }

    /*
     *  A page builder asking for the tree directly.
     *
     *  Elementor and Divi both open wp.media, but neither reaches this function
     *  the usual way: Elementor's editor runs on its own screen with its own
     *  enqueue hook, and Divi's visual builder runs on the *front end*, where
     *  admin_enqueue_scripts never fires at all. Everything below still applies;
     *  only the decision about whether to load is theirs to make.
     */
    $forced = ! empty( $GLOBALS['vergeml_force_tree'] );

    /*
     *  The library screen, and anywhere the media modal can be opened.
     *
     *  This used to load on upload.php alone, which meant the tree did not exist
     *  when inserting an image into a post -- half of what a media library is for.
     *
     *  Decided by asking whether wp.media is on the screen rather than by listing
     *  screens, because that list goes stale: a plugin, a block, a metabox or the
     *  next release of core can open a media modal anywhere. did_action gives the
     *  honest answer, and everything below is a no-op when there is no frame.
     */
    $library = ( 'upload.php' === $hook );

    // The one script every media modal needs. If it is going out, a frame can be
    // opened on this screen; if it is not, nothing below would have anything to
    // attach to anyway.
    $modal = wp_script_is( 'media-views', 'enqueued' ) || wp_script_is( 'media-views', 'to_do' );

    if ( ! $library && ! $modal && ! $folder_post_type && ! $forced )
        return;

    $taxonomies = $folder_post_type
        ? array( vergeml_folder_taxonomy_for( $folder_post_type ) )
        : vergeml_tree_taxonomies();

    if ( empty( $taxonomies ) )
        return;

    wp_enqueue_style(
        'vergeml-tree',
        plugins_url( 'css/vergeml-tree.css', VERGEML_FILE ),
        array(),
        vergeml_asset_ver( 'css/vergeml-tree.css' )
    );

    /*
     *  The list-mode screen ships no uploader at all, which made every road
     *  into a folder -- the row drop, the Upload button -- dead on arrival
     *  there. plupload plus its printed settings is all the tree needs to
     *  build one of its own when files actually arrive.
     */
    wp_enqueue_script( 'wp-plupload' );
    wp_plupload_default_settings();

    /*
     *  The grid's attachment-details modal, for the list screen. Clicking a
     *  file in the list navigated to the classic edit page while the grid
     *  opened a modal; same gesture, two different rooms. The modal machinery
     *  (media views plus media-grid's EditAttachments frame) only ships on
     *  the grid screen unless asked for.
     */
    wp_enqueue_media();
    wp_enqueue_script( 'media-grid' );

    if ( is_rtl() ) {
        wp_enqueue_style(
            'vergeml-tree-rtl',
            plugins_url( 'css/vergeml-tree-rtl.css', VERGEML_FILE ),
            array( 'vergeml-tree' ),
            vergeml_asset_ver( 'css/vergeml-tree-rtl.css' )
        );
    }

    wp_enqueue_script(
        'vergeml-tree',
        plugins_url( 'js/vergeml-tree.js', VERGEML_FILE ),
        /*
         *  jQuery UI draggable/droppable rather than the HTML5 drag API.
         *
         *  Both ship with WordPress and core's own media grid already uses them,
         *  so this costs no download and adds no dependency. It matters because
         *  the HTML5 API hands the browser control of the drag image, has no
         *  distance threshold -- so a sloppy click becomes a drag -- and does not
         *  work on touch at all. jQuery UI is plain pointer events with a helper
         *  element we own, which is why it can show a real tile with a count.
         */
        // vergeml-transport first, so the fallback road is installed before the
        // tree makes its first request rather than after its first failure.
        array( 'wp-api-fetch', 'vergeml-transport', 'jquery', 'jquery-ui-draggable', 'jquery-ui-droppable' ),
        vergeml_asset_ver( 'js/vergeml-tree.js' ),
        true
    );

    // One finger as the mouse jQuery UI listens for. See the file's header.
    wp_enqueue_script(
        'vergeml-touch',
        plugins_url( 'js/vergeml-touch.js', VERGEML_FILE ),
        array( 'vergeml-tree' ),
        vergeml_asset_ver( 'js/vergeml-touch.js' ),
        true
    );

    $list = array();

    foreach ( $taxonomies as $name ) {

        $object = get_taxonomy( $name );

        if ( ! $object instanceof WP_Taxonomy || ! $object->hierarchical )
            continue; // A flat taxonomy drawn as a tree is a lie about the data.

        $list[] = array(
            'name'  => $name,
            'label' => $object->labels->name,
        );
    }

    if ( empty( $list ) )
        return;

    $state = vergeml_tree_state( $list[0]['name'] );

    /*
     *  The tree travels with the page, so opening the library never fetches it.
     *
     *  It used to render empty and then call vergeml/v1/tree, which meant a blank
     *  panel followed by a pop -- on every single visit, for data this request
     *  already had in hand. The endpoint stays, because everything after the first
     *  paint still uses it, but the first paint costs nothing.
     *
     *  Built by calling the REST handler rather than by repeating its query here:
     *  one code path produces the tree, so the first paint cannot disagree with
     *  every paint after it.
     */
    $boot = null;

    if ( class_exists( 'WP_REST_Request' ) && function_exists( 'vergeml_rest_tree' ) ) {

        $request = new WP_REST_Request( 'GET', '/' . VERGEML_REST_NS . '/tree' );
        $request->set_param( 'taxonomy', $list[0]['name'] );

        if ( $folder_post_type ) {
            $request->set_param( 'post_type', $folder_post_type );
        }

        $result = vergeml_rest_tree( $request );

        if ( $result instanceof WP_REST_Response ) {
            $boot = $result->get_data();
        }
    }

    wp_localize_script( 'vergeml-tree', 'vergemlTree', array(
        'taxonomies' => $list,
        'state'      => $state,
        'boot'       => $boot,
        'canManage'  => current_user_can( 'manage_categories' ),
        /*
         *  The modal is a different room: about 700px wide, opened to pick a file
         *  rather than to reorganise. The panel is collapsible there, folders can
         *  be dragged into but not renamed or deleted, and it always opens on All
         *  files -- the folder someone was browsing on the library screen is
         *  rarely the one they want when inserting an image into a post.
         */
        'onLibrary'  => $library || (bool) $folder_post_type,
        /*
         *  Which list the tree is filtering. 'attachment' everywhere it always
         *  was, so nothing that reads this has to know post folders exist.
         */
        'postType'   => $folder_post_type ? $folder_post_type : 'attachment',
        /*
         *  A plain drag always moves -- the default every file manager taught.
         *  Ctrl-drag adds to a second folder, the thing the competitors cannot
         *  do, on the modifier that has always meant "copy". This setting is for
         *  keeping the single-folder promise absolute: with it on, Ctrl is
         *  ignored and every drop is a move.
         */
        'onePerFile' => ! empty( get_option( 'vergeml_tax_options', array() )['one_folder_per_file'] ),
        'palette'    => vergeml_tree_palette(),
        'skins'      => vergeml_tree_skins(),
        'densities'  => vergeml_tree_densities(),
        /*
         *  The accent of whichever admin colour scheme this user picked. The
         *  'native' skin uses it so the tree belongs to the admin it is sitting
         *  in rather than announcing itself. Neither competitor reads this.
         */
        'accent'     => vergeml_admin_accent(),
        /*
         *  Where the Librarian lives, handed to the tree so the one screen
         *  that can do something about an unfiled library is reachable from
         *  the screen where people notice it is unfiled.
         *
         *  It was a submenu entry under a top-level menu, which means it was
         *  found by people who already knew it existed. The media library is
         *  where somebody is standing when the problem occurs to them.
         */
        'librarianUrl' => current_user_can( 'manage_categories' )
            ? admin_url( 'admin.php?page=media-librarian' )
            : '',
        /*
         *  A ready-made, nonce-carrying download link; the browser only appends
         *  which folder. Built here because a nonce cannot be minted in the
         *  browser.
         */
        'zipUrl'     => wp_nonce_url( admin_url( 'admin-post.php?action=vergeml_zip' ), 'vergeml_zip' ),
        'l10n'       => array(
            /* translators: %s: how many files have no folder. */
            'sortPrompt' => __( '%s files are not in a folder', 'vergelabs-media-library' ),
            'sortGo'     => __( 'Sort them', 'vergelabs-media-library' ),
            /*
             *  "All files" is wrong above a list of pages. The post type's own
             *  plural is what that screen calls them everywhere else, so it is
             *  what the tree calls them too.
             */
            'all'            => $folder_post_type
                ? ( get_post_type_object( $folder_post_type )
                    ? get_post_type_object( $folder_post_type )->labels->all_items
                    : __( 'All', 'vergelabs-media-library' ) )
                : __( 'All files', 'vergelabs-media-library' ),
            'unassigned'     => __( 'Unfiled', 'vergelabs-media-library' ),
            'newFolder'      => __( 'New folder', 'vergelabs-media-library' ),
            'upload'         => __( 'Upload', 'vergelabs-media-library' ),
            'newSubfolder'   => __( 'New subfolder', 'vergelabs-media-library' ),
            'allFiles'       => __( 'All files', 'vergelabs-media-library' ),
            'collapse'       => __( 'Collapse panel', 'vergelabs-media-library' ),
            'filters'        => __( 'Filters', 'vergelabs-media-library' ),
            'aiFolders'      => __( 'AI folders', 'vergelabs-media-library' ),
            'aiLadder'       => __( 'Nothing described yet — describe your library', 'vergelabs-media-library' ),
            'expand'         => __( 'Expand panel', 'vergelabs-media-library' ),
            'uploadHere'     => __( 'Upload to this folder', 'vergelabs-media-library' ),
            /* translators: %s: folder name. */
            'uploadTo'       => __( 'Upload to “%s”', 'vergelabs-media-library' ),
            'uploadUnfiled'  => __( 'Upload files (they will be unfiled)', 'vergelabs-media-library' ),
            'rename'         => __( 'Rename', 'vergelabs-media-library' ),
            'color'          => __( 'Colour', 'vergelabs-media-library' ),
            /*
             *  Named, not just shown. Eight coloured circles with no names are
             *  unusable with a screen reader and ambiguous with colour blindness,
             *  which is most of the reason to have a fixed palette rather than a
             *  hex field: a fixed set can be named.
             */
            'colorNone'      => __( 'No colour', 'vergelabs-media-library' ),
            'colorRed'       => __( 'Red', 'vergelabs-media-library' ),
            'colorCoral'     => __( 'Coral', 'vergelabs-media-library' ),
            'colorAmber'     => __( 'Amber', 'vergelabs-media-library' ),
            'colorYellow'    => __( 'Yellow', 'vergelabs-media-library' ),
            'colorOlive'     => __( 'Olive', 'vergelabs-media-library' ),
            'colorLime'      => __( 'Lime', 'vergelabs-media-library' ),
            'colorGreen'     => __( 'Green', 'vergelabs-media-library' ),
            'colorTeal'      => __( 'Teal', 'vergelabs-media-library' ),
            'colorCyan'      => __( 'Cyan', 'vergelabs-media-library' ),
            'colorSky'       => __( 'Sky', 'vergelabs-media-library' ),
            'colorBlue'      => __( 'Blue', 'vergelabs-media-library' ),
            'colorIndigo'    => __( 'Indigo', 'vergelabs-media-library' ),
            'colorViolet'    => __( 'Violet', 'vergelabs-media-library' ),
            'colorMagenta'   => __( 'Magenta', 'vergelabs-media-library' ),
            'colorPink'      => __( 'Pink', 'vergelabs-media-library' ),
            'colorBrown'     => __( 'Brown', 'vergelabs-media-library' ),
            'colorSlate'     => __( 'Slate', 'vergelabs-media-library' ),
            'delete'         => __( 'Delete', 'vergelabs-media-library' ),
            'search'         => __( 'Search folders', 'vergelabs-media-library' ),
            'folders'        => __( 'Folders', 'vergelabs-media-library' ),
            'namePrompt'     => __( 'Folder name', 'vergelabs-media-library' ),
            /* translators: %s: folder name. */
            'renamePrompt'   => __( 'Rename %s to', 'vergelabs-media-library' ),
            /*
             *  Said in these words on purpose. "Delete folder" reads as "delete
             *  my photos" to anyone who has not thought about it, and the whole
             *  reason folders are terms is that it is not true.
             */
            /* translators: 1: folder name, 2: number of sub-folders. */
            'deleteConfirm'  => __( 'Delete the folder "%1$s"? Its %2$d sub-folders move up one level. No files are deleted — they simply leave this folder.', 'vergelabs-media-library' ),
            /* translators: %s: folder name. */
            'deleteSimple'   => __( 'Delete the folder "%s"? No files are deleted — they simply leave this folder.', 'vergelabs-media-library' ),
            /*
             *  Two strings, because "1 files filed" is the sort of thing that makes
             *  somebody trust the rest of the interface a little less. Not _n():
             *  this is read by JavaScript, which cannot ask WordPress which plural
             *  form a language wants, so the two cases it can distinguish are the
             *  two it is given.
             */
            'undoAssignedOne' => __( '1 file filed', 'vergelabs-media-library' ),
            /* translators: %d: number of files. */
            'undoAssigned'   => __( '%d files filed', 'vergelabs-media-library' ),
            // Filing without a mouse: the Move button, the M key, the picker.
            'moveSelected'   => __( 'Move selected…', 'vergelabs-media-library' ),
            'moveTo'         => __( 'Move to folder', 'vergelabs-media-library' ),
            /* translators: %d: number of selected files. */
            'moveCount'      => __( '%d selected — choose a folder', 'vergelabs-media-library' ),
            'moveOne'        => __( '1 selected — choose a folder', 'vergelabs-media-library' ),
            'typeToFilter'   => __( 'Type to find a folder', 'vergelabs-media-library' ),
            'noFolder'       => __( 'No folder', 'vergelabs-media-library' ),
            'nothingSelected' => __( 'Select files first — tick them in the list or click them in the grid, then press M or use Move selected.', 'vergelabs-media-library' ),
            'moveHint'       => __( 'Press M with files selected to move them without dragging.', 'vergelabs-media-library' ),
            'density'        => __( 'Density', 'vergelabs-media-library' ),
            'cancel'         => __( 'Cancel', 'vergelabs-media-library' ),
            'oneFile'        => __( '1 file', 'vergelabs-media-library' ),
            /* translators: %d: number of files being dragged. */
            'manyFiles'      => __( '%d files', 'vergelabs-media-library' ),
            'undo'           => __( 'Undo', 'vergelabs-media-library' ),
            'undone'         => __( 'Put back', 'vergelabs-media-library' ),
            /* translators: %d: number of folders a file belongs to. */
            'inFolders'      => __( 'in %d folders', 'vergelabs-media-library' ),
            'smartScan'      => __( 'Scan', 'vergelabs-media-library' ),
            /* translators: 1: posts scanned, 2: posts total. */
            'scanPosts'      => __( '%1$s / %2$s posts', 'vergelabs-media-library' ),
            /* translators: 1: files stamped, 2: files total. */
            'scanFiles'      => __( '%1$s / %2$s files', 'vergelabs-media-library' ),
            /* translators: %s: folder name shown on the drag-and-drop overlay. */
            'dropInto'       => __( 'Drop your files here to add to “%s”', 'vergelabs-media-library' ),
            'dropHere'       => __( 'Drop your files here', 'vergelabs-media-library' ),
            'downloadZip'    => __( 'Download as ZIP', 'vergelabs-media-library' ),
            'copyShortcode'  => __( 'Copy gallery shortcode', 'vergelabs-media-library' ),
            'makePrivate'    => __( 'Only I see this folder', 'vergelabs-media-library' ),
            'makeShared'     => __( 'Let everyone see this folder', 'vergelabs-media-library' ),
            /*
             *  Deliberate wording. It hides the FOLDER, never the files: the
             *  pictures inside stay in the library for everyone, and a label
             *  promising otherwise would be the one thing this feature must
             *  not do -- somebody would trust it with something sensitive.
             */
            'privateNote'    => __( 'Only you see this folder. The files inside stay in the library for everyone.', 'vergelabs-media-library' ),
            'sharedNote'     => __( 'Everyone can see this folder again.', 'vergelabs-media-library' ),
            /* translators: %s: the name of the person whose folder it is. */
            'privateOwned'   => __( '%s only', 'vergelabs-media-library' ),
            'privateMine'    => __( 'only you', 'vergelabs-media-library' ),
            'copied'         => __( 'Shortcode copied', 'vergelabs-media-library' ),
            /*
             *  Shown when the copy did not work, which happens on plain http in
             *  older browsers. The toast shows the shortcode itself rather than
             *  an apology, because the shortcode is the thing the person still
             *  needs and can select by hand.
             */
            'skin'           => __( 'Appearance', 'vergelabs-media-library' ),
            'skinNative'     => __( 'Native', 'vergelabs-media-library' ),
            'skinClassic'    => __( 'Classic', 'vergelabs-media-library' ),
            'skinMinimal'    => __( 'Minimal', 'vergelabs-media-library' ),
            'skinContrast'   => __( 'High contrast', 'vergelabs-media-library' ),
            'comfortable'    => __( 'Comfortable', 'vergelabs-media-library' ),
            'compact'        => __( 'Compact', 'vergelabs-media-library' ),
            'nothingFound'   => __( 'No folders match', 'vergelabs-media-library' ),
            /* translators: %d: number of folders not shown. */
            'moreFolders'    => __( '%d more — use search to find them', 'vergelabs-media-library' ),
            'failed'         => __( 'That did not work. Nothing was changed.', 'vergelabs-media-library' ),
        ),
    ) );
}


/**
 *  vergeml_tree_palette
 *
 *  Eight colours, fixed. Not a colour picker: a dot in a sidebar has to stay
 *  legible against eight different admin schemes, in light and dark, and a free
 *  hex field guarantees that some of them will not be. These were picked to
 *  hold contrast in all of them.
 */

function vergeml_tree_palette() {

    return array(
        '',         // none -- inherits the skin's own colour
        '#d63638',  // red
        '#e65054',  // coral
        '#e07d10',  // amber
        '#d9a404',  // yellow
        '#997e00',  // olive
        '#6a9a23',  // lime
        '#2f8f45',  // green
        '#0f7c8c',  // teal
        '#0891b2',  // cyan
        '#2271b1',  // sky
        '#3858e9',  // blue
        '#5b4ee9',  // indigo
        '#7c3aed',  // violet
        '#a4286a',  // magenta
        '#c2578c',  // pink
        '#8c6a4f',  // brown
        '#646970',  // slate
    );
}


/**
 *  vergeml_admin_accent
 *
 *  The highlight colour of this user's admin colour scheme, or the default blue
 *  if the scheme is unknown. Read once and handed to the browser rather than
 *  guessed at in CSS, because the schemes are registered in PHP and a plugin
 *  can add more.
 */

function vergeml_admin_accent() {

    global $_wp_admin_css_colors;

    $scheme = get_user_option( 'admin_color' );

    if ( ! $scheme || ! isset( $_wp_admin_css_colors[ $scheme ] ) )
        return '#3858e9';

    $colors = $_wp_admin_css_colors[ $scheme ]->colors;

    // The schemes list four colours; the third is the one core uses for
    // highlights, and it is the one that reads as "the accent" on screen.
    if ( isset( $colors[2] ) )
        return $colors[2];

    return isset( $colors[0] ) ? $colors[0] : '#3858e9';
}
